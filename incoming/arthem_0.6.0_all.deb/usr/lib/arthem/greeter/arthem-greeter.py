#!/usr/bin/env python3
"""Arthem Greeter: экран входа LightDM в стиле Windows XP, 7, 10, 11 и macOS.

Настройки — /etc/lightdm/arthem-greeter.conf (пишет /usr/lib/arthem/arthem-root):
    [greeter]
    style=xp|w7|w10|w11|mac
    background=/путь/к/фону.png
    fallback=slick-greeter

Проверка без LightDM:  arthem-greeter --test-mode [--style w10]
"""

import configparser
import math
import os
import sys
import time

import cairo  # noqa: F401  (без python3-cairo/gi-cairo рисовать нельзя — пусть обёртка сразу включит обычный вход)
import gi

gi.require_foreign("cairo")
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk  # noqa: E402

TEST = "--test-mode" in sys.argv
if not TEST:
    gi.require_version("LightDM", "1")
    from gi.repository import LightDM  # noqa: E402

CONF = os.environ.get("ARTHEM_GREETER_CONF", "/etc/lightdm/arthem-greeter.conf")
SHARE = "/usr/share/arthem"

RU = os.environ.get("LANG", "ru").startswith("ru") or True
T = {
    "begin": "Чтобы начать работу, щёлкните имя пользователя",
    "off": "Выключить компьютер",
    "after": "После входа в систему можно добавить или изменить учётные записи.\nОткройте панель управления и выберите «Учётные записи».",
    "password": "Пароль",
    "wrong": "Неверный пароль. Попробуйте ещё раз.",
    "switch": "Сменить пользователя",
    "welcome": "Добро пожаловать",
    "sleep": "Сон", "restart": "Перезагрузка", "shutdown": "Выключение",
    "hint": "Нажмите любую клавишу или щёлкните, чтобы войти",
    "enter": "Введите пароль",
    "other": "Другой пользователь",
}

STYLES = ("xp", "w7", "w10", "w11", "mac")


def load_conf():
    cp = configparser.RawConfigParser()
    try:
        cp.read(CONF, encoding="utf-8")
    except configparser.Error:
        pass
    g = cp["greeter"] if cp.has_section("greeter") else {}
    style = g.get("style", "w10")
    for i, a in enumerate(sys.argv):
        if a == "--style" and i + 1 < len(sys.argv):
            style = sys.argv[i + 1]
    if style not in STYLES:
        style = "w10"
    bg = g.get("background", "")
    if not bg or not os.path.isfile(bg):
        for ext in (".png", ".jpg"):
            cand = f"{SHARE}/login/{style}{ext}"
            if os.path.isfile(cand):
                bg = cand
                break
    return style, bg


# ------------------------------------------------------------------ рисование

def rgb(h, a=1.0):
    h = h.lstrip("#")
    return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)


def rounded(cr, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


def text(cr, s, x, y, size, color, bold=False, family="Sans", align="left", italic=False, shadow=False):
    import cairo
    cr.select_font_face(family, cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    cr.set_font_size(size)
    lines = s.split("\n")
    for i, line in enumerate(lines):
        ext = cr.text_extents(line)
        xx = x - ext.x_advance / 2 if align == "center" else (x - ext.x_advance if align == "right" else x)
        yy = y + i * size * 1.35
        if shadow:
            cr.set_source_rgba(0, 0, 0, 0.45)
            cr.move_to(xx + 1, yy + 1)
            cr.show_text(line)
        cr.set_source_rgba(*color)
        cr.move_to(xx, yy)
        cr.show_text(line)
    cr.new_path()  # иначе следующая фигура начнётся линией от конца текста


def diamond(cr, cx, cy, size, colors):
    cr.save()
    cr.translate(cx, cy)
    cr.rotate(math.pi / 4)
    s = size / 2.3
    g = size / 14
    for i, (dx, dy) in enumerate(((-1, -1), (0, -1), (-1, 0), (0, 0))):
        x = dx * s + (g if dx == 0 else -g)
        y = dy * s + (g if dy == 0 else -g)
        cr.set_source_rgba(*rgb(colors[i % len(colors)]))
        rounded(cr, x, y, s, s, size / 40)
        cr.fill()
    cr.restore()


def avatar_pixbuf(path, size, style):
    if path and os.path.isfile(path):
        try:
            return GdkPixbuf.Pixbuf.new_from_file_at_scale(path, size, size, False)
        except GLib.Error:
            pass
    return None


def draw_default_avatar(cr, x, y, size, style):
    """Своя картинка пользователя: силуэт на цветной плашке в духе системы."""
    bgc = {"xp": ("#F2B24B", "#D9731A"), "w7": ("#7FB2E6", "#2E6DB4"), "w10": ("#8F8F8F", "#5A5A5A"),
           "w11": ("#9DB7DC", "#5D7FB5"), "mac": ("#B9B9C0", "#8A8A93")}[style]
    import cairo
    g = cairo.LinearGradient(0, y, 0, y + size)
    g.add_color_stop_rgba(0, *rgb(bgc[0]))
    g.add_color_stop_rgba(1, *rgb(bgc[1]))
    cr.set_source(g)
    if style in ("w10", "w11", "mac"):
        cr.arc(x + size / 2, y + size / 2, size / 2, 0, 2 * math.pi)
    else:
        rounded(cr, x, y, size, size, size * 0.08)
    cr.fill()
    cr.set_source_rgba(1, 1, 1, 0.92)
    cr.arc(x + size / 2, y + size * 0.38, size * 0.17, 0, 2 * math.pi)
    cr.fill()
    cr.save()
    if style in ("w10", "w11", "mac"):
        cr.arc(x + size / 2, y + size / 2, size / 2, 0, 2 * math.pi)
        cr.clip()
    cr.arc(x + size / 2, y + size * 0.92, size * 0.32, math.pi, 2 * math.pi)
    cr.fill()
    cr.restore()


class User:
    def __init__(self, name, display, image=None, logged_in=False):
        self.name, self.display, self.image, self.logged_in = name, display or name, image, logged_in


# ------------------------------------------------------------------ окно

class Greeter(Gtk.Window):
    def __init__(self, style, bg):
        super().__init__(title="Arthem")
        self.style, self.bg_path = style, bg
        self.greeter = None
        self.users = []
        self.selected = None
        self.locked = style in ("w10", "w11")  # экран блокировки с часами
        self.error = ""
        self.busy = False
        self.hover = None
        self.avatar_cache = {}
        self._bg = None
        self._bg_blur = None

        scr = Gdk.Screen.get_default()
        disp = Gdk.Display.get_default()
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        geo = mon.get_geometry()
        self.W, self.H = (1280, 720) if TEST else (geo.width, geo.height)
        self.set_default_size(self.W, self.H)
        if not TEST:
            self.move(geo.x, geo.y)
            self.set_decorated(False)
            self.fullscreen()
        vis = scr.get_rgba_visual()
        if vis:
            self.set_visual(vis)
        self.set_app_paintable(True)

        # Fixed: сначала фон (DrawingArea), поверх — поле пароля и кнопка
        self.fixed = Gtk.Fixed()
        self.area = Gtk.DrawingArea()
        self.area.set_size_request(self.W, self.H)
        self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.POINTER_MOTION_MASK)
        self.area.connect("draw", self.on_draw)
        self.area.connect("button-press-event", self.on_click)
        self.area.connect("motion-notify-event", self.on_motion)
        self.fixed.put(self.area, 0, 0)
        self.add(self.fixed)
        self.pending = None

        self.entry = Gtk.Entry()
        self.entry.set_visibility(False)
        self.entry.set_invisible_char("●")
        self.entry.set_placeholder_text(T["password"])
        self.entry.get_style_context().add_class("arthem-password")
        self.entry.connect("activate", self.on_submit)
        self.go = Gtk.Button(label="→")
        self.go.get_style_context().add_class("arthem-go")
        self.go.connect("clicked", self.on_submit)
        self.connect("key-press-event", self.on_key)
        self._css()
        self._load_bg()
        self._connect_lightdm()
        GLib.timeout_add_seconds(15, self._tick)
        self.hits = []
        if len(self.users) == 1 or style in ("w7", "w10", "w11") or (style == "mac" and len(self.users) == 1):
            self.selected = self._default_user()
            if not self.locked:
                self.start_auth(self.selected)
                return
        self.layout()

    # --- LightDM

    def _connect_lightdm(self):
        if TEST:
            self.users = [User("alex", "Алексей"), User("guest", "Гость")]
            return
        self.greeter = LightDM.Greeter()
        self.greeter.connect("show-prompt", self.on_prompt)
        self.greeter.connect("show-message", self.on_message)
        self.greeter.connect("authentication-complete", self.on_auth_complete)
        self.greeter.connect_to_daemon_sync()
        ul = LightDM.UserList.get_instance()
        for u in ul.get_users():
            self.users.append(User(u.get_name(), u.get_display_name(), u.get_image(), u.get_logged_in()))
        if not self.users:
            self.users.append(User(None, T["other"]))

    def _default_user(self):
        if not self.users:
            return None
        if self.greeter:
            hint = self.greeter.get_select_user_hint()
            for u in self.users:
                if u.name == hint:
                    return u
        return self.users[0]

    def start_auth(self, user):
        self.selected = user
        self.error = ""
        self.entry.set_text("")
        if self.greeter:
            if self.greeter.get_in_authentication():
                self.greeter.cancel_authentication()
            self.greeter.authenticate(user.name)
        self.layout()
        self.entry.grab_focus()

    def on_prompt(self, _g, prompt, ptype):
        self.entry.set_placeholder_text(T["password"] if "assword" in prompt or "арол" in prompt else prompt.strip(": "))
        self.busy = False
        if self.pending is not None:
            pw, self.pending = self.pending, None
            self.busy = True
            self.greeter.respond(pw)
            return
        self.layout()

    def on_message(self, _g, msg, _mtype):
        self.error = msg
        self.area.queue_draw()

    def on_submit(self, *_a):
        if self.busy or not self.selected:
            return
        pw = self.entry.get_text()
        if TEST:
            self.error = "" if pw == "test" else T["wrong"]
            self.entry.set_text("")
            self.area.queue_draw()
            return
        self.busy = True
        if not self.greeter.get_in_authentication():
            # ответ отправим, когда LightDM спросит пароль
            self.pending = pw
            self.greeter.authenticate(self.selected.name)
            return
        self.greeter.respond(pw)

    def on_auth_complete(self, g):
        self.busy = False
        if g.get_is_authenticated():
            session = None
            try:
                session = g.get_default_session_hint()
            except Exception:
                pass
            try:
                g.start_session_sync(session)
            except GLib.Error as exc:
                self.error = str(exc)
        else:
            self.error = T["wrong"]
            self.entry.set_text("")
            g.authenticate(self.selected.name)
        self.area.queue_draw()

    def power(self, what):
        if TEST:
            print("power:", what)
            return
        try:
            {"sleep": LightDM.suspend, "restart": LightDM.restart, "shutdown": LightDM.shutdown}[what]()
        except Exception as exc:
            self.error = str(exc)
            self.area.queue_draw()

    # --- оформление

    def _css(self):
        css = {
            "xp": """
                .arthem-password { font: 13px Tahoma, Sans; min-height: 22px; padding: 1px 4px; border: 1px solid #7F9DB9;
                    border-radius: 0; background: #FFFFFF; color: #000; box-shadow: none; }
                .arthem-go { min-width: 24px; min-height: 22px; padding: 0; border-radius: 3px; border: 1px solid #FFFFFF;
                    background-image: linear-gradient(to bottom, #6FCF5A, #2D9A1C); color: #FFFFFF; font: bold 14px Sans; box-shadow: none; }
                .arthem-go:hover { background-image: linear-gradient(to bottom, #8BE476, #38B024); }
            """,
            "w7": """
                .arthem-password { font: 13px "Segoe UI", Sans; min-height: 24px; padding: 2px 6px; border: 1px solid #1C4E80;
                    border-radius: 2px; background: #FFFFFF; color: #000; box-shadow: inset 0 1px 2px rgba(0,0,0,0.25); }
                .arthem-go { min-width: 28px; min-height: 28px; padding: 0; border-radius: 3px; border: 1px solid #0F3C6E;
                    background-image: linear-gradient(to bottom, #6AA6E2, #2462A8); color: #FFFFFF; font: bold 15px Sans; box-shadow: none; }
                .arthem-go:hover { background-image: linear-gradient(to bottom, #8CC2F5, #2F79C8); }
            """,
            "w10": """
                .arthem-password { font: 15px "Segoe UI", Sans; min-height: 30px; padding: 2px 10px; border: 2px solid rgba(255,255,255,0.75);
                    border-radius: 0; background: rgba(255,255,255,0.85); color: #000; box-shadow: none; }
                .arthem-go { min-width: 34px; min-height: 34px; padding: 0; border-radius: 0; border: none;
                    background: rgba(255,255,255,0.25); color: #FFFFFF; font: 16px Sans; box-shadow: none; }
                .arthem-go:hover { background: rgba(255,255,255,0.4); }
            """,
            "w11": """
                .arthem-password { font: 14px "Segoe UI Variable", "Segoe UI", Sans; min-height: 30px; padding: 2px 10px;
                    border: 1px solid rgba(255,255,255,0.35); border-bottom: 2px solid #5FB2F2; border-radius: 5px;
                    background: rgba(255,255,255,0.75); color: #000; box-shadow: none; }
                .arthem-go { min-width: 30px; min-height: 30px; padding: 0; border-radius: 4px; border: none;
                    background: rgba(0,0,0,0.12); color: #222; font: 15px Sans; box-shadow: none; }
                .arthem-go:hover { background: rgba(0,0,0,0.22); }
            """,
            "mac": """
                .arthem-password { font: 13px "SF Pro Text", "Helvetica Neue", Sans; min-height: 26px; padding: 0 12px;
                    border: 1px solid rgba(255,255,255,0.25); border-radius: 14px; background: rgba(255,255,255,0.22);
                    color: #FFFFFF; caret-color: #FFFFFF; box-shadow: none; }
                .arthem-password image { color: #FFFFFF; }
                .arthem-go { min-width: 24px; min-height: 24px; padding: 0; border-radius: 12px; border: 1px solid rgba(255,255,255,0.4);
                    background: rgba(255,255,255,0.15); color: #FFFFFF; font: 13px Sans; box-shadow: none; }
            """,
        }[self.style]
        prov = Gtk.CssProvider()
        prov.load_from_data((css + " window { background: #000; } entry selection { background: #3D7BD9; }").encode())
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)

    def _load_bg(self):
        if not self.bg_path:
            return
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(self.bg_path)
        except GLib.Error:
            return
        sw, sh = pb.get_width(), pb.get_height()
        s = max(self.W / sw, self.H / sh)
        w, h = max(1, int(sw * s)), max(1, int(sh * s))
        pb = pb.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
        self._bg = pb.new_subpixbuf((w - self.W) // 2, (h - self.H) // 2, self.W, self.H).copy()
        if self.style in ("w10", "w11", "mac"):
            # размытие: уменьшить и увеличить обратно (Acrylic / Mica / вход macOS)
            small = self._bg.scale_simple(max(1, self.W // 28), max(1, self.H // 28), GdkPixbuf.InterpType.BILINEAR)
            mid = small.scale_simple(max(1, self.W // 6), max(1, self.H // 6), GdkPixbuf.InterpType.BILINEAR)
            self._bg_blur = mid.scale_simple(self.W, self.H, GdkPixbuf.InterpType.BILINEAR)

    def _avatar(self, cr, user, x, y, size):
        pb = self.avatar_cache.get((user.name, size))
        if pb is None and user.image:
            pb = avatar_pixbuf(user.image, size, self.style)
            self.avatar_cache[(user.name, size)] = pb or False
        if pb:
            cr.save()
            if self.style in ("w10", "w11", "mac"):
                cr.arc(x + size / 2, y + size / 2, size / 2, 0, 2 * math.pi)
                cr.clip()
            Gdk.cairo_set_source_pixbuf(cr, pb, x, y)
            cr.paint()
            cr.restore()
        else:
            draw_default_avatar(cr, x, y, size, self.style)

    # --- раскладка виджетов

    def _place(self, widget, x, y, w, h):
        if widget.get_parent() is None:
            self.fixed.put(widget, int(x), int(y))
        else:
            self.fixed.move(widget, int(x), int(y))
        widget.set_size_request(int(w), int(h))
        widget.show()

    def _hide_inputs(self):
        for w in (self.entry, self.go):
            w.hide()

    def layout(self):
        W, H, st = self.W, self.H, self.style
        self._hide_inputs()
        self.hits = []
        if st == "xp":
            # справа от разделителя — плитки пользователей
            x0, y0 = W // 2 + 30, int(H * 0.27)
            for i, u in enumerate(self.users[:6]):
                y = y0 + i * 92
                self.hits.append(("user", u, (x0, y, 380, 80)))
                if u is self.selected:
                    self._place(self.entry, x0 + 92, y + 46, 180, 24)
                    self._place(self.go, x0 + 278, y + 46, 26, 24)
            self.hits.append(("power", "shutdown", (24, H - 70, 260, 44)))
        elif st == "w7":
            cx, cy = W // 2, int(H * 0.42)
            if self.selected:
                self._place(self.entry, cx - 115, cy + 120, 210, 26)
                self._place(self.go, cx + 100, cy + 119, 28, 28)
            self.hits.append(("power", "shutdown", (W - 90, H - 60, 64, 36)))
            if len(self.users) > 1:
                self.hits.append(("switch", None, (cx - 90, cy + 175, 180, 34)))
        elif st in ("w10", "w11"):
            if self.locked:
                self.hits.append(("unlock", None, (0, 0, W, H)))
            else:
                cx, cy = W // 2, int(H * 0.40)
                if self.selected:
                    if st == "w10":
                        self._place(self.entry, cx - 150, cy + 150, 266, 34)
                        self._place(self.go, cx + 116, cy + 150, 34, 34)
                    else:
                        self._place(self.entry, cx - 140, cy + 148, 280, 34)
                        self._place(self.go, cx + 106, cy + 150, 30, 30)
                for i, u in enumerate(self.users[:6]):
                    self.hits.append(("user", u, (16, H - 70 - (len(self.users[:6]) - 1 - i) * 62, 260, 56)))
                self.hits.append(("power", "shutdown", (W - 70, H - 64, 48, 48)))
        else:  # mac
            n = len(self.users[:5])
            if self.selected:
                cx, cy = W // 2, int(H * 0.66)
                self._place(self.entry, cx - 90, cy + 70, 180, 28)
                self._place(self.go, cx + 96, cy + 72, 24, 24)
            else:
                for i, u in enumerate(self.users[:5]):
                    x = W // 2 - (n * 120) // 2 + i * 120 + 10
                    self.hits.append(("user", u, (x, int(H * 0.62), 100, 130)))
            for i, what in enumerate(("sleep", "restart", "shutdown")):
                x = W // 2 - 140 + i * 110
                self.hits.append(("power", what, (x, H - 110, 90, 80)))
            if self.selected and n > 1:
                self.hits.append(("back", None, (W // 2 - 60, int(H * 0.66) + 112, 120, 24)))
        self.area.queue_draw()
        if self.entry.get_visible():
            GLib.idle_add(self.entry.grab_focus)

    # --- события

    def _hit(self, x, y):
        for kind, val, (hx, hy, hw, hh) in self.hits:
            if hx <= x <= hx + hw and hy <= y <= hy + hh:
                return kind, val
        return None, None

    def on_click(self, _w, ev):
        kind, val = self._hit(ev.x, ev.y)
        if kind == "unlock":
            self.locked = False
            self.start_auth(self.selected or self._default_user())
        elif kind == "user":
            self.start_auth(val)
        elif kind == "power":
            self.power(val)
        elif kind == "switch":
            idx = self.users.index(self.selected) if self.selected in self.users else -1
            self.start_auth(self.users[(idx + 1) % len(self.users)])
        elif kind == "back":
            self.selected = None
            self.layout()
        return True

    def on_motion(self, _w, ev):
        kind, val = self._hit(ev.x, ev.y)
        h = (kind, getattr(val, "name", val)) if kind else None
        if h != self.hover:
            self.hover = h
            self.area.queue_draw()

    def on_key(self, _w, ev):
        if self.locked:
            self.locked = False
            self.start_auth(self.selected or self._default_user())
            return True
        if ev.keyval == Gdk.KEY_Escape:
            if self.style in ("w10", "w11"):
                self.locked = True
                self.layout()
                return True
            if self.style == "mac" and len(self.users) > 1:
                self.selected = None
                self.layout()
                return True
        return False

    def _tick(self):
        self.area.queue_draw()
        return True

    # --- отрисовка

    def on_draw(self, _w, cr):
        W, H = self.W, self.H
        blur = self._bg_blur if (self.style in ("w10", "w11") and not self.locked) or self.style == "mac" else None
        pb = blur or self._bg
        if pb:
            Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
            cr.paint()
        else:
            cr.set_source_rgb(0.1, 0.2, 0.4)
            cr.paint()
        getattr(self, "draw_" + self.style)(cr, W, H)
        return False

    def _hov(self, kind, val):
        return self.hover == (kind, val)

    def draw_xp(self, cr, W, H):
        import cairo
        # верхняя и нижняя полосы
        cr.set_source_rgba(*rgb("#00309C"))
        cr.rectangle(0, 0, W, 78)
        cr.fill()
        g = cairo.LinearGradient(0, 78, W, 78)
        g.add_color_stop_rgba(0, *rgb("#00309C"))
        g.add_color_stop_rgba(0.5, *rgb("#FFFFFF", 0.9))
        g.add_color_stop_rgba(1, *rgb("#00309C"))
        cr.set_source(g)
        cr.rectangle(0, 78, W, 2)
        cr.fill()
        cr.set_source_rgba(*rgb("#00309C"))
        cr.rectangle(0, H - 92, W, 92)
        cr.fill()
        g = cairo.LinearGradient(0, H - 94, W, H - 94)
        g.add_color_stop_rgba(0, *rgb("#00309C"))
        g.add_color_stop_rgba(0.35, *rgb("#F79F2B"))
        g.add_color_stop_rgba(1, *rgb("#00309C"))
        cr.set_source(g)
        cr.rectangle(0, H - 94, W, 2)
        cr.fill()
        # разделитель
        g = cairo.LinearGradient(0, H * 0.2, 0, H * 0.8)
        g.add_color_stop_rgba(0, 1, 1, 1, 0)
        g.add_color_stop_rgba(0.5, 1, 1, 1, 0.7)
        g.add_color_stop_rgba(1, 1, 1, 1, 0)
        cr.set_source(g)
        cr.rectangle(W // 2 - 1, H * 0.2, 1, H * 0.6)
        cr.fill()
        # слева: логотип и подсказка
        lx = W // 2 - 60
        ly = int(H * 0.36)
        diamond(cr, lx - 250, ly, 80, ["#F65314", "#7CBB00", "#00A1F1", "#FFBB00"])
        text(cr, "Arthem", lx - 195, ly + 12, 36, rgb("#FFFFFF"), bold=True, italic=True, shadow=True)
        text(cr, "XP", lx - 50, ly - 12, 18, rgb("#F79F2B"), bold=True, italic=True)
        text(cr, T["begin"], lx, ly + 90, 15, rgb("#FFFFFF"), align="right", family="Tahoma")
        # плитки пользователей
        for kind, u, (x, y, w, h) in self.hits:
            if kind != "user":
                continue
            sel = u is self.selected
            if sel or self._hov("user", u.name):
                g = cairo.LinearGradient(x, 0, x + w, 0)
                g.add_color_stop_rgba(0, *rgb("#00309C", 0.9 if sel else 0.5))
                g.add_color_stop_rgba(1, *rgb("#00309C", 0))
                cr.set_source(g)
                rounded(cr, x, y, w, h, 8)
                cr.fill()
            cr.set_source_rgba(1, 1, 1, 1 if sel else 0.6)
            rounded(cr, x + 8, y + 8, 64, 64, 4)
            cr.fill()
            self._avatar(cr, u, x + 10, y + 10, 60)
            text(cr, u.display, x + 92, y + 32, 19, rgb("#FFFFFF"), family="Tahoma", shadow=True)
            if sel and self.selected:
                text(cr, "Введите пароль:", x + 92, y + 42, 11, rgb("#FFFFFF"), family="Tahoma")
        # низ: выключение и текст
        x, y = 24, H - 70
        g = cairo.LinearGradient(0, y, 0, y + 30)
        g.add_color_stop_rgba(0, *rgb("#F2875A"))
        g.add_color_stop_rgba(1, *rgb("#D2400F"))
        cr.set_source(g)
        rounded(cr, x, y + 4, 30, 30, 4)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 1)
        cr.set_line_width(2.4)
        cr.arc(x + 15, y + 20, 8, -math.pi * 0.3, math.pi * 1.3)
        cr.stroke()
        cr.move_to(x + 15, y + 9)
        cr.line_to(x + 15, y + 19)
        cr.stroke()
        text(cr, T["off"], x + 42, y + 25, 14, rgb("#FFFFFF"), family="Tahoma", shadow=self._hov("power", "shutdown"))
        text(cr, T["after"], W - 40, H - 56, 12, rgb("#FFFFFF"), family="Tahoma", align="right")
        if self.error:
            text(cr, self.error, W // 2 + 122, int(H * 0.27) - 16, 13, rgb("#FFE38A"), family="Tahoma")

    def draw_w7(self, cr, W, H):
        import cairo
        cx, cy = W // 2, int(H * 0.42)
        u = self.selected
        if u:
            # рамка аватара — стеклянная
            s = 126
            x, y = cx - s // 2, cy - s // 2 - 10
            cr.set_source_rgba(1, 1, 1, 0.35)
            rounded(cr, x - 12, y - 12, s + 24, s + 24, 10)
            cr.fill()
            cr.set_source_rgba(1, 1, 1, 0.8)
            cr.set_line_width(1)
            rounded(cr, x - 12.5, y - 12.5, s + 25, s + 25, 10)
            cr.stroke()
            self._avatar(cr, u, x, y, s)
            text(cr, u.display, cx, cy + 92, 22, rgb("#FFFFFF"), family="Segoe UI", align="center", shadow=True)
        if len(self.users) > 1:
            hov = self._hov("switch", None)
            cr.set_source_rgba(1, 1, 1, 0.25 if hov else 0.12)
            rounded(cr, cx - 90, cy + 175, 180, 34, 4)
            cr.fill()
            text(cr, T["switch"], cx, cy + 197, 14, rgb("#FFFFFF"), family="Segoe UI", align="center", shadow=True)
        if self.error:
            text(cr, self.error, cx, cy + 165, 14, rgb("#FFFFFF"), family="Segoe UI", align="center", shadow=True)
        # кнопка питания (красная) справа внизу
        x, y = W - 90, H - 60
        g = cairo.LinearGradient(0, y, 0, y + 30)
        g.add_color_stop_rgba(0, *rgb("#E66A5C" if not self._hov("power", "shutdown") else "#F48A7C"))
        g.add_color_stop_rgba(1, *rgb("#A42315"))
        cr.set_source(g)
        rounded(cr, x, y, 40, 30, 4)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 0.9)
        cr.set_line_width(2)
        cr.arc(x + 20, y + 16, 7, -math.pi * 0.3, math.pi * 1.3)
        cr.stroke()
        cr.move_to(x + 20, y + 6)
        cr.line_to(x + 20, y + 15)
        cr.stroke()
        # знак внизу по центру
        diamond(cr, cx - 70, H - 60, 34, ["#F65314", "#7CBB00", "#00A1F1", "#FFBB00"])
        text(cr, "Arthem 7", cx - 44, H - 52, 22, rgb("#FFFFFF"), family="Segoe UI", shadow=True)

    def draw_w10(self, cr, W, H, eleven=False):
        now = time.localtime()
        if self.locked:
            if eleven:
                text(cr, time.strftime("%H:%M", now), W // 2, int(H * 0.25), 92, rgb("#FFFFFF"), family="Segoe UI", align="center", bold=True, shadow=True)
                text(cr, _date(now), W // 2, int(H * 0.25) + 42, 22, rgb("#FFFFFF"), family="Segoe UI", align="center", shadow=True)
            else:
                text(cr, time.strftime("%H:%M", now), 40, H - 130, 110, rgb("#FFFFFF"), family="Segoe UI Light", shadow=True)
                text(cr, _date(now), 46, H - 80, 34, rgb("#FFFFFF"), family="Segoe UI Light", shadow=True)
            return
        cr.set_source_rgba(0, 0, 0, 0.25 if not eleven else 0.1)
        cr.paint()
        cx, cy = W // 2, int(H * 0.40)
        u = self.selected
        if u:
            s = 190
            self._avatar(cr, u, cx - s // 2, cy - s // 2 - 20, s)
            text(cr, u.display, cx, cy + 118, 34 if not eleven else 28, rgb("#FFFFFF"), family="Segoe UI", align="center",
                 shadow=True, bold=eleven)
        if self.error:
            text(cr, self.error, cx, cy + 215, 15, rgb("#FFFFFF"), family="Segoe UI", align="center", shadow=True)
        # пользователи слева внизу
        for kind, uu, (x, y, w, h) in self.hits:
            if kind == "user":
                if uu is self.selected or self._hov("user", uu.name):
                    cr.set_source_rgba(1, 1, 1, 0.25 if uu is self.selected else 0.12)
                    if eleven:
                        rounded(cr, x, y, w, h, 6)
                    else:
                        cr.rectangle(x, y, w, h)
                    cr.fill()
                self._avatar(cr, uu, x + 8, y + 8, 40)
                text(cr, uu.display, x + 60, y + 34, 15, rgb("#FFFFFF"), family="Segoe UI")
            elif kind == "power":
                if self._hov("power", "shutdown"):
                    cr.set_source_rgba(1, 1, 1, 0.15)
                    rounded(cr, x, y, w, h, 6 if eleven else 0)
                    cr.fill()
                cr.set_source_rgba(1, 1, 1, 1)
                cr.set_line_width(2)
                cr.arc(x + w / 2, y + h / 2 + 1, 10, -math.pi * 0.3, math.pi * 1.3)
                cr.stroke()
                cr.move_to(x + w / 2, y + h / 2 - 12)
                cr.line_to(x + w / 2, y + h / 2)
                cr.stroke()

    def draw_w11(self, cr, W, H):
        self.draw_w10(cr, W, H, eleven=True)

    def draw_mac(self, cr, W, H):
        cr.set_source_rgba(0, 0, 0, 0.12)
        cr.paint()
        now = time.localtime()
        text(cr, time.strftime("%H:%M", now), W - 24, 22, 14, rgb("#FFFFFF"), family="Helvetica Neue", align="right")
        if self.selected:
            u = self.selected
            cx, cy = W // 2, int(H * 0.66)
            s = 96
            self._avatar(cr, u, cx - s // 2, cy - s - 4, s)
            text(cr, u.display, cx, cy + 40, 17, rgb("#FFFFFF"), family="Helvetica Neue", align="center", bold=True, shadow=True)
            if self.error:
                text(cr, self.error, cx, cy + 124, 13, rgb("#FFFFFF"), family="Helvetica Neue", align="center", shadow=True)
            elif len(self.users) > 1:
                text(cr, "Отменить", cx, cy + 128, 12, rgb("#FFFFFF", 0.85), family="Helvetica Neue", align="center")
        for kind, val, (x, y, w, h) in self.hits:
            if kind == "user":
                s = 88
                self._avatar(cr, val, x + (w - s) / 2, y, s)
                text(cr, val.display, x + w / 2, y + s + 26, 14, rgb("#FFFFFF"), family="Helvetica Neue", align="center",
                     bold=self._hov("user", val.name), shadow=True)
            elif kind == "power":
                cx2, cy2 = x + w / 2, y + 22
                cr.set_source_rgba(1, 1, 1, 0.32 if self._hov("power", val) else 0.18)
                cr.arc(cx2, cy2, 20, 0, 2 * math.pi)
                cr.fill()
                cr.set_source_rgba(1, 1, 1, 0.95)
                cr.set_line_width(2)
                if val == "sleep":
                    cr.arc(cx2, cy2, 8, math.pi * 0.25, math.pi * 1.75)
                    cr.stroke()
                elif val == "restart":
                    cr.arc(cx2, cy2, 8, -math.pi * 0.2, math.pi * 1.5)
                    cr.stroke()
                    cr.move_to(cx2 + 2, cy2 - 11)
                    cr.line_to(cx2 + 6, cy2 - 8)
                    cr.line_to(cx2 + 2, cy2 - 5)
                    cr.stroke()
                else:
                    cr.arc(cx2, cy2 + 1, 8, -math.pi * 0.3, math.pi * 1.3)
                    cr.stroke()
                    cr.move_to(cx2, cy2 - 10)
                    cr.line_to(cx2, cy2)
                    cr.stroke()
                text(cr, T[val], cx2, y + 64, 12, rgb("#FFFFFF"), family="Helvetica Neue", align="center", shadow=True)


MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"]
DAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]


def _date(t):
    return f"{DAYS[t.tm_wday].capitalize()}, {t.tm_mday} {MONTHS[t.tm_mon - 1]}"


def main():
    style, bg = load_conf()
    win = Greeter(style, bg)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    win._hide_inputs()
    win.layout()
    if not TEST:
        # курсор-стрелка на корневом окне (иначе после greeter-а — «крестик» X)
        root = Gdk.get_default_root_window()
        root.set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.LEFT_PTR))
    if "--shot" in sys.argv:
        # для проверки: снимок окна и выход
        out = sys.argv[sys.argv.index("--shot") + 1]

        def snap():
            if "--unlock" in sys.argv and win.locked:
                win.locked = False
                win.start_auth(win.selected or win._default_user())
                return True
            alloc = win.get_allocation()
            pb = Gdk.pixbuf_get_from_window(win.get_window(), 0, 0, alloc.width, alloc.height)
            if pb:
                pb.savev(out, "png", [], [])
            Gtk.main_quit()
            return False
        GLib.timeout_add(1500, snap)
    Gtk.main()


if __name__ == "__main__":
    main()
