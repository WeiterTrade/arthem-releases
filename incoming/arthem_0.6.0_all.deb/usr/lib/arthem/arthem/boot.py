"""Экраны загрузки (Plymouth) и входа (LightDM) вместе со стилем.

Меняет их системный помощник /usr/lib/arthem/arthem-root через pkexec. Пароль спрашивается
один раз: при первом запуске помощник ставит правило polkit, и дальше смена идёт молча.
Пересборка загрузочного образа идёт в фоне и только для последнего выбранного стиля."""

import os
import shutil

from . import config, packs, util

HELPER = os.environ.get("ARTHEM_ROOT_HELPER", "/usr/lib/arthem/arthem-root")


def available():
    return os.path.exists(HELPER) and shutil.which("pkexec") is not None


def _has_plymouth():
    return os.path.isdir("/usr/share/plymouth/themes") and (shutil.which("plymouth") or shutil.which("plymouthd"))


def _has_lightdm():
    return os.path.isdir("/etc/lightdm")


def request(style_id, cfg=None):
    cfg = cfg or config.load()
    if not cfg.get("components", {}).get("boot", True) or not available():
        return False
    if style_id == "linux":
        return restore()
    boot, login = _has_plymouth(), _has_lightdm()
    if not (boot or login):
        return False
    cmd = ["pkexec", HELPER, "apply", style_id]
    pk = packs.get(style_id)
    if pk:
        bd = pk.boot_dir()
        if bd:
            cmd += ["--pack-dir", str(bd)]
        lb = pk.login_background()
        if lb:
            cmd += ["--login-bg", str(lb)]
    if not boot:
        cmd.append("--no-boot")
    if not login:
        cmd.append("--no-login")
    util.log("экран загрузки/входа:", " ".join(cmd))
    ok = util.spawn(cmd)
    if ok:
        config.set_state(boot_style=style_id)
    return ok


def restore():
    if not available() or config.load_state().get("boot_style") in (None, "linux"):
        return False
    ok = util.spawn(["pkexec", HELPER, "restore"])
    if ok:
        config.set_state(boot_style="linux")
    return ok
