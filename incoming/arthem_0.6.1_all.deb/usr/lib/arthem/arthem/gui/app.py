"""Главное окно Arthem."""

import os
import shutil
import sys
from pathlib import Path

from .. import __version__, config, core, desktop, hotkeys, packs, styles, util
from . import logo, theme, widgets
from .qt import QT6, QtCore, QtGui, QtWidgets, Qt, exec_, make_app

PKG_PARENT = str(Path(__file__).resolve().parent.parent.parent)

NAV = [
    ("styles", "Стили"),
    ("packs", "Наборы .arthem"),
    ("hotkeys", "Горячие клавиши"),
    ("settings", "Настройки"),
]
NAV_SHORT = {"styles": "Стили", "packs": "Наборы", "hotkeys": "Клавиши", "settings": "Настройки"}

SIZES = {"gallery": (1180, 760), "showcase": (1180, 760), "compact": (540, 830)}


def cli_process(parent, args):
    proc = QtCore.QProcess(parent)
    env = QtCore.QProcessEnvironment.systemEnvironment()
    pp = env.value("PYTHONPATH", "")
    env.insert("PYTHONPATH", PKG_PARENT + (os.pathsep + pp if pp else ""))
    proc.setProcessEnvironment(env)
    proc.setProgram(sys.executable)
    proc.setArguments(["-m", "arthem"] + list(args))
    proc.setProcessChannelMode(QtCore.QProcess.MergedChannels)
    return proc


def _kind(style_id, pk):
    if style_id == "linux":
        return "base"
    return "orig" if style_id in pk else "built"


def _pack_pixmaps(pk):
    out = {}
    for sid, p in pk.items():
        prev = p.preview()
        if prev:
            pm = QtGui.QPixmap(str(prev))
            if not pm.isNull():
                out[sid] = pm
    return out


class MainWindow(QtWidgets.QWidget):
    def __init__(self, page=None, open_file=None):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Arthem")
        self.cfg = config.load()
        self.de = desktop.detect()
        self.de_name = desktop.pretty_name(self.de) if self.de else "Оболочка не определена"
        self.active = core.active_style()
        self.selected = self.active if self.active in styles.STYLES and self.active != "linux" else "w7"
        self.page = page if page in dict(NAV) else "styles"
        self.proc = None
        self.outer = QtWidgets.QVBoxLayout(self)
        self.outer.setContentsMargins(0, 0, 0, 0)
        self.root = None
        self.rebuild(first=True)
        if open_file:
            QtCore.QTimer.singleShot(300, lambda: self.install_pack(open_file))

    # ------------------------------------------------------------ сборка интерфейса

    def rebuild(self, first=False):
        self.cfg = config.load()
        self.t = theme.get(self.cfg.get("ui_theme"))
        self.layout_kind = self.cfg.get("ui_layout", "gallery")
        if self.layout_kind not in SIZES:
            self.layout_kind = "gallery"
        self.pk = packs.list_packs()
        self.pix = _pack_pixmaps(self.pk)
        self.setStyleSheet(theme.stylesheet(self.t))
        self.setWindowIcon(logo.logo_icon(self.t))
        if self.root is not None:
            self.root.setParent(None)
            self.root.deleteLater()
        self.root = QtWidgets.QWidget()
        self.root.setObjectName("Root")
        self.root.setAttribute(Qt.WA_StyledBackground, True)
        self.outer.addWidget(self.root)
        lay = QtWidgets.QVBoxLayout(self.root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        compact = self.layout_kind == "compact"
        self.nav_buttons = {}
        tabs = None
        if compact:
            title = widgets.TitleBar(self.t, self, compact=True)
            lay.addWidget(title)
            tabs = QtWidgets.QFrame()
            tl = QtWidgets.QHBoxLayout(tabs)
            tl.setContentsMargins(18, 12, 18, 0)
            box = QtWidgets.QFrame()
            box.setObjectName("Panel")
            bl = QtWidgets.QHBoxLayout(box)
            bl.setContentsMargins(4, 4, 4, 4)
            bl.setSpacing(4)
            for key, _title in NAV:
                b = QtWidgets.QPushButton(NAV_SHORT[key])
                b.setObjectName("Tab")
                b.setCheckable(True)
                b.clicked.connect(lambda _=False, k=key: self.go(k))
                bl.addWidget(b)
                self.nav_buttons[key] = b
            tl.addWidget(box)
            lay.addWidget(tabs)
            body = QtWidgets.QWidget()
            lay.addWidget(body, 1)
            bodylay = QtWidgets.QVBoxLayout(body)
            bodylay.setContentsMargins(0, 0, 0, 0)
            self.stack = QtWidgets.QStackedWidget()
            bodylay.addWidget(self.stack)
        else:
            title = widgets.TitleBar(self.t, self)
            lay.addWidget(title)
            body = QtWidgets.QWidget()
            lay.addWidget(body, 1)
            hl = QtWidgets.QHBoxLayout(body)
            hl.setContentsMargins(0, 0, 0, 0)
            hl.setSpacing(0)
            hl.addWidget(self._sidebar())
            self.stack = QtWidgets.QStackedWidget()
            hl.addWidget(self.stack, 1)

        self.pages = {
            "styles": self._styles_page(),
            "packs": self._packs_page(),
            "hotkeys": self._hotkeys_page(),
            "settings": self._settings_page(),
        }
        for key, _ in NAV:
            self.stack.addWidget(self.pages[key])
        grip_row = QtWidgets.QHBoxLayout()
        grip_row.setContentsMargins(0, 0, 4, 4)
        grip_row.addStretch(1)
        grip = QtWidgets.QSizeGrip(self.root)
        grip.setFixedSize(14, 14)
        grip_row.addWidget(grip)
        lay.addLayout(grip_row)
        self.go(self.page)
        w, h = SIZES[self.layout_kind]
        if first or self.width() < 200:
            self.resize(w, h)
        else:
            self.resize(w, h)

    def _sidebar(self):
        side = QtWidgets.QFrame()
        side.setObjectName("Side")
        side.setFixedWidth(232)
        sl = QtWidgets.QVBoxLayout(side)
        sl.setContentsMargins(14, 20, 14, 18)
        sl.setSpacing(4)
        for key, title in NAV:
            b = QtWidgets.QPushButton(title)
            b.setObjectName("Nav")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            sl.addWidget(b)
            self.nav_buttons[key] = b
        sl.addStretch(1)
        box = QtWidgets.QFrame()
        box.setObjectName("Panel")
        bl = QtWidgets.QVBoxLayout(box)
        bl.setContentsMargins(14, 12, 14, 12)
        bl.setSpacing(8)
        for label, value, gold in (("Оболочка", self.de_name, False), ("Активный стиль", styles.name(self.active), True)):
            a = QtWidgets.QLabel(label)
            a.setObjectName("Muted")
            a.setStyleSheet("font-size: 12px;")
            b = QtWidgets.QLabel(value)
            b.setWordWrap(True)
            b.setStyleSheet(f"font-weight: 700; color: {self.t['gold_light'] if gold else self.t['text']};")
            bl.addWidget(a)
            bl.addWidget(b)
            if gold:
                self.active_label = b
        sl.addWidget(box)
        return side

    def go(self, key):
        self.page = key
        for k, b in self.nav_buttons.items():
            b.setChecked(k == key)
        idx = [k for k, _ in NAV].index(key)
        self.stack.setCurrentIndex(idx)

    # ------------------------------------------------------------ страница «Стили»

    def _components_row(self, vertical=False):
        box = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(box) if vertical else QtWidgets.QHBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10 if vertical else 18)
        names = [("icons", "Иконки"), ("sounds", "Звуки"), ("cursors", "Курсоры"), ("wallpaper", "Обои"), ("boot", "Загрузка и вход")]
        comp = self.cfg.get("components", {})
        for key, title in names:
            cb = QtWidgets.QCheckBox(title)
            cb.setChecked(comp.get(key, True))
            cb.toggled.connect(lambda on, k=key: config.update(components={k: on}))
            lay.addWidget(cb)
        return box

    def _apply_buttons(self, full_width=False):
        revert = QtWidgets.QPushButton("Вернуть Linux")
        revert.setObjectName("Secondary")
        revert.setCursor(Qt.PointingHandCursor)
        revert.clicked.connect(lambda: self.run_apply("linux"))
        apply = QtWidgets.QPushButton("Применить")
        apply.setObjectName("Primary")
        apply.setCursor(Qt.PointingHandCursor)
        apply.clicked.connect(lambda: self.run_apply(self.selected))
        self.apply_buttons = [apply, revert]
        return apply, revert

    def _styles_page(self):
        self.cards = {}
        if self.layout_kind == "showcase":
            return self._showcase()
        if self.layout_kind == "compact":
            return self._compact()
        return self._gallery()

    def _header(self, title, sub, right=None):
        w = QtWidgets.QWidget()
        hl = QtWidgets.QHBoxLayout(w)
        hl.setContentsMargins(0, 0, 0, 0)
        col = QtWidgets.QVBoxLayout()
        col.setSpacing(4)
        h = QtWidgets.QLabel(title)
        h.setObjectName("H1")
        s = QtWidgets.QLabel(sub)
        s.setObjectName("Muted")
        s.setWordWrap(True)
        col.addWidget(h)
        col.addWidget(s)
        hl.addLayout(col, 1)
        if right:
            hl.addWidget(right, 0, Qt.AlignBottom)
        return w

    def _gallery(self):
        page = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        content = QtWidgets.QWidget()
        cl = QtWidgets.QVBoxLayout(content)
        cl.setContentsMargins(32, 24, 32, 16)
        cl.setSpacing(18)
        chip = QtWidgets.QLabel(f"  ●  Наборов .arthem: {len(self.pk)}  ")
        chip.setStyleSheet(
            f"color: {self.t['light']}; background: {self.t['side']}; border: 1px solid {self.t['border']};"
            f"border-radius: 15px; padding: 6px 10px; font-size: 13px;"
        )
        cl.addWidget(self._header("Выберите стиль", "Панель, меню «Пуск», окна, иконки и звуки меняются сразу.\nНаведите на картинку — откроется меню «Пуск».", chip))
        grid = QtWidgets.QGridLayout()
        grid.setSpacing(18)
        for i, sid in enumerate(styles.ORDER):
            card = widgets.StyleCard(self.t, sid, _kind(sid, self.pk), self.cfg["hotkeys"].get(sid), self.pix.get(sid))
            card.clicked.connect(lambda s=sid: self.select(s))
            grid.addWidget(card, i // 3, i % 3)
            self.cards[sid] = card
        cl.addLayout(grid)
        cl.addStretch(1)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        v.addWidget(scroll, 1)
        bottom = QtWidgets.QFrame()
        bottom.setObjectName("Bottom")
        bl = QtWidgets.QHBoxLayout(bottom)
        bl.setContentsMargins(32, 14, 32, 16)
        bl.setSpacing(16)
        bl.addWidget(self._components_row())
        bl.addStretch(1)
        apply, revert = self._apply_buttons()
        bl.addWidget(revert)
        bl.addWidget(apply)
        v.addWidget(bottom)
        self.select(self.selected)
        return page

    def _showcase(self):
        page = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(page)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        left = QtWidgets.QWidget()
        ll = QtWidgets.QVBoxLayout(left)
        ll.setContentsMargins(28, 22, 28, 22)
        ll.setSpacing(16)
        frame = QtWidgets.QFrame()
        frame.setStyleSheet(f"QFrame {{ border: 1.5px solid {self.t['gold']}; border-radius: 16px; }}")
        fl = QtWidgets.QVBoxLayout(frame)
        fl.setContentsMargins(2, 2, 2, 2)
        self.big = widgets.PreviewView(self.selected, self.pix.get(self.selected), radius=14)
        self.big.setMinimumHeight(380)
        fl.addWidget(self.big)
        ll.addWidget(frame, 1)
        strip = QtWidgets.QGridLayout()
        strip.setSpacing(12)
        for i, sid in enumerate(styles.ORDER):
            c = widgets.Clickable()
            c.setObjectName("Strip")
            cl = QtWidgets.QVBoxLayout(c)
            cl.setContentsMargins(6, 6, 6, 6)
            cl.setSpacing(6)
            pv = widgets.PreviewView(sid, self.pix.get(sid), radius=7, live=False)
            pv.setFixedHeight(74)
            cl.addWidget(pv)
            lab = QtWidgets.QLabel(styles.STYLES[sid]["short"])
            lab.setAlignment(Qt.AlignCenter)
            lab.setStyleSheet("font-size: 12px; font-weight: 700;")
            cl.addWidget(lab)
            c.clicked.connect(lambda s=sid: self.select(s))
            strip.addWidget(c, 0, i)
            self.cards[sid] = c
        ll.addLayout(strip)
        h.addWidget(left, 1)

        side = QtWidgets.QFrame()
        side.setObjectName("Side")
        side.setStyleSheet(f"QFrame#Side {{ border-left: 1px solid {self.t['line']}; border-right: none; border-radius: 0; }}")
        side.setFixedWidth(360)
        sl = QtWidgets.QVBoxLayout(side)
        sl.setContentsMargins(26, 26, 26, 22)
        sl.setSpacing(14)
        cap = QtWidgets.QLabel("СТИЛЬ")
        cap.setObjectName("Muted")
        cap.setStyleSheet("font-size: 11px; font-weight: 700;")
        sl.addWidget(cap)
        self.sc_name = QtWidgets.QLabel()
        self.sc_name.setStyleSheet("font-size: 30px; font-weight: 800;")
        sl.addWidget(self.sc_name)
        self.sc_badge_holder = QtWidgets.QHBoxLayout()
        sl.addLayout(self.sc_badge_holder)
        self.sc_desc = QtWidgets.QLabel()
        self.sc_desc.setWordWrap(True)
        self.sc_desc.setStyleSheet(f"color: {self.t['soft']}; line-height: 150%;")
        sl.addWidget(self.sc_desc)
        sep = QtWidgets.QFrame()
        sep.setObjectName("Sep")
        sl.addWidget(sep)
        wc = QtWidgets.QLabel("Что изменится")
        wc.setStyleSheet(f"color: {self.t['light']}; font-weight: 700;")
        sl.addWidget(wc)
        sl.addWidget(self._components_row(vertical=True))
        keyrow = QtWidgets.QFrame()
        keyrow.setObjectName("Panel")
        kl = QtWidgets.QHBoxLayout(keyrow)
        kl.setContentsMargins(14, 10, 14, 10)
        kk = QtWidgets.QLabel("Горячая клавиша")
        kk.setObjectName("Muted")
        kl.addWidget(kk)
        kl.addStretch(1)
        self.sc_key = widgets.kbd("")
        kl.addWidget(self.sc_key)
        sl.addWidget(keyrow)
        sl.addStretch(1)
        apply, revert = self._apply_buttons()
        sl.addWidget(apply)
        sl.addWidget(revert)
        h.addWidget(side)
        self.select(self.selected)
        return page

    def _compact(self):
        page = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        content = QtWidgets.QWidget()
        cl = QtWidgets.QVBoxLayout(content)
        cl.setContentsMargins(18, 14, 18, 10)
        cl.setSpacing(8)
        status = QtWidgets.QFrame()
        status.setObjectName("Panel")
        stl = QtWidgets.QHBoxLayout(status)
        stl.setContentsMargins(14, 10, 14, 10)
        a = QtWidgets.QLabel("Сейчас:")
        a.setObjectName("Muted")
        stl.addWidget(a)
        self.active_label = QtWidgets.QLabel(styles.name(self.active))
        self.active_label.setObjectName("Gold")
        stl.addWidget(self.active_label)
        stl.addStretch(1)
        d = QtWidgets.QLabel(self.de_name)
        d.setObjectName("Muted")
        stl.addWidget(d)
        cl.addWidget(status)
        for sid in styles.ORDER:
            row = widgets.StyleRow(self.t, sid, _kind(sid, self.pk), self.cfg["hotkeys"].get(sid), self.pix.get(sid))
            row.clicked.connect(lambda s=sid: self.select(s))
            cl.addWidget(row)
            self.cards[sid] = row
        cl.addStretch(1)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        v.addWidget(scroll, 1)
        bottom = QtWidgets.QFrame()
        bottom.setObjectName("Bottom")
        bl = QtWidgets.QVBoxLayout(bottom)
        bl.setContentsMargins(18, 12, 18, 14)
        bl.setSpacing(8)
        apply, revert = self._apply_buttons()
        bl.addWidget(apply)
        bl.addWidget(revert)
        v.addWidget(bottom)
        self.select(self.selected)
        return page

    def select(self, sid):
        self.selected = sid
        for k, c in self.cards.items():
            if hasattr(c, "set_selected"):
                c.set_selected(k == sid)
            else:
                c.setProperty("selected", "true" if k == sid else "false")
                widgets.repolish(c)
        if self.layout_kind == "showcase" and hasattr(self, "big"):
            self.big.set_style(sid, self.pix.get(sid))
            self.sc_name.setText(styles.name(sid))
            while self.sc_badge_holder.count():
                it = self.sc_badge_holder.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
            self.sc_badge_holder.addWidget(widgets.badge(self.t, _kind(sid, self.pk)))
            self.sc_badge_holder.addStretch(1)
            desc = styles.STYLES[sid]["desc"]
            if sid in self.pk:
                desc += f"\n\nНабор: {self.pk[sid].summary()}."
            self.sc_desc.setText(desc)
            key = self.cfg["hotkeys"].get(sid)
            self.sc_key.setText(hotkeys.pretty(key) if key else "не задана")

    # ------------------------------------------------------------ применение

    def run_apply(self, sid):
        if self.proc is not None:
            return
        if not self.de:
            self.message("Оболочка не определена",
                         "Arthem работает в KDE Plasma, GNOME и Cinnamon. Текущую оболочку определить не удалось.", "warn")
            return
        args = ["revert"] if sid == "linux" else ["apply", sid]
        self.proc = cli_process(self, args + ["--quiet"])
        self.proc.finished.connect(lambda code, _st=None, s=sid: self._applied(s, code))
        for b in getattr(self, "apply_buttons", []):
            b.setEnabled(False)
        self.apply_buttons[0].setText("Применяю…")
        self.proc.start()

    def _applied(self, sid, code):
        out = bytes(self.proc.readAll()).decode("utf-8", "replace") if self.proc else ""
        self.proc = None
        for b in getattr(self, "apply_buttons", []):
            b.setEnabled(True)
        self.apply_buttons[0].setText("Применить")
        if code != 0:
            self.message("Не получилось", out.strip() or "Неизвестная ошибка. Подробности — в ~/.local/share/arthem/arthem.log", "warn")
            return
        self.active = core.active_style()
        if hasattr(self, "active_label"):
            self.active_label.setText(styles.name(self.active))
        if config.load_state().get("pending_relogin"):
            self.message("Почти готово", "Установлены расширения для панели. Выйдите из системы и войдите снова — "
                         "Arthem сам доделает оформление.", "info")

    # ------------------------------------------------------------ наборы

    def _packs_page(self):
        page = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(page)
        v.setContentsMargins(32, 24, 32, 20)
        v.setSpacing(16)
        v.addWidget(self._header("Наборы .arthem",
                                 "Оригинальные иконки, звуки, обои и логотипы систем. Набор можно установить из файла "
                                 "или собрать из ISO-образа Windows."))
        row = QtWidgets.QHBoxLayout()
        b1 = QtWidgets.QPushButton("Установить .arthem…")
        b1.setObjectName("Primary")
        b1.clicked.connect(lambda: self.install_pack(None))
        row.addWidget(b1)
        b2 = QtWidgets.QPushButton("Импорт из ISO…")
        b2.setObjectName("Secondary")
        b2.clicked.connect(self.import_iso)
        row.addWidget(b2)
        row.addStretch(1)
        v.addLayout(row)
        listw = QtWidgets.QWidget()
        ll = QtWidgets.QVBoxLayout(listw)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(10)
        for sid in [s for s in styles.ORDER if s != "linux"]:
            fr = QtWidgets.QFrame()
            fr.setObjectName("Card")
            fl = QtWidgets.QHBoxLayout(fr)
            fl.setContentsMargins(10, 10, 16, 10)
            fl.setSpacing(14)
            pv = widgets.PreviewView(sid, self.pix.get(sid), radius=8)
            pv.setFixedSize(120, 72)
            fl.addWidget(pv)
            col = QtWidgets.QVBoxLayout()
            n = QtWidgets.QLabel(styles.name(sid))
            n.setStyleSheet("font-size: 15px; font-weight: 700;")
            col.addWidget(n)
            pk = self.pk.get(sid)
            if pk:
                s = QtWidgets.QLabel(f"{pk.summary()} — {'вшит в пакет' if pk.origin == 'system' else 'добавлен вами'}")
                s.setObjectName("Gold")
            else:
                s = QtWidgets.QLabel("Набора нет — используется встроенный стиль Arthem")
                s.setObjectName("Muted")
            s.setWordWrap(True)
            col.addWidget(s)
            fl.addLayout(col, 1)
            if pk and pk.origin == "user":
                rm = QtWidgets.QPushButton("Удалить")
                rm.clicked.connect(lambda _=False, st=sid: self.remove_pack(st))
                fl.addWidget(rm)
            ll.addWidget(fr)
        ll.addStretch(1)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(listw)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        v.addWidget(scroll, 1)
        return page

    def install_pack(self, path=None):
        if not path:
            path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Набор Arthem", str(Path.home()), "Наборы Arthem (*.arthem);;Все файлы (*)")
            if not path:
                return
        try:
            p = packs.install(path)
        except (packs.PackError, OSError) as exc:
            self.message("Набор не установлен", str(exc), "warn")
            return
        self.message("Готово", f"Набор «{p.title}» установлен. Примените стиль, чтобы увидеть оригинальное оформление.", "info")
        self.page = "packs"
        self.rebuild()

    def remove_pack(self, sid):
        if packs.remove(sid):
            self.rebuild()

    def import_iso(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "ISO-образ Windows", str(Path.home()), "Образы дисков (*.iso *.ISO);;Все файлы (*)")
        if not path:
            return
        dlg = IsoDialog(self.t, path, self)
        exec_(dlg)
        self.page = "packs"
        self.rebuild()

    # ------------------------------------------------------------ клавиши

    def _hotkeys_page(self):
        page = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(page)
        v.setContentsMargins(32, 24, 32, 20)
        v.setSpacing(14)
        v.addWidget(self._header("Горячие клавиши", "Нажмите «Изменить» и введите своё сочетание. Системные и занятые сочетания Arthem не даст выбрать."))
        en = QtWidgets.QCheckBox("Переключать стили горячими клавишами")
        en.setChecked(self.cfg.get("hotkeys_enabled", True))
        en.toggled.connect(self._toggle_hotkeys)
        v.addWidget(en)
        bad = {a: m for a, _s, m in hotkeys.conflicts(self.cfg, de=self.de)} if self.cfg.get("hotkeys_enabled", True) else {}
        rows = [(s, styles.name(s)) for s in styles.ORDER] + [("next", "Следующий стиль по кругу")]
        listw = QtWidgets.QWidget()
        ll = QtWidgets.QVBoxLayout(listw)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(8)
        for action, title in rows:
            fr = QtWidgets.QFrame()
            fr.setObjectName("Panel")
            fl = QtWidgets.QHBoxLayout(fr)
            fl.setContentsMargins(16, 10, 12, 10)
            col = QtWidgets.QVBoxLayout()
            n = QtWidgets.QLabel(title)
            n.setStyleSheet("font-weight: 700;")
            col.addWidget(n)
            if action in bad:
                w = QtWidgets.QLabel(bad[action])
                w.setStyleSheet("color: #FF6B6B; font-size: 12px;")
                w.setWordWrap(True)
                col.addWidget(w)
            fl.addLayout(col, 1)
            seq = self.cfg["hotkeys"].get(action) or ""
            fl.addWidget(widgets.kbd(hotkeys.pretty(seq) if seq else "не задано"))
            ch = QtWidgets.QPushButton("Изменить")
            ch.clicked.connect(lambda _=False, a=action: self.change_key(a))
            fl.addWidget(ch)
            cl = QtWidgets.QPushButton("Убрать")
            cl.clicked.connect(lambda _=False, a=action: self.set_key(a, ""))
            fl.addWidget(cl)
            ll.addWidget(fr)
        ll.addStretch(1)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(listw)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        v.addWidget(scroll, 1)
        reset = QtWidgets.QPushButton("Сбросить по умолчанию")
        reset.setObjectName("Secondary")
        reset.clicked.connect(self.reset_keys)
        r = QtWidgets.QHBoxLayout()
        r.addStretch(1)
        r.addWidget(reset)
        v.addLayout(r)
        return page

    def _toggle_hotkeys(self, on):
        cfg = config.update(hotkeys_enabled=on)
        if on:
            hotkeys.register(cfg, self.de)
        else:
            hotkeys.unregister(self.de)

    def change_key(self, action):
        dlg = widgets.KeyCaptureDialog(self.t, action, self.cfg["hotkeys"].get(action), self.cfg["hotkeys"], self)
        dlg.setStyleSheet(theme.stylesheet(self.t))
        if exec_(dlg) and dlg.result_seq:
            self.set_key(action, dlg.result_seq)

    def set_key(self, action, seq):
        cfg = config.load()
        cfg["hotkeys"][action] = seq
        config.save(cfg)
        hotkeys.register(cfg, self.de)
        self.page = "hotkeys"
        self.rebuild()

    def reset_keys(self):
        cfg = config.load()
        cfg["hotkeys"] = dict(config.DEFAULT_HOTKEYS)
        config.save(cfg)
        hotkeys.register(cfg, self.de)
        self.page = "hotkeys"
        self.rebuild()

    # ------------------------------------------------------------ настройки

    def _settings_page(self):
        page = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(page)
        outer.setContentsMargins(0, 0, 0, 0)
        content = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(content)
        v.setContentsMargins(32, 24, 32, 20)
        v.setSpacing(16)
        v.addWidget(self._header("Настройки", f"Arthem {__version__}"))

        def section(title):
            fr = QtWidgets.QFrame()
            fr.setObjectName("Panel")
            fl = QtWidgets.QVBoxLayout(fr)
            fl.setContentsMargins(18, 14, 18, 16)
            fl.setSpacing(10)
            h = QtWidgets.QLabel(title)
            h.setStyleSheet(f"color: {self.t['light']}; font-weight: 800;")
            fl.addWidget(h)
            v.addWidget(fr)
            return fl

        lay = section("Вид окна")
        grp = QtWidgets.QButtonGroup(page)
        for key, title, sub in (("gallery", "Галерея", "карточки всех стилей (по умолчанию)"),
                                ("showcase", "Витрина", "большое превью и лента"),
                                ("compact", "Компактный", "узкое окно-список")):
            rb = QtWidgets.QRadioButton(f"{title} — {sub}")
            rb.setChecked(self.layout_kind == key)
            grp.addButton(rb)
            rb.toggled.connect(lambda on, k=key: on and self._set_ui(ui_layout=k))
            lay.addWidget(rb)

        lay = section("Цветовая тема")
        grid = QtWidgets.QGridLayout()
        grid.setSpacing(10)
        for i, key in enumerate(theme.ORDER):
            t = theme.THEMES[key]
            b = QtWidgets.QPushButton(t["title"])
            b.setCheckable(True)
            b.setChecked(self.cfg.get("ui_theme") == key)
            b.setCursor(Qt.PointingHandCursor)
            border = t["gold"] if self.cfg.get("ui_theme") == key else t["border"]
            b.setStyleSheet(
                f"QPushButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {t['bg']}, stop:0.55 {t['card']}, stop:1 {t['acc2']});"
                f"color: {t['text']}; border: 2px solid {border}; border-radius: 12px; padding: 16px 10px; font-weight: 800; }}"
            )
            b.clicked.connect(lambda _=False, k=key: self._set_ui(ui_theme=k))
            grid.addWidget(b, i // 3, i % 3)
        lay.addLayout(grid)

        lay = section("Что менять при переключении")
        lay.addWidget(self._components_row(vertical=True))
        snd = QtWidgets.QCheckBox("Мелодия при входе в систему")
        snd.setChecked(self.cfg.get("startup_sound", True))
        snd.toggled.connect(lambda on: config.update(startup_sound=on))
        lay.addWidget(snd)
        tray = QtWidgets.QCheckBox("Значок Arthem в трее (с следующего входа)")
        tray.setChecked(self.cfg.get("tray", True))
        tray.toggled.connect(lambda on: config.update(tray=on))
        lay.addWidget(tray)

        lay = section("Откат")
        info = QtWidgets.QLabel("Вернёт панель, тему, иконки, звуки и обои, которые были до Arthem.")
        info.setObjectName("Muted")
        info.setWordWrap(True)
        lay.addWidget(info)
        rb = QtWidgets.QPushButton("Вернуть обычный Linux")
        rb.setObjectName("Secondary")
        rb.clicked.connect(lambda: self.run_apply("linux"))
        lay.addWidget(rb, 0, Qt.AlignLeft)

        lay = section("О программе")
        about = QtWidgets.QLabel(
            f"Arthem {__version__}. Встроенные стили нарисованы с нуля и не содержат файлов Microsoft или Apple. "
            "Оригинальные ресурсы подключаются только через ваши наборы .arthem.\n"
            "Журнал: ~/.local/share/arthem/arthem.log"
        )
        about.setWordWrap(True)
        about.setObjectName("Muted")
        lay.addWidget(about)
        v.addStretch(1)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        outer.addWidget(scroll)
        return page

    def _set_ui(self, **changes):
        config.update(**changes)
        self.page = "settings"
        QtCore.QTimer.singleShot(0, self.rebuild)

    # ------------------------------------------------------------ сообщения

    def message(self, title, text, level="info"):
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(f"<b>{title}</b>")
        box.setInformativeText(text)
        box.setIcon(QtWidgets.QMessageBox.Warning if level == "warn" else QtWidgets.QMessageBox.Information)
        box.setStyleSheet(theme.stylesheet(self.t))
        exec_(box)


class IsoDialog(QtWidgets.QDialog):
    """Импорт набора из ISO-образа Windows с журналом хода работы."""

    def __init__(self, t, iso, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Импорт из ISO")
        self.setMinimumSize(620, 460)
        self.iso = iso
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(12)
        h = QtWidgets.QLabel("Импорт из ISO")
        h.setObjectName("H2")
        lay.addWidget(h)
        p = QtWidgets.QLabel(Path(iso).name)
        p.setObjectName("Muted")
        lay.addWidget(p)
        self.upscale = QtWidgets.QCheckBox("Увеличить маленькие обои нейросетью (Real-ESRGAN; при первом запуске скачает ~45 МБ)")
        self.upscale.setChecked(True)
        lay.addWidget(self.upscale)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        lay.addWidget(self.log, 1)
        row = QtWidgets.QHBoxLayout()
        row.addStretch(1)
        self.close_btn = QtWidgets.QPushButton("Закрыть")
        self.close_btn.setObjectName("Secondary")
        self.close_btn.clicked.connect(self.reject)
        self.start_btn = QtWidgets.QPushButton("Начать")
        self.start_btn.setObjectName("Primary")
        self.start_btn.clicked.connect(self.start)
        row.addWidget(self.close_btn)
        row.addWidget(self.start_btn)
        lay.addLayout(row)
        self.setStyleSheet(theme.stylesheet(t))
        self.proc = None

    def start(self):
        from .. import boot
        miss = boot.missing_tools()
        if miss and boot.available() and not getattr(self, "_tools_tried", False):
            # недостающие программы ставим сами (пароль администратора спросит система)
            self._tools_tried = True
            self.log.appendPlainText("Не хватает программ: " + ", ".join(miss) + ". Устанавливаю…")
            self.start_btn.setEnabled(False)
            self.close_btn.setEnabled(False)
            self.proc = QtCore.QProcess(self)
            self.proc.setProgram("pkexec")
            self.proc.setArguments([boot.HELPER, "install-tools"])
            self.proc.setProcessChannelMode(QtCore.QProcess.MergedChannels)
            self.proc.readyRead.connect(self._read)
            self.proc.finished.connect(self._tools_done)
            self.proc.start()
            return
        self._start_import()

    def _tools_done(self, code, *_):
        from .. import boot
        miss = boot.missing_tools()
        if miss:
            self.log.appendPlainText(f"\nНе удалось установить: {', '.join(miss)} (код {code}). "
                                     "Проверьте интернет и попробуйте ещё раз.")
            self.start_btn.setEnabled(True)
            self.close_btn.setEnabled(True)
            self._tools_tried = False
            return
        self.log.appendPlainText("\nПрограммы установлены.\n")
        self._start_import()

    def _start_import(self):
        args = ["--iso", self.iso, "--install"]
        if self.upscale.isChecked():
            args += ["--upscale", "--download-esrgan"]
        self.proc = QtCore.QProcess(self)
        env = QtCore.QProcessEnvironment.systemEnvironment()
        pp = env.value("PYTHONPATH", "")
        env.insert("PYTHONPATH", PKG_PARENT + (os.pathsep + pp if pp else ""))
        self.proc.setProcessEnvironment(env)
        self.proc.setProgram(sys.executable)
        self.proc.setArguments(["-m", "arthem.pack"] + args)
        self.proc.setProcessChannelMode(QtCore.QProcess.MergedChannels)
        self.proc.readyRead.connect(self._read)
        self.proc.finished.connect(self._done)
        self.start_btn.setEnabled(False)
        self.close_btn.setEnabled(False)
        self.log.appendPlainText("Запуск…")
        self.proc.start()

    def _read(self):
        data = bytes(self.proc.readAll()).decode("utf-8", "replace")
        self.log.moveCursor(QtGui.QTextCursor.End)
        self.log.insertPlainText(data)
        self.log.moveCursor(QtGui.QTextCursor.End)

    def _done(self, code, *_):
        self.close_btn.setEnabled(True)
        self.log.appendPlainText("\nГотово." if code == 0 else f"\nОшибка (код {code}).")


def main(page=None, open_file=None):
    app = make_app(sys.argv)
    win = MainWindow(page=page, open_file=open_file)
    win.show()
    return exec_(app)
