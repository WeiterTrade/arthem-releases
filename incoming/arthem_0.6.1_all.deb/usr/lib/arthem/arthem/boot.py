"""Экраны загрузки (Plymouth) и входа (LightDM) вместе со стилем.

Меняет их системный помощник /usr/lib/arthem/arthem-root через pkexec. Пароль спрашивается
один раз: при первом запуске помощник ставит правило polkit, и дальше смена идёт молча.
Пересборка загрузочного образа идёт в фоне и только для последнего выбранного стиля."""

import os
import shutil
import subprocess
import sys

from . import config, packs, util

PKG_PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# программы, нужные для импорта из ISO: команда → что показать пользователю
ISO_TOOLS = [
    (("wimlib-imagex", "wimlib"), "wimtools"),
    (("cabextract",), "cabextract"),
    (("wrestool",), "icoutils"),
    (("7z", "7zz", "7za"), "7zip"),
    (("magick", "convert"), "imagemagick"),
    (("xcursorgen",), "xcursorgen"),
]


def missing_tools():
    return [pkg for cmds, pkg in ISO_TOOLS if not any(shutil.which(c) for c in cmds)]


def _launch(args):
    """pkexec должен жить, пока его родитель жив («Refusing to render service to dead parents»).
    Окно и горячие клавиши применяют стиль в коротком процессе, поэтому запускаем отдельный
    фоновый процесс-«держатель»: он ждёт pkexec до конца и пишет итог в журнал."""
    code = f"import sys; sys.path.insert(0, {PKG_PARENT!r}); from arthem import boot; boot._hold(sys.argv[1:])"
    return util.spawn([sys.executable, "-c", code] + list(args))


def _hold(args):
    cmd = ["pkexec", HELPER] + args
    util.log("экран загрузки/входа:", " ".join(cmd))
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    except (OSError, subprocess.TimeoutExpired) as exc:
        util.log("экран загрузки/входа: не запустился:", exc)
        return
    if res.returncode == 0:
        util.log("экран загрузки/входа: готово")
        config.set_state(boot_applied=args[1] if args[0] == "apply" else "linux")
    else:
        util.log(f"экран загрузки/входа: код {res.returncode}", (res.stderr or res.stdout).strip()[-500:])
        if res.returncode in (126, 127):
            util.notify("Arthem", "Экран загрузки и входа не изменён: пароль не введён.")

HELPER = os.environ.get("ARTHEM_ROOT_HELPER", "/usr/lib/arthem/arthem-root")


def available():
    return os.path.exists(HELPER) and shutil.which("pkexec") is not None


def _has_plymouth():
    return os.path.isdir("/usr/share/plymouth/themes") and (shutil.which("plymouth") or shutil.which("plymouthd"))


def _has_lightdm():
    return os.path.isdir("/etc/lightdm")


def request(style_id, cfg=None):
    cfg = cfg or config.load()
    if not cfg.get("components", {}).get("boot", True) or not available():
        return False
    if style_id == "linux":
        return restore()
    boot, login = _has_plymouth(), _has_lightdm()
    if not (boot or login):
        return False
    cmd = ["apply", style_id]
    pk = packs.get(style_id)
    if pk:
        bd = pk.boot_dir()
        if bd:
            cmd += ["--pack-dir", str(bd)]
        lb = pk.login_background()
        if lb:
            cmd += ["--login-bg", str(lb)]
    if not boot:
        cmd.append("--no-boot")
    if not login:
        cmd.append("--no-login")
    return _launch(cmd)


def restore():
    if not available() or config.load_state().get("boot_applied") in (None, "linux"):
        return False
    return _launch(["restore"])


def sync():
    """При входе: если экран загрузки не совпадает с активным стилем (пароль не ввели,
    программа обновилась) — попросить ещё раз."""
    st = config.load_state()
    active = st.get("active")
    if active and active != "linux" and st.get("boot_applied") != active:
        return request(active)
    return False
