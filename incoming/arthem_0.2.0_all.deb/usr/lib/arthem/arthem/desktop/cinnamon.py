"""Cinnamon: панели и апплеты, меню с кнопкой «Пуск», тема GTK, иконки, звуки, обои, кнопки окон."""

import glob
import json
import os
import threading
import time
from pathlib import Path

from .. import paths, resources, styles, util

ARTHEM_MENU = "arthem-menu@arthem"
ARTHEM_MENU_DIRS = [Path("/usr/share/cinnamon/applets") / ARTHEM_MENU, paths.XDG_DATA / "cinnamon" / "applets" / ARTHEM_MENU]


def menu_uuid():
    """Своё меню Arthem, если оно установлено; иначе стандартное меню Cinnamon."""
    return ARTHEM_MENU if any((d / "applet.js").is_file() for d in ARTHEM_MENU_DIRS) else "menu@cinnamon.org"


def write_menu_conf(style_id, res):
    """Настройки для апплета меню: раскладка и картинки. Апплет следит за файлом и перестраивается."""
    conf = {
        "layout": style_id,
        "start": str(res.start_icon) if res.start_icon else None,
        "accent": styles.get(style_id).get("accent"),
    }
    pk = res.pack
    if pk and pk.ui("user.png"):
        conf["user_pic"] = str(pk.ui("user.png"))
    path = paths.DATA_DIR / "cinnamon-menu.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(conf, ensure_ascii=False, indent=1), encoding="utf-8")


TRAY = [
    "systray@cinnamon.org",
    "xapp-status@cinnamon.org",
    "notifications@cinnamon.org",
    "removable-drives@cinnamon.org",
    "keyboard@cinnamon.org",
    "network@cinnamon.org",
    "sound@cinnamon.org",
    "power@cinnamon.org",
    "calendar@cinnamon.org",
]


def _layout(style_id):
    """Список (панель, зона, uuid)."""
    menu = menu_uuid()
    if style_id == "mac":
        items = [(1, "left", menu)]
        items += [(1, "right", u) for u in TRAY]
        items += [(2, "center", "grouped-window-list@cinnamon.org")]
        return items
    st = styles.get(style_id)
    zone = "center" if st["panel"]["center"] else "left"
    winlist = "window-list@cinnamon.org" if st["panel"]["labels"] else "grouped-window-list@cinnamon.org"
    items = [(1, zone, menu), (1, zone, winlist)]
    items += [(1, "right", u) for u in TRAY]
    if style_id != "xp":
        items.append((1, "right", "show-desktop@cinnamon.org"))
    return items


def _parse_applets(values):
    ids = {}
    max_id = 0
    for v in values:
        parts = v.split(":")
        if len(parts) >= 5:
            uuid, inst = parts[3], parts[4]
            try:
                n = int(inst)
            except ValueError:
                continue
            max_id = max(max_id, n)
            ids.setdefault(uuid, n)
    return ids, max_id


def spices_dirs():
    return [
        paths.XDG_CONFIG / "cinnamon" / "spices",
        paths.HOME / ".cinnamon" / "configs",
    ]


class Cinnamon:
    name = "cinnamon"

    def apply(self, style_id, cfg, backup):
        st = styles.get(style_id)
        res = resources.Resources(style_id, cfg, backup)

        iface = "org.cinnamon.desktop.interface"
        backup.set_gs(iface, "gtk-theme", util.gv_str(res.gtk_theme))
        if res.icon_theme:
            backup.set_gs(iface, "icon-theme", util.gv_str(res.icon_theme))
        if res.cursor_theme:
            backup.set_gs(iface, "cursor-theme", util.gv_str(res.cursor_theme))
        # Чтобы GTK4-программы тоже подхватили тему
        backup.set_gs("org.gnome.desktop.interface", "gtk-theme", util.gv_str(res.gtk_theme))
        if res.icon_theme:
            backup.set_gs("org.gnome.desktop.interface", "icon-theme", util.gv_str(res.icon_theme))

        layout = "close,minimize,maximize:" if st["buttons"] == "left" else ":minimize,maximize,close"
        backup.set_gs("org.cinnamon.desktop.wm.preferences", "button-layout", util.gv_str(layout))

        if res.wallpaper:
            backup.set_gs("org.cinnamon.desktop.background", "picture-uri", util.gv_str(Path(res.wallpaper).as_uri()))
            backup.set_gs("org.cinnamon.desktop.background", "picture-options", "'zoom'")

        if res.sound_theme:
            for schema in ("org.cinnamon.desktop.sound", "org.gnome.desktop.sound"):
                backup.set_gs(schema, "theme-name", util.gv_str(res.sound_theme))
                backup.set_gs(schema, "event-sounds", "true")
        if res.startup_sound and util.gs_has("org.cinnamon.sounds", "login-file"):
            backup.set_gs("org.cinnamon.sounds", "login-file", util.gv_str(str(res.startup_sound)))
            backup.set_gs("org.cinnamon.sounds", "login-enabled", "true")

        resources.write_gtk4_css(style_id, backup)
        write_menu_conf(style_id, res)
        self._panels(style_id, backup)
        if menu_uuid() != ARTHEM_MENU:
            self._menu_icon_later(res.start_icon, backup)
        return {"relogin": False, "resources": res.describe()}

    def _panels(self, style_id, backup):
        st = styles.get(style_id)
        current = util.parse_strv(util.gs_get("org.cinnamon", "enabled-applets"))
        known, max_id = _parse_applets(current)
        used = set()
        out = []
        order = {}
        for panel, zone, uuid in _layout(style_id):
            if uuid in known and known[uuid] not in used:
                inst = known[uuid]
            else:
                max_id += 1
                inst = max_id
            used.add(inst)
            pos = order.get((panel, zone), 0)
            order[(panel, zone)] = pos + 1
            out.append(f"panel{panel}:{zone}:{pos}:{uuid}:{inst}")

        if style_id == "mac":
            panels = ["1:0:top", "2:0:bottom"]
            heights = ["1:28", "2:52"]
        else:
            panels = ["1:0:bottom"]
            heights = [f"1:{st['panel']['height']}"]
        backup.set_gs("org.cinnamon", "panels-enabled", util.gv_strv(panels))
        backup.set_gs("org.cinnamon", "panels-height", util.gv_strv(heights))
        backup.set_gs("org.cinnamon", "enabled-applets", util.gv_strv(out))


    def _edit_menu_json(self, start_icon, backup):
        changed = False
        for base in spices_dirs():
            for f in glob.glob(str(base / "menu@cinnamon.org" / "*.json")):
                try:
                    with open(f, encoding="utf-8") as fh:
                        data = json.load(fh)
                except (OSError, ValueError):
                    continue
                backup.record_file(f)
                for key, val in (("menu-custom", True), ("menu-icon", str(start_icon)), ("menu-label", "")):
                    if key in data and isinstance(data[key], dict):
                        data[key]["value"] = val
                with open(f, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, indent=4)
                changed = True
        return changed

    def _menu_icon_later(self, start_icon, backup):
        if not start_icon:
            return
        if self._edit_menu_json(start_icon, backup):
            return
        # Файл настроек апплета появляется через секунду-другую после пересборки панели.
        def worker():
            for _ in range(10):
                time.sleep(1)
                if self._edit_menu_json(start_icon, backup):
                    return
        t = threading.Thread(target=worker, daemon=False)
        t.start()
        t.join(12)

    def revert(self, backup):
        return {"errors": backup.restore()}

    def reload(self):
        pass
