"""Тема оболочки Cinnamon для каждого стиля: панель, кнопки окон, подписи и значки на панели.

Тема создаётся в ~/.local/share/themes/Arthem-<стиль>-Cinnamon и подключает (@import) исходную тему
пользователя — меню, календарь и уведомления остаются как были, меняется только панель.
"""

from pathlib import Path

from .. import paths

SYSTEM_DEFAULT = Path("/usr/share/cinnamon/theme/cinnamon.css")


def find_theme_css(name):
    if not name:
        return SYSTEM_DEFAULT if SYSTEM_DEFAULT.is_file() else None
    for base in (paths.HOME / ".themes", paths.XDG_DATA / "themes", Path("/usr/local/share/themes"), Path("/usr/share/themes")):
        css = base / name / "cinnamon" / "cinnamon.css"
        if css.is_file():
            return css
    return SYSTEM_DEFAULT if SYSTEM_DEFAULT.is_file() else None


def theme_name(style_id):
    return {"xp": "Arthem-XP-Cinnamon", "w7": "Arthem-7-Cinnamon", "w10": "Arthem-10-Cinnamon",
            "w11": "Arthem-11-Cinnamon", "mac": "Arthem-Mac-Cinnamon"}[style_id]


# Общие селекторы списков окон (обычный и сгруппированный)
ITEM = ".window-list-item-box, .grouped-window-list-item-box"
ITEM_HOVER = ".window-list-item-box:hover, .grouped-window-list-item-box:hover"
ITEM_ACTIVE = (".window-list-item-box:active, .window-list-item-box:checked, .window-list-item-box:focus, "
               ".grouped-window-list-item-box:active, .grouped-window-list-item-box:checked, .grouped-window-list-item-box:focus")


def _reset(sel):
    """Сброс того, что сторонние темы (Mint-Y, Arc, Yaru…) рисуют на кнопках панели.
    Идёт раньше наших правил, поэтому наши состояния его перекрывают."""
    targets = []
    for cls in ("applet-box", "window-list-item-box", "grouped-window-list-item-box"):
        for variant in ("", ".bottom", ".top", ".running", ".focused"):
            for state in ("", ":hover", ":checked", ":active", ":focus", ":highlight"):
                targets.append(f"{sel} .{cls}{variant}{state}")
    return ",\n".join(targets) + """ {
  background-color: transparent;
  background-gradient-direction: none;
  background-image: none;
  border-image: none;
  box-shadow: none;
  border: none;
}
"""


def _panel_text(sel, color):
    return _reset(sel) + f"""
{sel} .applet-label, {sel} .window-list-item-label, {sel} .grouped-window-list-item-label,
{sel} .applet-box, {sel} StLabel {{ color: {color}; }}
{sel} .applet-icon, {sel} .system-status-icon, {sel} .applet-box StIcon {{ color: {color}; }}
"""


def css(style_id):
    if style_id == "xp":
        return """
.panel-bottom, .panel-top {
  background-color: #245EDB;
  background-gradient-direction: vertical;
  background-gradient-start: #3D7BEA;
  background-gradient-end: #1941A5;
  border-top: 1px solid #5A8EF0;
  box-shadow: none;
  border-image: none;
  background-image: none;
  padding: 0px;
}
""" + _panel_text(".panel-bottom", "#FFFFFF") + f"""
.panel-bottom .applet-box:hover {{ background-color: rgba(255,255,255,0.15); }}
.panel-bottom .window-list-item-box {{
  background-gradient-direction: vertical;
  background-gradient-start: #4B92F7;
  background-gradient-end: #3478EC;
  border: 1px solid #1B4DB8;
  border-radius: 3px;
  margin: 3px 2px;
  padding: 0px 8px;
  min-width: 160px;
  box-shadow: none;
}}
.panel-bottom .window-list-item-box:hover {{
  background-gradient-start: #5FA2FF;
  background-gradient-end: #3F86F2;
}}
.panel-bottom .window-list-item-box:active, .panel-bottom .window-list-item-box:checked,
.panel-bottom .window-list-item-box:focus {{
  background-gradient-start: #1E52B7;
  background-gradient-end: #2A63CC;
  border: 1px solid #10388A;
}}
/* Трей с часами — отдельный голубой блок, как в Luna */
.panel-bottom #panelRight, .panel-bottom .panelRight {{
  background-gradient-direction: vertical;
  background-gradient-start: #1AA0F0;
  background-gradient-end: #0B7FD6;
  border-left: 1px solid #0A5AB8;
  box-shadow: inset 1px 0px 0px rgba(255,255,255,0.35);
  padding: 0px 8px;
}}
"""
    if style_id == "w7":
        return """
.panel-bottom, .panel-top {
  background-color: rgba(30,53,80,0.9);
  background-gradient-direction: vertical;
  background-gradient-start: rgba(70,110,150,0.86);
  background-gradient-end: rgba(15,30,50,0.94);
  border-top: 1px solid rgba(255,255,255,0.32);
  box-shadow: none;
  border-image: none;
  background-image: none;
}
""" + _panel_text(".panel-bottom", "#FFFFFF") + f"""
.panel-bottom .applet-box:hover {{ background-color: rgba(255,255,255,0.12); border-radius: 3px; }}
.panel-bottom {ITEM} {{ border-radius: 4px; margin: 2px 1px; padding: 0px 10px; border: 1px solid transparent; }}
.panel-bottom {ITEM_HOVER} {{
  background-gradient-direction: vertical;
  background-gradient-start: rgba(255,255,255,0.28);
  background-gradient-end: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.45);
}}
.panel-bottom .grouped-window-list-item-box:focus, .panel-bottom .grouped-window-list-item-box:active,
.panel-bottom .grouped-window-list-item-box:checked {{
  background-gradient-direction: vertical;
  background-gradient-start: rgba(255,255,255,0.22);
  background-gradient-end: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.35);
}}
"""
    if style_id == "w10":
        return """
.panel-bottom, .panel-top {
  background-color: rgba(16,19,24,0.98);
  background-gradient-direction: vertical;
  background-gradient-start: rgba(16,19,24,0.98);
  background-gradient-end: rgba(16,19,24,0.98);
  border-top: none;
  box-shadow: none;
  border-image: none;
  background-image: none;
}
""" + _panel_text(".panel-bottom", "#FFFFFF") + f"""
.panel-bottom .applet-box:hover {{ background-color: rgba(255,255,255,0.10); border-radius: 0px; }}
.panel-bottom {ITEM} {{ border-radius: 0px; margin: 0px; padding: 0px 12px; border: none; border-bottom: 2px solid transparent; }}
.panel-bottom {ITEM_HOVER} {{ background-color: rgba(255,255,255,0.10); }}
.panel-bottom .grouped-window-list-item-box:focus, .panel-bottom .grouped-window-list-item-box:active,
.panel-bottom .grouped-window-list-item-box:checked {{
  background-color: rgba(255,255,255,0.14);
  border-bottom: 2px solid #4DA8FF;
}}
.panel-bottom .grouped-window-list-item-box {{ border-bottom: 2px solid rgba(77,168,255,0.0); }}
"""
    if style_id == "w11":
        return """
.panel-bottom, .panel-top {
  background-color: rgba(238,242,247,0.94);
  background-gradient-direction: vertical;
  background-gradient-start: rgba(238,242,247,0.94);
  background-gradient-end: rgba(238,242,247,0.94);
  border-top: 1px solid #D2D9E3;
  box-shadow: none;
  border-image: none;
  background-image: none;
}
""" + _panel_text(".panel-bottom", "#1A1A1A") + f"""
.panel-bottom .applet-box:hover {{ background-color: rgba(255,255,255,0.75); border-radius: 6px; }}
.panel-bottom {ITEM} {{ border-radius: 6px; margin: 4px 2px; padding: 0px 8px; border: none; border-bottom: 3px solid transparent; }}
.panel-bottom {ITEM_HOVER} {{ background-color: rgba(255,255,255,0.75); }}
.panel-bottom .grouped-window-list-item-box:focus, .panel-bottom .grouped-window-list-item-box:active,
.panel-bottom .grouped-window-list-item-box:checked {{
  background-color: rgba(255,255,255,0.85);
  border-bottom: 3px solid #005FB8;
}}
"""
    # macOS: строка меню сверху, «док» снизу
    return """
.panel-top {
  background-color: rgba(246,246,246,0.88);
  background-gradient-direction: vertical;
  background-gradient-start: rgba(246,246,246,0.88);
  background-gradient-end: rgba(246,246,246,0.88);
  border-bottom: 1px solid rgba(0,0,0,0.08);
  border-top: none;
  box-shadow: none;
  border-image: none;
  background-image: none;
}
""" + _panel_text(".panel-top", "#1D1D1F") + """
.panel-top .applet-box:hover { background-color: rgba(0,0,0,0.08); border-radius: 4px; }
.panel-bottom {
  background-color: rgba(255,255,255,0.3);
  background-gradient-direction: vertical;
  background-gradient-start: rgba(255,255,255,0.62);
  background-gradient-end: rgba(255,255,255,0.45);
  border-top: 1px solid rgba(255,255,255,0.55);
  box-shadow: none;
  border-image: none;
  background-image: none;
}
""" + _panel_text(".panel-bottom", "#1D1D1F") + f"""
.panel-bottom {ITEM} {{ border-radius: 10px; margin: 4px 3px; padding: 0px 6px; border: none; }}
.panel-bottom {ITEM_HOVER} {{ background-color: rgba(255,255,255,0.45); }}
.panel-bottom .grouped-window-list-item-box:focus, .panel-bottom .grouped-window-list-item-box:active,
.panel-bottom .grouped-window-list-item-box:checked {{ border-bottom: 3px solid rgba(29,29,31,0.55); }}
"""


def boost(text):
    """Темы Cinnamon задают цвет панели правилом #panel — оно сильнее класса.
    Пишем свои правила как #panel.panel-bottom, чтобы они всегда побеждали."""
    return text.replace(".panel-bottom", "#panel.panel-bottom").replace(".panel-top", "#panel.panel-top")


def write_theme(style_id, base_css, backup):
    """Создаёт тему и возвращает её имя."""
    name = theme_name(style_id)
    root = paths.XDG_DATA / "themes" / name
    target = root / "cinnamon" / "cinnamon.css"
    target.parent.mkdir(parents=True, exist_ok=True)
    head = f'/* Arthem: панель «{style_id}». Остальное — из исходной темы. */\n'
    if base_css:
        head += f'@import url("{Path(base_css).as_uri()}");\n'
    target.write_text(head + boost(css(style_id)), encoding="utf-8")
    backup.add_created(str(root))
    return name
