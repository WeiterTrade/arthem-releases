"""Мелкие помощники: запуск команд, журнал, уведомления, gsettings."""

import datetime
import os
import shutil
import subprocess
import sys

from . import paths

_DRY = os.environ.get("ARTHEM_DRY_RUN") == "1"
_VERBOSE = os.environ.get("ARTHEM_VERBOSE") == "1"


def log(*parts):
    line = " ".join(str(p) for p in parts)
    stamp = datetime.datetime.now().strftime("%H:%M:%S")
    try:
        paths.DATA_DIR.mkdir(parents=True, exist_ok=True)
        with open(paths.LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(f"{stamp} {line}\n")
    except OSError:
        pass
    if _VERBOSE:
        print(line, file=sys.stderr)


def info(*parts):
    line = " ".join(str(p) for p in parts)
    log(line)
    print(line)


def have(cmd):
    return shutil.which(cmd) is not None


def first_cmd(*cmds):
    for c in cmds:
        if have(c):
            return c
    return None


def run(cmd, check=False, timeout=60, env=None, input_text=None, quiet=False):
    """Запускает команду. Возвращает CompletedProcess или None, если программы нет."""
    if not cmd:
        return None
    if not have(cmd[0]) and not os.path.isabs(cmd[0]):
        if not quiet:
            log("нет программы:", cmd[0])
        return None
    if _DRY:
        log("[dry-run]", " ".join(cmd))
        return subprocess.CompletedProcess(cmd, 0, "", "")
    full_env = None
    if env:
        full_env = dict(os.environ)
        full_env.update(env)
    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=full_env,
            input=input_text,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        log("ошибка запуска", " ".join(cmd), exc)
        return None
    if res.returncode != 0 and not quiet:
        log("код", res.returncode, ":", " ".join(cmd), "|", (res.stderr or "").strip()[:300])
    if check and res.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)}: {res.stderr.strip()}")
    return res


def spawn(cmd):
    """Запуск в фоне, без ожидания (например, перезапуск plasmashell)."""
    if not have(cmd[0]):
        return False
    if _DRY:
        log("[dry-run spawn]", " ".join(cmd))
        return True
    try:
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        return True
    except OSError:
        return False


def notify(title, body="", icon="arthem"):
    log("уведомление:", title, body)
    if have("notify-send"):
        run(["notify-send", "-a", "Arthem", "-i", icon, title, body], quiet=True)


def play_sound(path):
    if not path or not os.path.exists(path):
        return False
    for cmd in (
        ["pw-play", path],
        ["paplay", path],
        ["canberra-gtk-play", "-f", path],
        ["aplay", "-q", path],
    ):
        if have(cmd[0]):
            return spawn(cmd)
    return False


# ---------- gsettings ----------

_schema_cache = {}
_keys_cache = {}


def _gs_base(schemadir=None):
    cmd = ["gsettings"]
    if schemadir:
        cmd += ["--schemadir", str(schemadir)]
    return cmd


def gs_schemas(schemadir=None):
    key = str(schemadir or "")
    if key not in _schema_cache:
        res = run(_gs_base(schemadir) + ["list-schemas"], quiet=True)
        _schema_cache[key] = set(res.stdout.split()) if res and res.returncode == 0 else set()
        if schemadir:
            res2 = run(_gs_base(schemadir) + ["list-relocatable-schemas"], quiet=True)
            if res2 and res2.returncode == 0:
                _schema_cache[key] |= set(res2.stdout.split())
    return _schema_cache[key]


def gs_has(schema, key=None, schemadir=None):
    base_schema = schema.split(":", 1)[0]
    if not have("gsettings"):
        return False
    if ":" not in schema and base_schema not in gs_schemas(schemadir):
        return False
    if key is None:
        return True
    ck = (schema, str(schemadir or ""))
    if ck not in _keys_cache:
        res = run(_gs_base(schemadir) + ["list-keys", schema], quiet=True)
        _keys_cache[ck] = set(res.stdout.split()) if res and res.returncode == 0 else set()
    return key in _keys_cache[ck]


def gs_get(schema, key, schemadir=None):
    res = run(_gs_base(schemadir) + ["get", schema, key], quiet=True)
    if res and res.returncode == 0:
        return res.stdout.strip()
    return None


def gs_set_raw(schema, key, value, schemadir=None):
    res = run(_gs_base(schemadir) + ["set", schema, key, value])
    return bool(res and res.returncode == 0)


def gv_str(s):
    """Строка в формате GVariant."""
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"


def gv_strv(items):
    return "[" + ", ".join(gv_str(i) for i in items) + "]"


def parse_strv(text):
    """Разбор ответа gsettings вида ['a', 'b'] или @as []."""
    if not text:
        return []
    text = text.strip()
    if text.startswith("@as"):
        text = text[3:].strip()
    try:
        import ast

        val = ast.literal_eval(text)
        if isinstance(val, (list, tuple)):
            return [str(v) for v in val]
    except (ValueError, SyntaxError):
        pass
    return []


def parse_gv_string(text):
    if text is None:
        return None
    text = text.strip()
    try:
        import ast

        val = ast.literal_eval(text)
        return val if isinstance(val, str) else str(val)
    except (ValueError, SyntaxError):
        return text.strip("'")


def reset_caches():
    _schema_cache.clear()
    _keys_cache.clear()
