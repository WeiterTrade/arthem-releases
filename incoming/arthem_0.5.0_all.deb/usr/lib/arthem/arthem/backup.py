"""«Ленивая» резервная копия: перед первым изменением каждой настройки запоминаем исходное значение.

Так откат возвращает ровно то, что было до Arthem, сколько бы раз ни переключались стили.
"""

import json
import os
import shutil
from pathlib import Path

from . import paths, util

INDEX = "backup.json"


class Backup:
    def __init__(self):
        self.dir = paths.BACKUP_DIR
        self.index_path = self.dir / INDEX
        self.data = {"gsettings": [], "files": [], "created": []}
        try:
            with open(self.index_path, encoding="utf-8") as fh:
                loaded = json.load(fh)
            for k in self.data:
                self.data[k] = loaded.get(k, [])
        except (OSError, ValueError):
            pass

    # ---------- запись ----------

    def exists(self):
        return any(self.data[k] for k in self.data)

    def save(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        tmp = self.index_path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.data, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, self.index_path)

    def _gs_recorded(self, schema, key, schemadir):
        sd = str(schemadir or "")
        return any(
            e["schema"] == schema and e["key"] == key and e.get("schemadir", "") == sd
            for e in self.data["gsettings"]
        )

    def record_gs(self, schema, key, schemadir=None):
        if self._gs_recorded(schema, key, schemadir):
            return
        value = util.gs_get(schema, key, schemadir)
        self.data["gsettings"].append(
            {"schema": schema, "key": key, "schemadir": str(schemadir or ""), "value": value}
        )
        self.save()

    def set_gs(self, schema, key, value, schemadir=None):
        """Изменить gsettings-ключ с записью исходного значения. Пропускает несуществующие ключи."""
        if not util.gs_has(schema, key, schemadir):
            util.log("нет ключа", schema, key)
            return False
        self.record_gs(schema, key, schemadir)
        return util.gs_set_raw(schema, key, value, schemadir)

    def record_file(self, path):
        path = str(Path(path).expanduser())
        if any(e["path"] == path for e in self.data["files"]):
            return
        stored = None
        if os.path.lexists(path) and os.path.isfile(path):
            store_dir = self.dir / "files"
            store_dir.mkdir(parents=True, exist_ok=True)
            stored = f"files/{len(self.data['files']):04d}_{os.path.basename(path)}"
            shutil.copy2(path, self.dir / stored)
        self.data["files"].append({"path": path, "stored": stored})
        self.save()

    def add_created(self, path):
        path = str(path)
        if path not in self.data["created"]:
            self.data["created"].append(path)
            self.save()

    # ---------- откат ----------

    def restore(self):
        errors = 0
        for e in reversed(self.data["gsettings"]):
            sd = e.get("schemadir") or None
            if e.get("value") is None:
                res = util.run(
                    (["gsettings", "--schemadir", sd] if sd else ["gsettings"]) + ["reset", e["schema"], e["key"]],
                    quiet=True,
                )
                ok = bool(res and res.returncode == 0)
            else:
                ok = util.gs_set_raw(e["schema"], e["key"], e["value"], sd)
            errors += 0 if ok else 1
        for e in reversed(self.data["files"]):
            target = e["path"]
            try:
                if e.get("stored"):
                    Path(target).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(self.dir / e["stored"], target)
                elif os.path.lexists(target):
                    os.remove(target)
            except OSError as exc:
                util.log("не удалось вернуть файл", target, exc)
                errors += 1
        for p in reversed(self.data["created"]):
            try:
                if os.path.islink(p) or os.path.isfile(p):
                    os.remove(p)
                elif os.path.isdir(p):
                    shutil.rmtree(p)
            except OSError:
                errors += 1
        return errors

    def clear(self):
        shutil.rmtree(self.dir, ignore_errors=True)
        self.data = {"gsettings": [], "files": [], "created": []}
