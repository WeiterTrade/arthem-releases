"""Наборы тем .arthem.

Формат: ZIP-архив с файлом manifest.json в корне.

    manifest.json   {"format": "arthem", "version": 1, "style": "w7", "title": "...", ...}
    preview.png     мини-рабочий стол для карточки (необязательно)
    wallpapers/     обои; manifest["wallpaper"] — обои по умолчанию
    sounds/         звуковая тема freedesktop (index.theme + stereo/*.wav|oga)
    icons/          тема иконок freedesktop (index.theme + папки размеров)
    cursors/        тема курсоров X11 (index.theme + cursors/)
    ui/             картинки интерфейса: start.png (кнопка «Пуск») и т.п.
    boot/           ресурсы загрузочного экрана (logo.png, frames/)
    fonts/          шрифты (если сборщик набора их положил)

Системные наборы (вшитые при сборке) лежат в /usr/share/arthem/packs/<стиль>/,
пользовательские — в ~/.local/share/arthem/packs/<стиль>/. Пользовательский набор
главнее, если он новее.
"""

import json
import os
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from . import paths, styles, util

FORMAT = "arthem"
FORMAT_VERSION = 1
MAX_FILES = 50000
MAX_TOTAL = 4 * 1024 ** 3  # 4 ГБ распакованного содержимого


class PackError(Exception):
    pass


class Pack:
    def __init__(self, root, manifest, origin):
        self.root = Path(root)
        self.manifest = manifest
        self.origin = origin  # "system" | "user"

    @property
    def style(self):
        return self.manifest.get("style")

    @property
    def title(self):
        return self.manifest.get("title") or styles.name(self.style)

    @property
    def created(self):
        return self.manifest.get("created", "")

    def path(self, rel):
        if not rel:
            return None
        p = (self.root / rel).resolve()
        try:
            p.relative_to(self.root.resolve())
        except ValueError:
            return None
        return p if p.exists() else None

    def wallpaper(self):
        p = self.path(self.manifest.get("wallpaper"))
        if p:
            return p
        wdir = self.root / "wallpapers"
        if wdir.is_dir():
            files = sorted(f for f in wdir.iterdir() if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".bmp", ".webp"))
            if files:
                return files[0]
        return None

    def _theme_dir(self, sub):
        d = self.root / sub
        return d if (d / "index.theme").is_file() else None

    def icons_dir(self):
        return self._theme_dir("icons")

    def sounds_dir(self):
        return self._theme_dir("sounds")

    def cursors_dir(self):
        return self._theme_dir("cursors")

    def preview(self):
        return self.path(self.manifest.get("preview") or "preview.png")

    def ui(self, name):
        return self.path(f"ui/{name}")

    def startup_sound(self):
        rel = (self.manifest.get("sounds") or {}).get("startup") if isinstance(self.manifest.get("sounds"), dict) else None
        p = self.path(rel) if rel else None
        if p:
            return p
        sd = self.sounds_dir()
        if sd:
            for name in ("system-ready", "desktop-login"):
                for ext in (".wav", ".oga", ".ogg"):
                    cand = sd / "stereo" / (name + ext)
                    if cand.is_file():
                        return cand
        return None

    def summary(self):
        src = self.manifest.get("source") or {}
        parts = [src.get("os") or self.title]
        if src.get("build"):
            parts.append(f"сборка {src['build']}")
        if src.get("lang"):
            parts.append(src["lang"])
        return ", ".join(parts)


def _load_dir(d, origin):
    mf = Path(d) / "manifest.json"
    try:
        with open(mf, encoding="utf-8") as fh:
            manifest = json.load(fh)
    except (OSError, ValueError):
        return None
    if manifest.get("format") != FORMAT or manifest.get("style") not in styles.STYLES:
        return None
    return Pack(d, manifest, origin)


def list_packs():
    """Возвращает {стиль: Pack} с учётом приоритета пользовательских наборов."""
    found = {}
    for base, origin in ((paths.SYS_PACKS, "system"), (paths.USER_PACKS, "user")):
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            if not d.is_dir():
                continue
            pack = _load_dir(d, origin)
            if not pack:
                continue
            prev = found.get(pack.style)
            if prev is None or origin == "user" or pack.created >= prev.created:
                found[pack.style] = pack
    return found


def get(style_id):
    return list_packs().get(style_id)


def read_manifest(archive):
    with zipfile.ZipFile(archive) as zf:
        try:
            with zf.open("manifest.json") as fh:
                manifest = json.load(fh)
        except KeyError:
            raise PackError("В архиве нет manifest.json — это не набор Arthem.")
    _check_manifest(manifest)
    return manifest


def _check_manifest(manifest):
    if manifest.get("format") != FORMAT:
        raise PackError("Файл не является набором Arthem (format != arthem).")
    if int(manifest.get("version", 0)) > FORMAT_VERSION:
        raise PackError("Набор сделан более новой версией Arthem. Обновите программу.")
    if manifest.get("style") not in styles.WINDOWS_STYLES + ("mac",):
        raise PackError(f"Неизвестный стиль в наборе: {manifest.get('style')}")


def _safe_members(zf):
    total = 0
    members = zf.infolist()
    if len(members) > MAX_FILES:
        raise PackError("Слишком много файлов в наборе.")
    for m in members:
        name = m.filename
        pp = PurePosixPath(name)
        bad = (
            not pp.parts
            or pp.is_absolute()
            or ".." in pp.parts
            or "\\" in name
            or ":" in pp.parts[0]
        )
        if bad:
            raise PackError(f"Недопустимый путь в архиве: {name}")
        mode = (m.external_attr >> 16) & 0o170000
        if mode == stat.S_IFLNK:
            raise PackError(f"Ссылки внутри набора запрещены: {name}")
        total += m.file_size
        if total > MAX_TOTAL:
            raise PackError("Набор слишком большой.")
    return members


def extract(archive, dest_parent, style=None):
    """Распаковывает набор в dest_parent/<style> атомарно. Возвращает Pack."""
    archive = Path(archive)
    with zipfile.ZipFile(archive) as zf:
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        _check_manifest(manifest)
        style = style or manifest["style"]
        members = _safe_members(zf)
        dest_parent = Path(dest_parent)
        dest_parent.mkdir(parents=True, exist_ok=True)
        tmp = Path(tempfile.mkdtemp(prefix=f".{style}-", dir=dest_parent))
        try:
            for m in members:
                if m.is_dir():
                    (tmp / m.filename).mkdir(parents=True, exist_ok=True)
                    continue
                target = tmp / m.filename
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(m) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
            final = dest_parent / style
            old = None
            if final.exists():
                old = dest_parent / f".{style}-old"
                shutil.rmtree(old, ignore_errors=True)
                os.replace(final, old)
            os.replace(tmp, final)
            if old:
                shutil.rmtree(old, ignore_errors=True)
        except Exception:
            shutil.rmtree(tmp, ignore_errors=True)
            raise
    util.log("установлен набор", style, "в", final)
    return _load_dir(final, "user" if Path(dest_parent) == paths.USER_PACKS else "system")


def install(archive):
    """Установка набора пользователем (без пароля, в домашнюю папку)."""
    try:
        return extract(archive, paths.USER_PACKS)
    except zipfile.BadZipFile:
        raise PackError("Файл повреждён или это не ZIP-архив.")


def remove(style_id):
    d = paths.USER_PACKS / style_id
    if d.is_dir():
        shutil.rmtree(d)
        return True
    return False
