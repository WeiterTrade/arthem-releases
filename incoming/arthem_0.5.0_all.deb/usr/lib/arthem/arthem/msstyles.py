"""Визуальный стиль Windows (.msstyles) → картинки и размеры для набора .arthem.

XP (Luna): настройки — текстовые INI-ресурсы (TEXTFILE), картинки — BITMAP.
Vista/7/8/10/11: таблица свойств VARIANT/NORMAL, имена классов CMAP, картинки — ресурсы IMAGE (PNG).

Результат — папка msstyles/ с PNG по кадрам и manifest.json:
  {"kind": "xp"|"vista", "parts": {ключ: {"frames": [...], "w":, "h":, "margins": [l, r, t, b], "text": "#rrggbb"}}}
"""

import json
import re
import struct
from pathlib import Path

from . import bitmap
from .pe import PE

# ключ → (варианты разделов XP, (класс, часть) Vista+, сколько кадров по умолчанию)
PARTS = {
    "caption": (["Window.Caption"], ("WINDOW", 1), 2),
    "frame_left": (["Window.FrameLeft"], ("WINDOW", 7), 2),
    "frame_right": (["Window.FrameRight"], ("WINDOW", 8), 2),
    "frame_bottom": (["Window.FrameBottom"], ("WINDOW", 9), 2),
    "btn_min": (["Window.MinButton"], ("WINDOW", 15), 8),
    "btn_max": (["Window.MaxButton"], ("WINDOW", 17), 8),
    "btn_close": (["Window.CloseButton"], ("WINDOW", 18), 8),
    "btn_restore": (["Window.RestoreButton"], ("WINDOW", 21), 8),
    "pushbutton": (["Button.Pushbutton"], ("BUTTON", 1), 5),
    "radio": (["Button.Radiobutton"], ("BUTTON", 2), 8),
    "checkbox": (["Button.Checkbox"], ("BUTTON", 3), 12),
    "scroll_thumb_h": (["ScrollBar.ThumbBtnHorz"], ("SCROLLBAR", 2), 4),
    "scroll_thumb_v": (["ScrollBar.ThumbBtnVert"], ("SCROLLBAR", 3), 4),
    "scroll_track_h": (["ScrollBar.LowerTrackHorz"], ("SCROLLBAR", 4), 4),
    "scroll_track_v": (["ScrollBar.LowerTrackVert"], ("SCROLLBAR", 6), 4),
    "progress_bar": (["Progress.Bar"], ("PROGRESS", 1), 1),
    "progress_chunk": (["Progress.Chunk"], ("PROGRESS", 3), 1),
    "progress_fill": ([], ("PROGRESS", 5), 1),
    "tab_item": (["Tab.TabItem"], ("TAB", 1), 5),
    "tab_pane": (["Tab.Pane"], ("TAB", 9), 1),
    "taskbar": (["Taskbar.BackgroundBottom", "TaskBar.BackgroundBottom"], ("TASKBAR", 1), 1),
    "start": (["Start::Button", "StartMenu::Button"], ("START", 1), 3),
    "taskbtn": (["TaskBand::Toolbar.Button", "TaskBand2::Toolbar.Button", "TaskBandGroup::Toolbar.Button"], ("TASKBAND", 1), 6),
    "tray": (["TrayNotify.Background", "TrayNotifyHoriz.Background"], ("TRAYNOTIFY", 1), 1),
}

TMT_IMAGEFILE = (3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010)
TMT_IMAGECOUNT = 2401
TMT_SIZINGMARGINS = 3601
TMT_CONTENTMARGINS = 3602
TMT_TEXTCOLOR = 3803
TMT_TRANSPARENTCOLOR = 3809
TMT_IMAGELAYOUT = 4011  # 0 — вертикально, 1 — горизонтально


def _ints(text):
    return [int(x) for x in re.findall(r"-?\d+", text or "")]


def _hex(rgb):
    r, g, b = (rgb + [0, 0, 0])[:3]
    return f"#{r:02X}{g:02X}{b:02X}"


# ------------------------------------------------------------------ XP

def _parse_ini(text):
    sections, cur = {}, None
    for line in text.splitlines():
        line = line.split(";", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            cur = sections.setdefault(line[1:-1].strip().lower(), {})
        elif "=" in line and cur is not None:
            k, v = line.split("=", 1)
            cur[k.strip().lower()] = v.strip()
    return sections


def _res_name(image_file):
    return re.sub(r"[\\/.]", "_", image_file.strip()).upper()


def export_xp(pe, out_dir, log=print):
    names = [n for n in pe.names("TEXTFILE") if isinstance(n, str)]
    ini_name = next((n for n in names if n == "NORMALBLUE_INI"), None) or next((n for n in names if n.endswith("_INI") and n != "THEMES_INI"), None)
    if not ini_name:
        raise ValueError("в .msstyles нет INI-описания цветовой схемы")
    raw = pe.get("TEXTFILE", ini_name)
    text = raw.decode("utf-16-le", "replace") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") or b"\x00" in raw[:20] else raw.decode("latin-1")
    text = text.lstrip("﻿")
    ini = _parse_ini(text)
    log(f"    схема: {ini_name}, разделов: {len(ini)}")
    bitmaps = {n: n for n in pe.names("BITMAP") if isinstance(n, str)}
    manifest = {"kind": "xp", "scheme": ini_name, "parts": {}, "colors": {}}
    for k, v in ini.get("sysmetrics", {}).items():
        vals = _ints(v)
        if len(vals) == 3:
            manifest["colors"][k] = _hex(vals)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for key, (sections, _vista, default_count) in PARTS.items():
        sec = None
        for cand in sections:
            sec = ini.get(cand.lower())
            if sec and (sec.get("imagefile") or sec.get("imagefile1")):
                break
            sec = None
        if not sec:
            continue
        img_file = sec.get("imagefile") or sec.get("imagefile1")
        rname = _res_name(img_file)
        data = pe.get("BITMAP", rname)
        if data is None:
            base = rname.split("_")[-2] if "_" in rname else rname
            alt = next((n for n in bitmaps if n.endswith(base + "_BMP")), None)
            data = pe.get("BITMAP", alt) if alt else None
        if data is None:
            log(f"    нет картинки {img_file} для {key}")
            continue
        img = bitmap.from_dib(data)
        tc = _ints(sec.get("transparentcolor"))
        if sec.get("transparent", "").lower() == "true" or tc:
            img.key_out(tuple(tc[:3]) if len(tc) >= 3 else (255, 0, 255))
        count = (_ints(sec.get("imagecount")) or [1])[0]
        vertical = sec.get("imagelayout", "vertical").lower() != "horizontal"
        frames = img.split(max(1, count), vertical)
        files = []
        for i, fr in enumerate(frames):
            fn = f"{key}_{i}.png"
            fr.save_png(out_dir / fn)
            files.append(fn)
        part = {"frames": files, "w": frames[0].w, "h": frames[0].h,
                "margins": (_ints(sec.get("sizingmargins")) + [0, 0, 0, 0])[:4],
                "content": (_ints(sec.get("contentmargins")) + [0, 0, 0, 0])[:4],
                "sizing": sec.get("sizingtype", "stretch").lower()}
        txt = _ints(sec.get("textcolor"))
        if len(txt) >= 3:
            part["text"] = _hex(txt)
        manifest["parts"][key] = part
    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    return manifest


# ------------------------------------------------------------------ Vista+

def _class_names(pe):
    data = pe.get("CMAP", "CMAP")
    if data is None:
        for (t, n), v in pe.resources().items():
            if t == "CMAP":
                data = v
                break
    if not data:
        return []
    names = data.decode("utf-16-le", "replace").split("\x00")
    return [n.upper() for n in names]


def _properties(pe):
    data = pe.get("VARIANT", "NORMAL")
    if data is None:
        for (t, n), v in pe.resources().items():
            if t == "VARIANT":
                data = v
                break
    props = []
    if not data:
        return props
    off = 0
    while off + 32 <= len(data):
        name, typ, cls, part, state, short, _res, size = struct.unpack_from("<8i", data, off)
        if not (0 < name < 20000 and 190 < typ < 260):
            off += 4  # потеря синхронизации — ищем дальше
            continue
        off += 32
        if short:
            value = short if size == 0 else size
            payload = struct.pack("<i", value)
        else:
            if size < 0 or off + size > len(data):
                break
            payload = data[off:off + size]
            off += size
            off = (off + 7) & ~7
        props.append({"name": name, "type": typ, "cls": cls, "part": part, "state": state, "data": payload})
    return props


def export_vista(pe, out_dir, log=print):
    classes = _class_names(pe)
    props = _properties(pe)
    images = {n: v for (t, n), v in pe.resources().items() if t == "IMAGE"}
    log(f"    классов: {len(classes)}, свойств: {len(props)}, картинок: {len(images)}")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"kind": "vista", "parts": {}, "classes": classes[:400]}

    def cls_index(name):
        for i, c in enumerate(classes):
            if c == name or c.endswith("::" + name):
                return i
        return None

    by_key = {}
    for p in props:
        by_key.setdefault((p["cls"], p["part"]), []).append(p)

    for key, (_xp, (cname, part_id), default_count) in PARTS.items():
        ci = cls_index(cname)
        if ci is None:
            continue
        plist = by_key.get((ci, part_id), [])
        img_id = None
        count, margins, vertical, text = default_count, [0, 0, 0, 0], True, None
        for p in plist:
            if p["state"] not in (0,):
                continue
            n, d = p["name"], p["data"]
            if n in TMT_IMAGEFILE and len(d) >= 4 and img_id is None:
                img_id = struct.unpack_from("<i", d)[0]
            elif n == TMT_IMAGECOUNT and len(d) >= 4:
                count = struct.unpack_from("<i", d)[0] or count
            elif n == TMT_SIZINGMARGINS and len(d) >= 16:
                margins = list(struct.unpack_from("<4i", d))
            elif n == TMT_IMAGELAYOUT and len(d) >= 4:
                vertical = struct.unpack_from("<i", d)[0] == 0
            elif n == TMT_TEXTCOLOR and len(d) >= 4:
                r, g, b, _a = d[:4]
                text = f"#{r:02X}{g:02X}{b:02X}"
        if img_id is None or img_id not in images:
            continue
        try:
            img = bitmap.from_png(images[img_id])
        except ValueError as exc:
            log(f"    {key}: картинка {img_id} не прочитана ({exc})")
            continue
        frames = img.split(max(1, count), vertical)
        files = []
        for i, fr in enumerate(frames):
            fn = f"{key}_{i}.png"
            fr.save_png(out_dir / fn)
            files.append(fn)
        part = {"frames": files, "w": frames[0].w, "h": frames[0].h, "margins": margins, "sizing": "stretch"}
        if text:
            part["text"] = text
        manifest["parts"][key] = part
    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    return manifest


def export(path, out_dir, log=print):
    pe = PE(path)
    if pe.names("TEXTFILE"):
        return export_xp(pe, out_dir, log)
    return export_vista(pe, out_dir, log)
