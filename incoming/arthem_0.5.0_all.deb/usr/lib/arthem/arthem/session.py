"""Действия при входе в систему (автозапуск /etc/xdg/autostart/arthem-session.desktop)."""

import time

from . import config, core, hotkeys, styles, util


def run(installed=False):
    cfg = config.load()
    state = config.load_state()

    # 1. Горячие клавиши: регистрируем и проверяем на конфликты
    try:
        if cfg.get("hotkeys_enabled", True):
            hotkeys.register(cfg)
            bad = hotkeys.conflicts(cfg)
            if bad:
                names = ", ".join(hotkeys.pretty(seq) for _a, seq, _m in bad)
                util.notify(
                    "Arthem: сочетания клавиш заняты",
                    f"{names}. Откройте Arthem → «Горячие клавиши», чтобы переназначить.",
                )
    except Exception as exc:  # клавиши не должны ломать вход в систему
        util.log("ошибка клавиш при входе", exc)

    # 2. Если после установки расширений GNOME нужен был перезаход — доприменяем стиль
    active = state.get("active", "linux")
    if state.get("pending_relogin") and active != "linux":
        time.sleep(3)
        try:
            core.apply(active, quiet=True)
        except Exception as exc:
            util.log("не удалось доприменить стиль", exc)

    # 3. Мелодия входа
    if cfg.get("startup_sound", True) and not installed:
        util.play_sound(str(core.startup_sound_path() or ""))

    # 4. Первый запуск — открыть окно программы; значок в трее
    if not cfg.get("first_run_done") or installed:
        config.update(first_run_done=True)
        util.spawn(["arthem", "gui"])
    if cfg.get("tray", True) and not installed:
        util.spawn(["arthem", "tray"])
    return 0
