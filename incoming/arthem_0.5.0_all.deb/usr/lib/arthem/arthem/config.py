"""Настройки пользователя (~/.config/arthem/config.json) и состояние (~/.local/share/arthem/state.json)."""

import copy
import json
import os

from . import paths

DEFAULT_HOTKEYS = {
    "linux": "Ctrl+Alt+Shift+0",
    "xp": "Ctrl+Alt+Shift+1",
    "w7": "Ctrl+Alt+Shift+2",
    "w10": "Ctrl+Alt+Shift+3",
    "w11": "Ctrl+Alt+Shift+4",
    "mac": "Ctrl+Alt+Shift+5",
    "next": "Ctrl+Alt+Shift+Space",
}

DEFAULTS = {
    "ui_layout": "gallery",          # gallery | showcase | compact
    "ui_theme": "aristocrat",        # aristocrat | turquoise | ruby | anime | light
    "hotkeys_enabled": True,
    "hotkeys": dict(DEFAULT_HOTKEYS),
    "components": {
        "icons": True,
        "sounds": True,
        "cursors": True,
        "wallpaper": True,
        "boot": True,
    },
    "startup_sound": True,
    "tray": True,
    "first_run_done": False,
}


def _merge(base, extra):
    out = copy.deepcopy(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _read(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load():
    return _merge(DEFAULTS, _read(paths.CONFIG_FILE))


def save(cfg):
    _write(paths.CONFIG_FILE, cfg)


def update(**changes):
    cfg = load()
    cfg = _merge(cfg, changes)
    save(cfg)
    return cfg


def load_state():
    return _read(paths.STATE_FILE)


def save_state(state):
    _write(paths.STATE_FILE, state)


def set_state(**changes):
    st = load_state()
    st.update(changes)
    save_state(st)
    return st
