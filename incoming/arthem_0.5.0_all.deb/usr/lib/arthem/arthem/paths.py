"""Пути Arthem. Всё можно переопределить переменными окружения (для разработки и тестов)."""

import os
from pathlib import Path

PREFIX = Path(os.environ.get("ARTHEM_PREFIX", "/usr"))
SHARE = Path(os.environ.get("ARTHEM_SHARE", str(PREFIX / "share" / "arthem")))
SYS_PACKS = Path(os.environ.get("ARTHEM_SYS_PACKS", str(SHARE / "packs")))

HOME = Path(os.environ.get("HOME") or Path.home())
XDG_CONFIG = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config")
XDG_DATA = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local" / "share")

CONF_DIR = XDG_CONFIG / "arthem"
CONFIG_FILE = CONF_DIR / "config.json"
DATA_DIR = XDG_DATA / "arthem"
STATE_FILE = DATA_DIR / "state.json"
USER_PACKS = DATA_DIR / "packs"
BACKUP_DIR = DATA_DIR / "backup"
SNAPSHOT_DIR = DATA_DIR / "snapshots"
LOG_FILE = DATA_DIR / "arthem.log"

USER_ICONS = XDG_DATA / "icons"
USER_SOUNDS = XDG_DATA / "sounds"
USER_APPS = XDG_DATA / "applications"


def share(*parts):
    return SHARE.joinpath(*parts)


def ensure_dirs():
    for d in (CONF_DIR, DATA_DIR, USER_PACKS, BACKUP_DIR):
        d.mkdir(parents=True, exist_ok=True)
