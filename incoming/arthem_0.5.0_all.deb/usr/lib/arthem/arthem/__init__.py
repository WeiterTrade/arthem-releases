"""Arthem — переключатель оформления Linux в стиле Windows XP/7/10/11 и macOS."""

import os as _os
from pathlib import Path as _Path


def _read_version():
    for candidate in (
        _Path(__file__).resolve().parent / "VERSION",
        _Path(__file__).resolve().parent.parent / "VERSION",
    ):
        try:
            return candidate.read_text(encoding="utf-8").strip()
        except OSError:
            continue
    return _os.environ.get("ARTHEM_VERSION", "0.0.0")


__version__ = _read_version()
