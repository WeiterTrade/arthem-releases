"""Чтение ресурсов из PE-файлов Windows (DLL, EXE, .msstyles) на чистом Python."""

import struct

RT_NAMES = {1: "CURSOR", 2: "BITMAP", 3: "ICON", 4: "MENU", 5: "DIALOG", 6: "STRING", 10: "RCDATA",
            12: "GROUP_CURSOR", 14: "GROUP_ICON", 16: "VERSION", 24: "MANIFEST"}


class PEError(Exception):
    pass


class PE:
    def __init__(self, path):
        with open(path, "rb") as fh:
            self.data = fh.read()
        d = self.data
        if d[:2] != b"MZ":
            raise PEError("не PE-файл")
        pe_off = struct.unpack_from("<I", d, 0x3C)[0]
        if d[pe_off:pe_off + 4] != b"PE\0\0":
            raise PEError("нет заголовка PE")
        coff = pe_off + 4
        n_sections = struct.unpack_from("<H", d, coff + 2)[0]
        opt_size = struct.unpack_from("<H", d, coff + 16)[0]
        opt = coff + 20
        magic = struct.unpack_from("<H", d, opt)[0]
        dd_off = opt + (96 if magic == 0x10B else 112)
        n_dirs = struct.unpack_from("<I", d, dd_off - 4)[0]
        self.rsrc_rva = 0
        if n_dirs > 2:
            self.rsrc_rva, self.rsrc_size = struct.unpack_from("<II", d, dd_off + 8 * 2)
        sec = opt + opt_size
        self.sections = []
        for i in range(n_sections):
            off = sec + 40 * i
            vsize, va, rsize, rptr = struct.unpack_from("<IIII", d, off + 8)
            self.sections.append((va, max(vsize, rsize), rptr))
        self._res = None

    def rva_to_off(self, rva):
        for va, size, ptr in self.sections:
            if va <= rva < va + size:
                return rva - va + ptr
        raise PEError(f"RVA {rva:#x} вне секций")

    def _name(self, base, val):
        if val & 0x80000000:
            off = base + (val & 0x7FFFFFFF)
            n = struct.unpack_from("<H", self.data, off)[0]
            return self.data[off + 2: off + 2 + 2 * n].decode("utf-16-le", "replace").upper()
        return val

    def _walk(self, base, off, depth, path, out):
        d = self.data
        _ch, _ts, _maj, _min, n_named, n_id = struct.unpack_from("<IIHHHH", d, off)
        for i in range(n_named + n_id):
            name, child = struct.unpack_from("<II", d, off + 16 + 8 * i)
            key = self._name(base, name)
            if child & 0x80000000:
                if depth < 3:
                    self._walk(base, base + (child & 0x7FFFFFFF), depth + 1, path + [key], out)
            else:
                entry = base + child
                rva, size = struct.unpack_from("<II", d, entry)
                try:
                    foff = self.rva_to_off(rva)
                except PEError:
                    continue
                p = path + [key]
                typ, nm = p[0], (p[1] if len(p) > 1 else 0)
                out.setdefault((typ, nm), d[foff:foff + size])

    def resources(self):
        """{(тип, имя): bytes}. Тип и имя — число или строка в ВЕРХНЕМ регистре (берётся первый язык)."""
        if self._res is None:
            self._res = {}
            if self.rsrc_rva:
                base = self.rva_to_off(self.rsrc_rva)
                self._walk(base, base, 1, [], self._res)
        return self._res

    def get(self, typ, name):
        res = self.resources()
        if isinstance(name, str):
            name = name.upper()
        if isinstance(typ, str):
            typ = typ.upper()
            for k, v in RT_NAMES.items():
                if v == typ:
                    if (k, name) in res:
                        return res[(k, name)]
        return res.get((typ, name))

    def names(self, typ):
        if isinstance(typ, str):
            typ = typ.upper()
            ids = [k for k, v in RT_NAMES.items() if v == typ]
            if ids:
                typ = ids[0]
        return [n for (t, n) in self.resources() if t == typ]
