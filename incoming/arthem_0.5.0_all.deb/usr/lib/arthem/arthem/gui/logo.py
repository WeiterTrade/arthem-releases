"""Логотип Arthem «Медальон»: палитра с кистью на монете. Рисуется кодом и перекрашивается под тему."""

from .qt import QtCore, QtGui, Qt


def _palette_path():
    p = QtGui.QPainterPath()
    p.moveTo(60, 16)
    p.cubicTo(88, 16, 106, 33, 106, 55)
    p.cubicTo(106, 71, 96, 78, 85, 76)
    p.cubicTo(75, 74, 70, 80, 72, 89)
    p.cubicTo(74, 100, 66, 106, 54, 104)
    p.cubicTo(31, 100, 14, 83, 14, 60)
    p.cubicTo(14, 35, 34, 16, 60, 16)
    p.closeSubpath()
    hole = QtGui.QPainterPath()
    hole.addEllipse(QtCore.QPointF(44, 78), 7, 7)
    return p.subtracted(hole)


def draw_logo(painter, rect, t):
    painter.save()
    painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
    s = min(rect.width(), rect.height()) / 120.0
    painter.translate(rect.x() + (rect.width() - 120 * s) / 2, rect.y() + (rect.height() - 120 * s) / 2)
    painter.scale(s, s)

    gold = QtGui.QLinearGradient(0, 0, 120, 120)
    gold.setColorAt(0, QtGui.QColor(t["gold_light"]))
    gold.setColorAt(0.5, QtGui.QColor(t["gold"]))
    gold.setColorAt(1, QtGui.QColor(t["gold"]).darker(130))

    coin = QtGui.QRadialGradient(QtCore.QPointF(42, 36), 96)
    coin.setColorAt(0, QtGui.QColor(t["coin1"]))
    coin.setColorAt(1, QtGui.QColor(t["coin2"]))
    painter.setBrush(QtGui.QBrush(coin))
    painter.setPen(QtGui.QPen(QtGui.QBrush(gold), 3))
    painter.drawEllipse(QtCore.QPointF(60, 60), 54, 54)
    ring = QtGui.QColor(t["gold"])
    ring.setAlphaF(0.35)
    painter.setBrush(Qt.NoBrush)
    painter.setPen(QtGui.QPen(ring, 1))
    painter.drawEllipse(QtCore.QPointF(60, 60), 48, 48)

    painter.translate(60, 60)
    painter.scale(0.72, 0.72)
    painter.translate(-60, -60)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QtGui.QBrush(gold))
    painter.drawPath(_palette_path())
    painter.setBrush(QtGui.QColor(t["coin2"]))
    for x, y, r in ((36, 46, 7.5), (55, 33, 7.5), (77, 36, 7.5), (90, 54, 6.5)):
        painter.drawEllipse(QtCore.QPointF(x, y), r, r)

    painter.translate(60, 60)
    painter.rotate(38)
    painter.translate(-60 + 14, -60 + 2)
    tip = QtGui.QPainterPath()
    tip.moveTo(60, 10)
    tip.cubicTo(55.5, 17, 54.5, 24, 55.5, 31)
    tip.lineTo(64.5, 31)
    tip.cubicTo(65.5, 24, 64.5, 17, 60, 10)
    painter.setBrush(QtGui.QColor("#FFFFFF"))
    painter.drawPath(tip)
    painter.setBrush(QtGui.QColor(t["light"]))
    painter.drawRoundedRect(QtCore.QRectF(54.8, 31, 10.4, 13), 1.5, 1.5)
    handle = QtGui.QPainterPath()
    handle.moveTo(55, 44)
    handle.lineTo(65, 44)
    handle.lineTo(63, 110)
    handle.quadTo(60, 114, 57, 110)
    handle.closeSubpath()
    painter.setBrush(QtGui.QColor("#FFFFFF"))
    painter.setPen(QtGui.QPen(QtGui.QColor(t["coin2"]), 1.5))
    painter.drawPath(handle)
    painter.restore()


def logo_pixmap(size, t):
    ratio = 2
    pm = QtGui.QPixmap(size * ratio, size * ratio)
    pm.fill(Qt.transparent)
    p = QtGui.QPainter(pm)
    draw_logo(p, QtCore.QRectF(0, 0, size * ratio, size * ratio), t)
    p.end()
    pm.setDevicePixelRatio(ratio)
    return pm


def logo_icon(t):
    icon = QtGui.QIcon()
    for s in (16, 24, 32, 48, 64, 128, 256):
        icon.addPixmap(logo_pixmap(s, t))
    return icon
