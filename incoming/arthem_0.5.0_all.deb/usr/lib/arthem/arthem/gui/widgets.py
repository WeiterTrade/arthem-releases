"""Виджеты Arthem: заголовок окна, превью стиля с «живым» меню, карточки, захват сочетаний клавиш."""

from .. import hotkeys, styles
from . import logo, previews
from .qt import QT6, QtCore, QtGui, QtWidgets, Qt, Signal, key_mods, key_name


def repolish(w):
    w.style().unpolish(w)
    w.style().polish(w)
    w.update()


class PreviewView(QtWidgets.QWidget):
    """Мини-рабочий стол. При наведении плавно открывается меню «Пуск»."""

    def __init__(self, style_id, pack_pixmap=None, radius=9, live=True, parent=None):
        super().__init__(parent)
        self.style_id = style_id
        self.pack_pixmap = pack_pixmap
        self.radius = radius
        self.live = live
        self.progress = 0.0
        self.anim = QtCore.QVariantAnimation(self)
        self.anim.setDuration(320)
        self.anim.setEasingCurve(QtCore.QEasingCurve.OutCubic)
        self.anim.valueChanged.connect(self._tick)
        self.setAttribute(Qt.WA_Hover, True)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

    def set_style(self, style_id, pack_pixmap=None):
        self.style_id = style_id
        self.pack_pixmap = pack_pixmap
        self.update()

    def _tick(self, v):
        self.progress = float(v)
        self.update()

    def _animate(self, target):
        if not self.live:
            return
        self.anim.stop()
        self.anim.setStartValue(self.progress)
        self.anim.setEndValue(float(target))
        self.anim.start()

    def enterEvent(self, e):
        self._animate(1.0)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._animate(0.0)
        super().leaveEvent(e)

    def paintEvent(self, e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)
        r = QtCore.QRectF(self.rect())
        path = QtGui.QPainterPath()
        path.addRoundedRect(r, self.radius, self.radius)
        p.setClipPath(path)
        previews.paint(p, r, self.style_id, self.progress, self.pack_pixmap)
        p.end()


class Clickable(QtWidgets.QFrame):
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.pos()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)


class Radio(QtWidgets.QWidget):
    """Кружок выбора, как на макете."""

    def __init__(self, t, parent=None):
        super().__init__(parent)
        self.t = t
        self.on = False
        self.setFixedSize(18, 18)

    def set_on(self, on):
        self.on = on
        self.update()

    def paintEvent(self, e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        col = QtGui.QColor(self.t["gold"] if self.on else self.t["border"])
        p.setPen(QtGui.QPen(col, 2))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QtCore.QRectF(1, 1, 16, 16))
        if self.on:
            p.setPen(Qt.NoPen)
            p.setBrush(col)
            p.drawEllipse(QtCore.QRectF(5, 5, 8, 8))
        p.end()


def badge(t, kind):
    lab = QtWidgets.QLabel({"orig": "ОРИГИНАЛ · .arthem", "built": "ВСТРОЕННЫЙ", "base": "ИСХОДНЫЙ ВИД"}[kind])
    lab.setObjectName("Badge")
    if kind == "orig":
        lab.setStyleSheet(f"color: {t['gold_light']}; border: 1px solid {t['gold']};")
    else:
        lab.setStyleSheet(f"color: {t['muted']}; border: 1px solid {t['border']};")
    return lab


def kbd(text):
    lab = QtWidgets.QLabel(text)
    lab.setObjectName("Kbd")
    lab.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
    lab.setAlignment(Qt.AlignCenter)
    return lab


class StyleCard(Clickable):
    """Карточка стиля для «Галереи»."""

    def __init__(self, t, style_id, kind, key, pack_pixmap=None, preview_h=148, parent=None):
        super().__init__(parent)
        self.t = t
        self.style_id = style_id
        self.setObjectName("Card")
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(10)
        self.preview = PreviewView(style_id, pack_pixmap)
        self.preview.setFixedHeight(preview_h)
        lay.addWidget(self.preview)
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(4, 0, 4, 0)
        name = QtWidgets.QLabel(styles.name(style_id))
        name.setStyleSheet("font-size: 15px; font-weight: 700;")
        row.addWidget(name)
        row.addStretch(1)
        self.radio = Radio(t)
        row.addWidget(self.radio)
        lay.addLayout(row)
        row2 = QtWidgets.QHBoxLayout()
        row2.setContentsMargins(4, 0, 4, 4)
        row2.addWidget(badge(t, kind))
        row2.addStretch(1)
        if key:
            row2.addWidget(kbd(hotkeys.pretty(key)))
        lay.addLayout(row2)

    def set_selected(self, on):
        self.setProperty("selected", "true" if on else "false")
        self.radio.set_on(on)
        repolish(self)


class StyleRow(Clickable):
    """Строка стиля для «Компактного» вида."""

    def __init__(self, t, style_id, kind, key, pack_pixmap=None, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(8, 8, 14, 8)
        lay.setSpacing(14)
        self.preview = PreviewView(style_id, pack_pixmap, radius=8)
        self.preview.setFixedSize(108, 66)
        lay.addWidget(self.preview)
        col = QtWidgets.QVBoxLayout()
        col.setSpacing(3)
        name = QtWidgets.QLabel(styles.name(style_id))
        name.setStyleSheet("font-size: 15px; font-weight: 700;")
        sub = QtWidgets.QLabel({"orig": "Оригинал · .arthem", "built": "Встроенный стиль", "base": "Исходный вид системы"}[kind])
        sub.setStyleSheet(f"font-size: 12px; color: {t['gold_light'] if kind == 'orig' else t['muted']};")
        col.addWidget(name)
        col.addWidget(sub)
        lay.addLayout(col, 1)
        if key:
            lay.addWidget(kbd(hotkeys.pretty(key)), 0, Qt.AlignVCenter)
        self.radio = Radio(t)
        lay.addWidget(self.radio, 0, Qt.AlignVCenter)

    def set_selected(self, on):
        self.setProperty("selected", "true" if on else "false")
        self.radio.set_on(on)
        repolish(self)


class TitleBar(QtWidgets.QWidget):
    def __init__(self, t, window, center=None, compact=False, parent=None):
        super().__init__(parent)
        self.win = window
        self._drag = None
        self.setFixedHeight(56 if center else 52)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(18, 0, 14, 0)
        lay.setSpacing(12)
        lg = QtWidgets.QLabel()
        lg.setPixmap(logo.logo_pixmap(30, t))
        lay.addWidget(lg)
        brand = QtWidgets.QLabel("ARTHEM")
        brand.setObjectName("Brand")
        f = brand.font()
        f.setLetterSpacing(QtGui.QFont.PercentageSpacing, 118)
        brand.setFont(f)
        lay.addWidget(brand)
        lay.addStretch(1)
        if center is not None:
            lay.addWidget(center)
            lay.addStretch(1)
        for name, obj, tip in (("min", "Round", "Свернуть"), ("max", "Round", "Развернуть"), ("close", "RoundClose", "Закрыть")):
            if compact and name == "max":
                continue
            b = QtWidgets.QPushButton({"min": "–", "max": "□", "close": "×"}[name])
            b.setObjectName(obj)
            b.setToolTip(tip)
            b.setAccessibleName(tip)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(getattr(self, f"_{name}"))
            lay.addWidget(b)
        self.t = t

    def _min(self):
        self.win.showMinimized()

    def _max(self):
        self.win.showNormal() if self.win.isMaximized() else self.win.showMaximized()

    def _close(self):
        self.win.close()

    def paintEvent(self, e):
        p = QtGui.QPainter(self)
        g = QtGui.QLinearGradient(0, 0, self.width(), 0)
        c = QtGui.QColor(self.t["glow"])
        c0 = QtGui.QColor(c)
        c0.setAlpha(0)
        g.setColorAt(0, c0)
        g.setColorAt(0.5, c)
        g.setColorAt(1, c0)
        p.fillRect(QtCore.QRectF(0, self.height() - 1, self.width(), 1), QtGui.QBrush(g))
        p.end()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            handle = self.win.windowHandle()
            if handle is not None and hasattr(handle, "startSystemMove"):
                if handle.startSystemMove():
                    return
            gp = e.globalPosition().toPoint() if QT6 else e.globalPos()
            self._drag = gp - self.win.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            gp = e.globalPosition().toPoint() if QT6 else e.globalPos()
            self.win.move(gp - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None

    def mouseDoubleClickEvent(self, e):
        self._max()


class KeyCaptureDialog(QtWidgets.QDialog):
    """«Нажмите сочетание». Проверяет конфликты и не даёт сохранить системные комбинации."""

    def __init__(self, t, action, current, assigned, parent=None):
        super().__init__(parent)
        self.t = t
        self.action = action
        self.assigned = dict(assigned)
        self.result_seq = None
        self.setWindowTitle("Новое сочетание")
        self.setModal(True)
        self.setMinimumWidth(460)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 20)
        lay.setSpacing(14)
        title = "Следующий стиль по кругу" if action == "next" else styles.name(action)
        h = QtWidgets.QLabel(f"Сочетание для: {title}")
        h.setObjectName("H2")
        lay.addWidget(h)
        hint = QtWidgets.QLabel("Нажмите нужные клавиши вместе. Esc — отмена.")
        hint.setObjectName("Muted")
        lay.addWidget(hint)
        self.seq_label = QtWidgets.QLabel(hotkeys.pretty(current) if current else "…")
        self.seq_label.setAlignment(Qt.AlignCenter)
        self.seq_label.setStyleSheet(
            f"font-size: 22px; font-weight: 800; padding: 18px; border-radius: 12px;"
            f"background: {t['card']}; border: 1px solid {t['border']}; color: {t['light']};"
        )
        lay.addWidget(self.seq_label)
        self.msg = QtWidgets.QLabel("")
        self.msg.setWordWrap(True)
        self.msg.setMinimumHeight(44)
        lay.addWidget(self.msg)
        row = QtWidgets.QHBoxLayout()
        row.addStretch(1)
        cancel = QtWidgets.QPushButton("Отмена")
        cancel.setObjectName("Secondary")
        cancel.clicked.connect(self.reject)
        self.ok = QtWidgets.QPushButton("Сохранить")
        self.ok.setObjectName("Primary")
        self.ok.setEnabled(False)
        self.ok.clicked.connect(self.accept)
        row.addWidget(cancel)
        row.addWidget(self.ok)
        lay.addLayout(row)
        self.candidate = None
        self.grabKeyboard()

    def done(self, r):
        self.releaseKeyboard()
        super().done(r)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape and not key_mods(e):
            self.reject()
            return
        mods = key_mods(e)
        key = key_name(e)
        if not key:
            self.seq_label.setText("+".join(mods) + "+…" if mods else "…")
            return
        seq = hotkeys.canonical(mods, key)
        self.candidate = seq
        self.seq_label.setText(hotkeys.pretty(seq))
        res = hotkeys.check(seq, self.action, assigned=self.assigned)
        colors = {"ok": "#2BB673", "warn": self.t["gold"], "block": "#FF6B6B"}
        self.msg.setStyleSheet(f"color: {colors[res.level]}; font-weight: 600;")
        self.msg.setText(res.message)
        self.ok.setEnabled(res.level != "block")
        if res.level != "block":
            self.result_seq = seq

    def keyReleaseEvent(self, e):
        pass
