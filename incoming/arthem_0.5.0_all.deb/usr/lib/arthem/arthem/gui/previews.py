"""Мини-рабочие столы для карточек стилей и «живое» меню «Пуск» при наведении.

Если для стиля есть набор .arthem с preview.png, рисуется он, а меню накладывается поверх.
"""

from .qt import QtCore, QtGui, Qt

C = QtGui.QColor
R = QtCore.QRectF
P = QtCore.QPointF


class Ctx:
    def __init__(self, painter, rect):
        self.p = painter
        self.r = R(rect)
        self.u = self.r.height() / 100.0
        self.w = self.r.width()
        self.h = self.r.height()

    def X(self, pct):
        return self.r.x() + self.w * pct / 100.0

    def Y(self, pct):
        return self.r.y() + self.h * pct / 100.0

    def rect(self, x, y, w, h):
        return R(self.X(x), self.Y(y), self.w * w / 100.0, self.h * h / 100.0)

    def font(self, size_u, bold=False, italic=False):
        f = QtGui.QFont()
        f.setPixelSize(max(6, int(self.u * size_u)))
        f.setBold(bold)
        f.setItalic(italic)
        self.p.setFont(f)

    def text(self, rect, s, color="#FFFFFF", size=4, bold=False, italic=False, align=Qt.AlignLeft | Qt.AlignVCenter):
        self.font(size, bold, italic)
        self.p.setPen(C(color))
        self.p.drawText(rect, int(align), s)

    def fill(self, rect, brush, radius=0, pen=None):
        self.p.setPen(pen if pen is not None else Qt.NoPen)
        self.p.setBrush(brush)
        if radius:
            self.p.drawRoundedRect(rect, radius, radius)
        else:
            self.p.drawRect(rect)


def vgrad(rect, *stops):
    g = QtGui.QLinearGradient(rect.topLeft(), rect.bottomLeft())
    for pos, col in stops:
        g.setColorAt(pos, C(col) if isinstance(col, str) else col)
    return QtGui.QBrush(g)


def rgba(hexc, a):
    c = C(hexc)
    c.setAlphaF(a)
    return c


def diamond(c, cx, cy, size, color):
    p = c.p
    p.save()
    p.translate(cx, cy)
    p.rotate(45)
    p.setPen(Qt.NoPen)
    p.setBrush(C(color))
    s = size / 2.3
    g = size / 14
    for dx, dy in ((-1, -1), (0, -1), (-1, 0), (0, 0)):
        p.drawRect(R(dx * s + (g if dx == 0 else -g), dy * s + (g if dy == 0 else -g), s, s))
    p.restore()


# ------------------------------------------------------------------ рабочие столы

def _window(c, x, y, w, h, title, kind):
    r = c.rect(x, y, w, h)
    u = c.u
    p = c.p
    if kind == "xp":
        c.fill(r, C("#ECE9D8"), 3 * u, QtGui.QPen(C("#0831D9"), 1))
        bar = R(r.x(), r.y(), r.width(), r.height() * 0.17)
        c.fill(bar, vgrad(bar, (0, "#0A5FE0"), (0.35, "#3C8CF6"), (1, "#0B55D6")), 3 * u)
        c.text(bar.adjusted(3 * u, 0, 0, 0), title, "#FFFFFF", 4.6, True)
        cb = R(bar.right() - 9 * u, bar.y() + bar.height() * 0.18, 7 * u, bar.height() * 0.64)
        c.fill(cb, vgrad(cb, (0, "#E8735A"), (1, "#C4391D")), 1.2 * u, QtGui.QPen(C("#FFFFFF"), 1))
        side = R(r.x() + 1, bar.bottom(), r.width() * 0.3, r.bottom() - bar.bottom() - 1)
        c.fill(side, vgrad(side, (0, "#7BA2E7"), (1, "#6375D6")))
        c.fill(R(side.right(), bar.bottom(), r.right() - side.right() - 1, side.height()), C("#FFFFFF"))
    elif kind == "w7":
        c.fill(r, rgba("#AACDEB", 0.85), 2.5 * u, QtGui.QPen(rgba("#FFFFFF", 0.7), 1))
        bar = R(r.x(), r.y(), r.width(), r.height() * 0.16)
        c.text(bar.adjusted(3 * u, 0, 0, 0), title, "#1B2B3C", 4.2)
        cb = R(bar.right() - 15 * u, bar.y() + bar.height() * 0.2, 13 * u, bar.height() * 0.6)
        c.fill(cb, vgrad(cb, (0, "#E9A08F"), (1, "#C73B22")), u, QtGui.QPen(rgba("#FFFFFF", 0.8), 1))
        c.fill(R(r.x() + 2 * u, bar.bottom(), r.width() - 4 * u, r.bottom() - bar.bottom() - 2 * u), C("#FFFFFF"), 0, QtGui.QPen(C("#8DB2D8"), 1))
    elif kind in ("w10", "w11"):
        rad = 2.5 * u if kind == "w11" else 0
        border = C("#1E63D3") if kind == "w10" else C("#D6DDE8")
        c.fill(r, C("#FFFFFF"), rad, QtGui.QPen(border, 1))
        bar = R(r.x(), r.y(), r.width(), r.height() * 0.15)
        c.fill(bar.adjusted(1, 1, -1, 0), C("#FFFFFF" if kind == "w10" else "#F3F3F3"), rad)
        c.text(bar.adjusted(3 * u, 0, 0, 0), title, "#1A1A1A", 4)
        c.text(bar.adjusted(0, 0, -3 * u, 0), "–   □   ×", "#444444", 4, align=Qt.AlignRight | Qt.AlignVCenter)
        c.fill(R(r.x() + 1, bar.bottom(), r.width() * 0.25, r.bottom() - bar.bottom() - 1), C("#F5F7FA"))
    elif kind == "mac":
        c.fill(r, C("#F5F5F7"), 2.5 * u)
        bar = R(r.x(), r.y(), r.width(), r.height() * 0.15)
        c.fill(bar, C("#E8E8EC"), 2.5 * u)
        for i, col in enumerate(("#FF5F57", "#FEBC2E", "#28C840")):
            c.fill(R(bar.x() + 3 * u + i * 5 * u, bar.center().y() - 1.8 * u, 3.6 * u, 3.6 * u), C(col), 1.8 * u)
    else:
        c.fill(r, C("#2A2F3A"), 2.5 * u, QtGui.QPen(C("#3A4152"), 1))
        c.fill(R(r.x(), r.y(), r.width(), r.height() * 0.15), C("#353B48"), 2.5 * u)
    # тень
    return r


def _bg(c, style):
    r = c.r
    p = c.p
    u = c.u
    if style == "xp":
        c.fill(r, vgrad(r, (0, "#2F78D8"), (0.5, "#7DB8EE"), (0.68, "#BFE0F7")))
        hill = QtGui.QPainterPath()
        hill.moveTo(c.X(-5), c.Y(70))
        hill.cubicTo(c.X(25), c.Y(52), c.X(60), c.Y(55), c.X(105), c.Y(72))
        hill.lineTo(c.X(105), c.Y(105))
        hill.lineTo(c.X(-5), c.Y(105))
        hill.closeSubpath()
        g = QtGui.QRadialGradient(P(c.X(40), c.Y(58)), c.w * 0.7)
        g.setColorAt(0, C("#86C84F"))
        g.setColorAt(0.6, C("#4F9A2F"))
        g.setColorAt(1, C("#3A7F22"))
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QBrush(g))
        p.drawPath(hill)
    elif style == "w7":
        g = QtGui.QRadialGradient(P(c.X(68), c.Y(32)), c.w * 0.8)
        g.setColorAt(0, C("#59BBEE"))
        g.setColorAt(0.42, C("#1769A8"))
        g.setColorAt(1, C("#0A3563"))
        c.fill(r, QtGui.QBrush(g))
        p.save()
        p.translate(r.center())
        p.rotate(-12)
        band = R(-c.w * 0.7, -c.h * 0.12, c.w * 1.4, c.h * 0.16)
        c.fill(band, vgrad(band, (0, rgba("#FFFFFF", 0)), (0.5, rgba("#FFFFFF", 0.22)), (1, rgba("#FFFFFF", 0))))
        p.restore()
    elif style == "w10":
        g = QtGui.QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, C("#04142E"))
        g.setColorAt(0.6, C("#0A3A78"))
        g.setColorAt(1, C("#05254F"))
        c.fill(r, QtGui.QBrush(g))
        for y1, y2, a in ((5, 25, 0.6), (35, 50, 0.45), (60, 85, 0.4)):
            poly = QtGui.QPolygonF([P(c.X(100), c.Y(45)), P(c.X(0), c.Y(y1)), P(c.X(0), c.Y(y2))])
            lg = QtGui.QLinearGradient(P(c.X(100), 0), P(c.X(0), 0))
            lg.setColorAt(0, rgba("#5AAAFF", a))
            lg.setColorAt(1, rgba("#5AAAFF", 0))
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QBrush(lg))
            p.drawPolygon(poly)
    elif style == "w11":
        g = QtGui.QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, C("#E4EEF9"))
        g.setColorAt(1, C("#BCD6F2"))
        c.fill(r, QtGui.QBrush(g))
        p.save()
        p.translate(c.X(50), c.Y(44))
        for i, (a, b) in enumerate((("#1E63D3", "#8EC5FF"), ("#0B4FB8", "#6AB4FF"), ("#1E63D3", "#B7E0FF"), ("#2D74E0", "#4DA8FF"))):
            p.save()
            p.rotate(i * 45)
            e = R(-24 * u, -6 * u, 48 * u, 12 * u)
            lg = QtGui.QLinearGradient(e.topLeft(), e.topRight())
            lg.setColorAt(0, rgba(a, 0.75))
            lg.setColorAt(1, rgba(b, 0.75))
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QBrush(lg))
            p.drawEllipse(e)
            p.restore()
        p.restore()
    elif style == "mac":
        g = QtGui.QLinearGradient(r.topLeft(), r.bottomRight())
        for pos, col in ((0, "#2B2D6E"), (0.45, "#6B3FA0"), (0.82, "#E0756A"), (1, "#F2B36B")):
            g.setColorAt(pos, C(col))
        c.fill(r, QtGui.QBrush(g))
    else:
        c.fill(r, vgrad(r, (0, "#1B2333"), (1, "#2C3A55")))


def _icons_on_desktop(c, style, icons=None):
    """Пара ярлыков на рабочем столе (из набора, если есть)."""
    if style in ("mac", "linux"):
        return
    u = c.u
    icons = icons or {}
    for i, (key, col, label) in enumerate((("computer", "#3A6EA5", "Компьютер"), ("trash", "#CFD6DF", "Корзина"))):
        x = c.X(2.5)
        y = c.Y(4 + i * 17)
        pm = icons.get(key)
        if pm is not None and not pm.isNull():
            c.p.drawPixmap(R(x + 1.5 * u, y - 1 * u, 8.5 * u, 8.5 * u), pm, R(pm.rect()))
        else:
            c.fill(R(x + 2 * u, y, 7 * u, 6 * u), C(col), u * 0.8)
        if c.h > 110:
            c.text(R(x - 2 * u, y + 6.5 * u, 15 * u, 4 * u), label, "#FFFFFF", 2.8, align=Qt.AlignHCenter | Qt.AlignTop)


def _xp_start(c, start):
    u = c.u
    p = c.p
    path = QtGui.QPainterPath()
    path.addRoundedRect(start.adjusted(-start.height(), 0, 0, 0), start.height() / 2, start.height() / 2)
    p.setPen(Qt.NoPen)
    p.setBrush(vgrad(start, (0, "#5DBB5D"), (0.5, "#3A943A"), (1, "#2F7F2F")))
    p.drawPath(path)
    diamond(c, start.x() + 4.5 * u, start.center().y(), 4 * u, "#FFFFFF")
    c.text(start.adjusted(8 * u, 0, 0, 0), "пуск", "#FFFFFF", 6, True, True)


def _start_img(c, rect, pm):
    if pm is None or pm.isNull():
        return False
    sc = min(rect.width() / pm.width(), rect.height() / pm.height())
    w, h = pm.width() * sc, pm.height() * sc
    c.p.drawPixmap(R(rect.x(), rect.center().y() - h / 2, w, h), pm, R(pm.rect()))
    return True


def _taskbar(c, style, start_pix=None):
    u = c.u
    r = c.r
    p = c.p
    if style == "xp":
        bar = R(r.x(), c.Y(88), r.width(), c.h * 0.12)
        c.fill(bar, vgrad(bar, (0, "#3D7BEA"), (0.18, "#245EDB"), (0.85, "#1F53CC"), (1, "#173FA8")))
        start = R(bar.x(), bar.y(), max(c.w * 0.14, 20 * u), bar.height())
        if _start_img(c, start, start_pix):
            pass
        else:
            _xp_start(c, start)
        btn = R(start.right() + 2 * u, bar.y() + bar.height() * 0.13, c.w * 0.26, bar.height() * 0.74)
        c.fill(btn, C("#3C81F3"), u, QtGui.QPen(C("#1B4DB8"), 1))
        c.text(btn.adjusted(2 * u, 0, 0, 0), "Мой компьютер", "#FFFFFF", 4)
        tray = R(r.right() - c.w * 0.14, bar.y(), c.w * 0.14, bar.height())
        c.fill(tray, vgrad(tray, (0, "#1AA0F0"), (1, "#0D8DE0")))
        c.text(tray, "12:00", "#FFFFFF", 4.4, align=Qt.AlignCenter)
        return bar
    if style == "w7":
        bar = R(r.x(), c.Y(87), r.width(), c.h * 0.13)
        c.fill(bar, vgrad(bar, (0, rgba("#3C5F82", 0.85)), (1, rgba("#0F1E32", 0.92))))
        p.setPen(QtGui.QPen(rgba("#FFFFFF", 0.3), 1))
        p.drawLine(bar.topLeft(), bar.topRight())
        orb = R(bar.x() + 1.5 * u, bar.center().y() - 5.5 * u, 11 * u, 11 * u)
        if not _start_img(c, orb, start_pix):
            g = QtGui.QRadialGradient(P(orb.center().x(), orb.y() + orb.height() * 0.3), orb.width() * 0.6)
            g.setColorAt(0, C("#A8E6FF"))
            g.setColorAt(0.55, C("#2482D0"))
            g.setColorAt(1, C("#0C3F80"))
            p.setBrush(QtGui.QBrush(g))
            p.setPen(QtGui.QPen(rgba("#FFFFFF", 0.7), 1))
            p.drawEllipse(orb)
            diamond(c, orb.center().x(), orb.center().y(), 4.4 * u, "#FFFFFF")
        x = orb.right() + 3 * u
        for col, active in (("#F2C14E", True), ("#3FA0E8", False), ("#F08A24", False)):
            slot = R(x, bar.center().y() - 4.5 * u, 10 * u, 9 * u)
            if active:
                c.fill(slot, rgba("#FFFFFF", 0.18), 1.5 * u, QtGui.QPen(rgba("#FFFFFF", 0.35), 1))
            c.fill(R(slot.center().x() - 3 * u, slot.center().y() - 2.5 * u, 6 * u, 5 * u), C(col), 0.8 * u)
            x += 11.5 * u
        c.text(R(r.right() - 16 * u, bar.y(), 14 * u, bar.height()), "12:00", "#FFFFFF", 4.2, align=Qt.AlignCenter)
        return bar
    if style == "w10":
        bar = R(r.x(), c.Y(89), r.width(), c.h * 0.11)
        c.fill(bar, C("#101318"))
        diamond(c, bar.x() + 5.5 * u, bar.center().y(), 4 * u, "#FFFFFF")
        sb = R(bar.x() + 11 * u, bar.y() + bar.height() * 0.15, c.w * 0.3, bar.height() * 0.7)
        c.fill(sb, C("#F2F2F2"))
        c.text(sb.adjusted(2 * u, 0, 0, 0), "Поиск", "#555555", 4)
        x = sb.right() + 2 * u
        for col, active in (("#F2C14E", True), ("#0086FF", False), ("#2BB673", False)):
            slot = R(x, bar.y(), 9 * u, bar.height())
            if active:
                c.fill(slot, rgba("#FFFFFF", 0.08))
                c.fill(R(slot.x(), slot.bottom() - 0.8 * u, slot.width(), 0.8 * u), C("#4DA8FF"))
            c.fill(R(slot.center().x() - 2.5 * u, slot.center().y() - 2 * u, 5 * u, 4 * u), C(col))
            x += 9 * u
        c.text(R(r.right() - 14 * u, bar.y(), 12 * u, bar.height()), "12:00", "#FFFFFF", 4, align=Qt.AlignCenter)
        return bar
    if style == "w11":
        bar = R(r.x(), c.Y(89), r.width(), c.h * 0.11)
        c.fill(bar, rgba("#F3F3F3", 0.94))
        p.setPen(QtGui.QPen(C("#D6DDE8"), 1))
        p.drawLine(bar.topLeft(), bar.topRight())
        n = 5
        sz = 7 * u
        gap = 2 * u
        total = n * sz + (n - 1) * gap
        x = r.center().x() - total / 2
        cols = ("start", "#F2C14E", "#0086FF", "#2BB673", "#7B5CE0")
        for col in cols:
            slot = R(x, bar.center().y() - sz / 2, sz, sz)
            if col == "start":
                c.fill(slot, C("#FFFFFF"), 1.6 * u)
                diamond(c, slot.center().x(), slot.center().y(), 3.6 * u, "#1E63D3")
            else:
                c.fill(slot, C(col), 1.6 * u)
            x += sz + gap
        c.text(R(r.right() - 14 * u, bar.y(), 12 * u, bar.height()), "12:00", "#1A1A1A", 3.8, align=Qt.AlignCenter)
        return bar
    if style == "mac":
        top = R(r.x(), r.y(), r.width(), c.h * 0.08)
        c.fill(top, rgba("#FFFFFF", 0.4))
        c.fill(R(top.x() + 3 * u, top.center().y() - 1.5 * u, 3 * u, 3 * u), C("#1A1A1A"), 1.5 * u)
        c.text(top.adjusted(9 * u, 0, 0, 0), "Finder    Файл    Правка    Вид", "#1A1A1A", 3.6, True)
        c.text(top.adjusted(0, 0, -3 * u, 0), "12:00", "#1A1A1A", 3.6, align=Qt.AlignRight | Qt.AlignVCenter)
        n = 6
        sz = 8.5 * u
        gap = 2 * u
        total = n * sz + (n - 1) * gap + 4 * u
        dock = R(r.center().x() - total / 2, c.Y(84), total, 12.5 * u)
        c.fill(dock, rgba("#FFFFFF", 0.3), 3.5 * u, QtGui.QPen(rgba("#FFFFFF", 0.45), 1))
        x = dock.x() + 2 * u
        for a, b in (("#6AC8FF", "#1E63D3"), ("#FFFFFF", "#D9D9DE"), ("#7CE08A", "#2BB673"), ("#FFB46A", "#F0702A"), ("#B79BFF", "#6B3FA0"), ("#FF8A8A", "#E0435A")):
            ic = R(x, dock.center().y() - sz / 2, sz, sz)
            c.fill(ic, vgrad(ic, (0, a), (1, b)), 2.2 * u)
            x += sz + gap
        return dock
    # linux
    top = R(r.x(), r.y(), r.width(), c.h * 0.08)
    c.fill(top, C("#0B0E14"))
    c.text(top, "12:00", "#FFFFFF", 4, align=Qt.AlignCenter)
    dock = R(r.center().x() - 16 * u, c.Y(85), 32 * u, 11 * u)
    c.fill(dock, rgba("#000000", 0.45), 3 * u)
    for i, col in enumerate(("#4A90D9", "#E66B2E", "#8E9AAF")):
        c.fill(R(dock.x() + 2.5 * u + i * 9.5 * u, dock.y() + 2 * u, 7 * u, 7 * u), C(col), 1.6 * u)
    return dock


# ------------------------------------------------------------------ меню «Пуск»

def _menu(c, style, progress):
    if progress <= 0.01 or style == "linux":
        return
    u = c.u
    p = c.p
    p.save()
    p.setOpacity(min(1.0, progress * 1.3))
    shift = (1 - progress) * 10 * u
    if style == "xp":
        m = R(c.X(0), c.Y(20) + shift, c.w * 0.46, c.h * 0.68)
        c.fill(m, C("#FFFFFF"), 2 * u, QtGui.QPen(C("#0B55D6"), 1.5))
        head = R(m.x(), m.y(), m.width(), m.height() * 0.15)
        c.fill(head, vgrad(head, (0, "#3C8CF6"), (1, "#0B55D6")), 2 * u)
        c.fill(R(head.x() + 2 * u, head.y() + 1.5 * u, head.height() - 3 * u, head.height() - 3 * u), C("#F2C14E"), u, QtGui.QPen(C("#FFFFFF"), 1))
        c.text(head.adjusted(head.height() + 1 * u, 0, 0, 0), "Пользователь", "#FFFFFF", 4.4, True)
        body = R(m.x(), head.bottom(), m.width(), m.height() * 0.73)
        right = R(body.x() + body.width() * 0.52, body.y(), body.width() * 0.48, body.height())
        c.fill(right, C("#D3E5FA"))
        for i, t in enumerate(("Интернет", "Почта", "Блокнот", "Paint")):
            y = body.y() + 2 * u + i * 8 * u
            c.fill(R(body.x() + 2 * u, y + 1 * u, 5 * u, 5 * u), C(("#3FA0E8", "#F2C14E", "#2BB673", "#E0435A")[i]), 0.8 * u)
            c.text(R(body.x() + 8.5 * u, y, body.width() * 0.4, 7 * u), t, "#1A1A1A", 3.6)
        for i, t in enumerate(("Мои документы", "Мои рисунки", "Мой компьютер", "Панель управления")):
            c.text(R(right.x() + 2 * u, right.y() + 2 * u + i * 8 * u, right.width(), 7 * u), t, "#0A246A", 3.4, True)
        foot = R(m.x(), body.bottom(), m.width(), m.bottom() - body.bottom())
        c.fill(foot, vgrad(foot, (0, "#3C8CF6"), (1, "#0B55D6")), 2 * u)
        c.text(foot.adjusted(0, 0, -3 * u, 0), "Выход из системы   Выключение", "#FFFFFF", 3.4, align=Qt.AlignRight | Qt.AlignVCenter)
    elif style == "w7":
        m = R(c.X(1), c.Y(17) + shift, c.w * 0.52, c.h * 0.69)
        c.fill(m, rgba("#2A4B6E", 0.92), 2 * u, QtGui.QPen(rgba("#FFFFFF", 0.5), 1))
        left = R(m.x() + 2 * u, m.y() + 2 * u, m.width() * 0.52, m.height() - 4 * u)
        c.fill(left, C("#FFFFFF"), u)
        for i, t in enumerate(("Проводник", "Интернет", "Блокнот", "Paint", "Калькулятор")):
            y = left.y() + 2 * u + i * 8 * u
            c.fill(R(left.x() + 2 * u, y + 1 * u, 5.5 * u, 5.5 * u), C(("#F2C14E", "#3FA0E8", "#2BB673", "#E0435A", "#7B5CE0")[i]), 0.8 * u)
            c.text(R(left.x() + 9 * u, y, left.width(), 7.5 * u), t, "#1A1A1A", 3.6)
        sb = R(left.x() + 2 * u, left.bottom() - 8 * u, left.width() - 4 * u, 6 * u)
        c.fill(sb, C("#FFFFFF"), u, QtGui.QPen(C("#9DB5CF"), 1))
        c.text(sb.adjusted(1.5 * u, 0, 0, 0), "Найти программы и файлы", "#7A8696", 3.2, False, True)
        rx = left.right() + 3 * u
        for i, t in enumerate(("Пользователь", "Документы", "Изображения", "Музыка", "Компьютер", "Панель управления")):
            c.text(R(rx, left.y() + 2 * u + i * 7.5 * u, m.right() - rx, 7 * u), t, "#FFFFFF", 3.1, i == 0)
        btn = R(rx, left.bottom() - 7 * u, (m.right() - rx) * 0.9, 6 * u)
        c.fill(btn, vgrad(btn, (0, "#E9A08F"), (1, "#C73B22")), u)
        c.text(btn, "Завершение работы", "#FFFFFF", 2.7, align=Qt.AlignCenter)
    elif style == "w10":
        m = R(c.X(0), c.Y(22) + shift, c.w * 0.58, c.h * 0.67)
        c.fill(m, rgba("#1F1F1F", 0.97))
        c.fill(R(m.x(), m.y(), 6 * u, m.height()), C("#161616"))
        for i in range(4):
            c.fill(R(m.x() + 1.8 * u, m.y() + 3 * u + i * 7 * u, 2.6 * u, 2.6 * u), C("#BBBBBB"))
        lx = m.x() + 8 * u
        for i, t in enumerate(("Блокнот", "Калькулятор", "Почта", "Проводник", "Фото")):
            y = m.y() + 3 * u + i * 7.5 * u
            c.fill(R(lx, y + u, 5 * u, 5 * u), C(("#0078D7", "#2B2B2B", "#0063B1", "#F2C14E", "#0099BC")[i]))
            c.text(R(lx + 7 * u, y, 30 * u, 7 * u), t, "#FFFFFF", 3.5)
        gx = m.x() + m.width() * 0.48
        tw = (m.right() - gx - 4 * u) / 3
        cols = ("#0078D7", "#00B294", "#E81123", "#FF8C00", "#5C2D91", "#0063B1")
        for i in range(6):
            tr = R(gx + (i % 3) * (tw + u), m.y() + 4 * u + (i // 3) * (tw + u), tw, tw)
            c.fill(tr, C(cols[i]))
    elif style == "w11":
        mw, mh = c.w * 0.5, c.h * 0.7
        m = R(c.r.center().x() - mw / 2, c.Y(16) + shift, mw, mh)
        c.fill(m, rgba("#F7F9FC", 0.97), 2.5 * u, QtGui.QPen(C("#D6DDE8"), 1))
        sb = R(m.x() + 4 * u, m.y() + 3 * u, m.width() - 8 * u, 6 * u)
        c.fill(sb, C("#FFFFFF"), 3 * u, QtGui.QPen(C("#D6DDE8"), 1))
        c.text(sb.adjusted(3 * u, 0, 0, 0), "Поиск", "#777777", 3.2)
        c.text(R(m.x() + 4 * u, sb.bottom() + u, 30 * u, 6 * u), "Закреплённые", "#1A1A1A", 3.4, True)
        cols = ("#0078D7", "#F2C14E", "#2BB673", "#E0435A", "#7B5CE0", "#0099BC", "#FF8C00", "#5C2D91", "#00B294", "#E81123", "#3FA0E8", "#8E9AAF")
        cw = (m.width() - 8 * u) / 6
        for i in range(12):
            cx = m.x() + 4 * u + (i % 6) * cw + cw / 2
            cy = sb.bottom() + 11 * u + (i // 6) * 10 * u
            c.fill(R(cx - 3 * u, cy - 3 * u, 6 * u, 6 * u), C(cols[i]), 1.4 * u)
        c.text(R(m.x() + 4 * u, sb.bottom() + 27 * u, 30 * u, 6 * u), "Рекомендуем", "#1A1A1A", 3.4, True)
        for i in range(2):
            c.fill(R(m.x() + 4 * u + i * (m.width() / 2 - 2 * u), sb.bottom() + 34 * u, m.width() / 2 - 8 * u, 6 * u), C("#E9EEF5"), u)
    elif style == "mac":
        m = R(c.X(3), c.Y(8) + shift * 0.3, c.w * 0.3, c.h * 0.42)
        c.fill(m, rgba("#F2F2F2", 0.97), 1.6 * u, QtGui.QPen(C("#C8C8C8"), 1))
        for i, t in enumerate(("Об этом компьютере", "Системные настройки", "Магазин приложений", "Сон", "Перезагрузить", "Выключить")):
            y = m.y() + 2 * u + i * 6.4 * u
            if i == 0:
                c.fill(R(m.x() + u, y, m.width() - 2 * u, 6 * u), C("#007AFF"), u)
            c.text(R(m.x() + 3 * u, y, m.width(), 6 * u), t, "#FFFFFF" if i == 0 else "#1A1A1A", 3.2)
    p.restore()


def paint(painter, rect, style, menu=0.0, pack_pixmap=None, wallpaper=None, icons=None, start=None):
    painter.save()
    painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
    painter.setRenderHint(QtGui.QPainter.TextAntialiasing, True)
    painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, True)
    clip = QtGui.QPainterPath()
    clip.addRect(R(rect))
    painter.setClipPath(clip)
    c = Ctx(painter, rect)
    if pack_pixmap is not None and not pack_pixmap.isNull():
        src = pack_pixmap.size()
        scale = max(c.w / src.width(), c.h / src.height())
        sw, sh = c.w / scale, c.h / scale
        painter.drawPixmap(R(rect), pack_pixmap, R((src.width() - sw) / 2, (src.height() - sh) / 2, sw, sh))
    else:
        if wallpaper is not None and not wallpaper.isNull():
            src = wallpaper.size()
            scale = max(c.w / src.width(), c.h / src.height())
            sw, sh = c.w / scale, c.h / scale
            painter.drawPixmap(R(rect), wallpaper, R((src.width() - sw) / 2, (src.height() - sh) / 2, sw, sh))
        else:
            _bg(c, style)
        _icons_on_desktop(c, style, icons)
        titles = {"xp": "Мой компьютер", "w7": "Компьютер", "w10": "Проводник", "w11": "Проводник", "mac": "", "linux": ""}
        pos = {"w11": (22, 12, 50, 52), "mac": (18, 16, 56, 52), "linux": (18, 18, 56, 50)}.get(style, (15, 10, 52, 56))
        _window(c, *pos, titles.get(style, ""), style)
        _taskbar(c, style, start)
    _menu(c, style, menu)
    painter.restore()
