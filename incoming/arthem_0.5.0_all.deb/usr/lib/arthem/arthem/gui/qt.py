"""Совместимость с PySide6 (Qt 6) и PySide2 (Qt 5). Берём ту, что есть в системе."""

import os

QT6 = False
try:
    from PySide6 import QtCore, QtGui, QtWidgets  # noqa: F401
    QT6 = True
except ImportError:  # pragma: no cover - зависит от системы
    from PySide2 import QtCore, QtGui, QtWidgets  # noqa: F401

Qt = QtCore.Qt
Signal = QtCore.Signal
Slot = QtCore.Slot

QAction = QtGui.QAction if QT6 else QtWidgets.QAction


def exec_(obj, *args):
    fn = getattr(obj, "exec", None) or getattr(obj, "exec_")
    return fn(*args)


def make_app(argv):
    if not QT6:
        try:
            QtWidgets.QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
            QtWidgets.QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
        except AttributeError:
            pass
    os.environ.setdefault("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1")
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(argv)
    app.setApplicationName("Arthem")
    app.setOrganizationName("Arthem")
    app.setDesktopFileName("arthem") if hasattr(app, "setDesktopFileName") else None
    return app


def key_mods(event):
    m = event.modifiers()
    out = []
    if m & Qt.ControlModifier:
        out.append("Ctrl")
    if m & Qt.AltModifier:
        out.append("Alt")
    if m & Qt.ShiftModifier:
        out.append("Shift")
    if m & Qt.MetaModifier:
        out.append("Meta")
    return out


_KEYNAMES = None


def key_name(event):
    """Имя клавиши без модификаторов, совместимое с hotkeys.parse()."""
    global _KEYNAMES
    if _KEYNAMES is None:
        _KEYNAMES = {
            Qt.Key_Space: "Space", Qt.Key_Return: "Return", Qt.Key_Enter: "Return", Qt.Key_Tab: "Tab",
            Qt.Key_Backtab: "Tab", Qt.Key_Backspace: "Backspace", Qt.Key_Delete: "Delete", Qt.Key_Escape: "Escape",
            Qt.Key_Insert: "Insert", Qt.Key_Home: "Home", Qt.Key_End: "End", Qt.Key_PageUp: "PageUp",
            Qt.Key_PageDown: "PageDown", Qt.Key_Left: "Left", Qt.Key_Right: "Right", Qt.Key_Up: "Up",
            Qt.Key_Down: "Down", Qt.Key_Print: "Print", Qt.Key_Minus: "-", Qt.Key_Equal: "=",
        }
    k = event.key()
    if k in (Qt.Key_Control, Qt.Key_Shift, Qt.Key_Alt, Qt.Key_Meta, Qt.Key_Super_L, Qt.Key_Super_R, Qt.Key_AltGr):
        return ""
    if k in _KEYNAMES:
        return _KEYNAMES[k]
    if Qt.Key_F1 <= k <= Qt.Key_F35:
        return f"F{k - Qt.Key_F1 + 1}"
    if Qt.Key_0 <= k <= Qt.Key_9:
        return chr(k)
    if Qt.Key_A <= k <= Qt.Key_Z:
        return chr(k)
    # Shift+цифра даёт символ — восстановим цифру по коду клавиши
    text = event.text()
    sym = {"!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6", "&": "7", "*": "8", "(": "9", ")": "0",
           "\"": "2", "№": "3", ";": "4", ":": "6", "?": "7"}
    if text in sym:
        return sym[text]
    try:
        native = event.nativeVirtualKey()
        if 0x30 <= native <= 0x39:
            return chr(native)
        if 0x61 <= native <= 0x7A:
            return chr(native).upper()
    except Exception:
        pass
    return text.upper() if text and text.isprintable() else ""
