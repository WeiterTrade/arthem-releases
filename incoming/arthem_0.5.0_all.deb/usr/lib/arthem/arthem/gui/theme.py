"""Цветовые темы окна Arthem и таблица стилей Qt."""

THEMES = {
    "aristocrat": {
        "title": "Aristocrat Классика",
        "bg": "#0A0F1F", "side": "#0C1428", "card": "#102542", "card_hover": "#14305A",
        "border": "#2A2F45", "line": "#1A2238",
        "text": "#FFFFFF", "muted": "#A9B7CE", "soft": "#C9D6EA",
        "acc1": "#0B2D6B", "acc2": "#1E63D3", "glow": "#0086FF", "acc_border": "#4DA8FF",
        "gold": "#D4AF37", "gold_light": "#F7E7B8", "light": "#B7E0FF",
        "coin1": "#1E63D3", "coin2": "#0B2D6B",
    },
    "turquoise": {
        "title": "Бирюза",
        "bg": "#061416", "side": "#081C1F", "card": "#0C2A2E", "card_hover": "#10373C",
        "border": "#1F4549", "line": "#123034",
        "text": "#FFFFFF", "muted": "#9FC3C6", "soft": "#C6E4E6",
        "acc1": "#00596B", "acc2": "#00A7B8", "glow": "#00E5FF", "acc_border": "#5FF2FF",
        "gold": "#C9D3DB", "gold_light": "#EEF4F7", "light": "#A6F6FF",
        "coin1": "#00A7B8", "coin2": "#00475A",
    },
    "ruby": {
        "title": "Рубин",
        "bg": "#14070B", "side": "#1B0A10", "card": "#2B0F18", "card_hover": "#3A1521",
        "border": "#4A2230", "line": "#2E121B",
        "text": "#FFFFFF", "muted": "#D3A9B5", "soft": "#EBCFD6",
        "acc1": "#6B0B22", "acc2": "#C81E3F", "glow": "#FF3355", "acc_border": "#FF7A8E",
        "gold": "#D4AF37", "gold_light": "#F7E7B8", "light": "#FFC2CC",
        "coin1": "#C81E3F", "coin2": "#5A0A1C",
    },
    "anime": {
        "title": "Аниме",
        "bg": "#120A1F", "side": "#170D28", "card": "#24143D", "card_hover": "#2E1A4E",
        "border": "#3D2766", "line": "#251640",
        "text": "#FFFFFF", "muted": "#C9B3E6", "soft": "#E4D6F7",
        "acc1": "#7B2FF7", "acc2": "#FF4FB0", "glow": "#FF6AD5", "acc_border": "#FF9BE0",
        "gold": "#8FF3FF", "gold_light": "#E0FCFF", "light": "#FFC4EC",
        "coin1": "#FF4FB0", "coin2": "#5B1FB8",
    },
    "light": {
        "title": "Светлая",
        "bg": "#F4F6FB", "side": "#E9EEF7", "card": "#FFFFFF", "card_hover": "#F2F6FF",
        "border": "#D3DAE8", "line": "#DDE3EE",
        "text": "#0F1A2E", "muted": "#55627A", "soft": "#33405A",
        "acc1": "#1E63D3", "acc2": "#3D8BFF", "glow": "#3D8BFF", "acc_border": "#1E63D3",
        "gold": "#B08A1E", "gold_light": "#7A5C0A", "light": "#1E63D3",
        "coin1": "#1E63D3", "coin2": "#0B2D6B",
    },
}

ORDER = ["aristocrat", "turquoise", "ruby", "anime", "light"]


def get(name):
    return THEMES.get(name) or THEMES["aristocrat"]


def _indicators(t):
    """Картинки для галочек и переключателей (рисуются один раз в ~/.cache/arthem)."""
    import hashlib
    import os
    from pathlib import Path
    from .qt import QtCore, QtGui, Qt

    key = hashlib.md5((t["gold"] + t["border"] + t["bg"]).encode()).hexdigest()[:10]
    base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "arthem" / "ui" / key
    files = {n: base / f"{n}.png" for n in ("check_on", "check_off", "radio_on", "radio_off")}
    if all(f.exists() for f in files.values()):
        return {k: v.as_posix() for k, v in files.items()}
    base.mkdir(parents=True, exist_ok=True)
    size = 36  # рисуем в 2× для чётких краёв
    for name, path in files.items():
        img = QtGui.QImage(size, size, QtGui.QImage.Format_ARGB32_Premultiplied)
        img.fill(0)
        p = QtGui.QPainter(img)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        on = name.endswith("_on")
        rect = QtCore.QRectF(2, 2, size - 4, size - 4)
        if name.startswith("check"):
            p.setPen(QtGui.QPen(QtGui.QColor(t["gold"] if on else t["border"]), 3))
            p.setBrush(QtGui.QColor(t["gold"] if on else t["bg"]))
            p.drawRoundedRect(rect, 8, 8)
            if on:
                pen = QtGui.QPen(QtGui.QColor(t["bg"]), 4.5)
                pen.setCapStyle(Qt.RoundCap)
                pen.setJoinStyle(Qt.RoundJoin)
                p.setPen(pen)
                p.setBrush(Qt.NoBrush)
                path = QtGui.QPainterPath()
                path.moveTo(9, 18.5)
                path.lineTo(15.5, 25)
                path.lineTo(27.5, 11.5)
                p.drawPath(path)
        else:
            p.setPen(QtGui.QPen(QtGui.QColor(t["gold"] if on else t["border"]), 3))
            p.setBrush(QtGui.QColor(t["bg"]))
            p.drawEllipse(rect)
            if on:
                p.setPen(Qt.NoPen)
                p.setBrush(QtGui.QColor(t["gold"]))
                p.drawEllipse(QtCore.QRectF(10, 10, size - 20, size - 20))
        p.end()
        img.save(str(path))
    return {k: v.as_posix() for k, v in files.items()}


def stylesheet(t):
    try:
        ind = _indicators(t)
    except Exception:
        ind = None
    css = _stylesheet(t)
    if ind:
        css += f"""
QCheckBox::indicator {{ width: 18px; height: 18px; border: none; background: transparent; image: url({ind['check_off']}); }}
QCheckBox::indicator:checked {{ border: none; background: transparent; image: url({ind['check_on']}); }}
QRadioButton::indicator {{ width: 18px; height: 18px; border: none; background: transparent; image: url({ind['radio_off']}); }}
QRadioButton::indicator:checked {{ border: none; background: transparent; image: url({ind['radio_on']}); }}
"""
    return css


def _stylesheet(t):
    return f"""
* {{ font-family: "Manrope", "Inter", "Noto Sans", "Segoe UI", sans-serif; }}
QWidget#Root {{ background: {t['bg']}; border: 1px solid {t['border']}; border-radius: 16px; }}
QWidget {{ color: {t['text']}; font-size: 14px; }}
QLabel {{ background: transparent; }}
QLabel#Muted {{ color: {t['muted']}; }}
QLabel#H1 {{ font-size: 26px; font-weight: 800; }}
QLabel#H2 {{ font-size: 18px; font-weight: 800; }}
QLabel#Brand {{ font-family: "Cinzel", "Cormorant", "Liberation Serif", serif; font-size: 18px; font-weight: 700;
               color: {t['gold']}; }}
QLabel#Gold {{ color: {t['gold_light']}; font-weight: 700; }}
QLabel#Badge {{ font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 6px; }}
QLabel#Kbd {{ font-family: "JetBrains Mono", "DejaVu Sans Mono", monospace; font-size: 11px; color: {t['light']};
             padding: 3px 6px; border-radius: 6px; background: {t['bg']}; border: 1px solid {t['border']}; }}

QFrame#Side {{ background: {t['side']}; border-right: 1px solid {t['line']}; border-bottom-left-radius: 16px; }}
QFrame#Panel {{ background: {t['card']}; border: 1px solid {t['border']}; border-radius: 12px; }}
QFrame#Bottom {{ border-top: 1px solid {t['line']}; }}
QFrame#Sep {{ background: {t['line']}; max-height: 1px; min-height: 1px; }}

QFrame#Card {{ background: {t['card']}; border: 1.5px solid {t['border']}; border-radius: 14px; }}
QFrame#Card:hover {{ background: {t['card_hover']}; }}
QFrame#Card[selected="true"] {{ border: 1.5px solid {t['gold']}; }}
QFrame#Strip {{ background: {t['card']}; border: 1.5px solid {t['border']}; border-radius: 12px; }}
QFrame#Strip[selected="true"] {{ border: 1.5px solid {t['gold']}; }}

QPushButton {{ background: {t['card']}; border: 1px solid {t['border']}; border-radius: 12px;
              padding: 9px 18px; font-weight: 700; color: {t['text']}; }}
QPushButton:hover {{ background: {t['card_hover']}; }}
QPushButton:disabled {{ color: {t['muted']}; }}
QPushButton#Primary {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {t['acc1']}, stop:1 {t['acc2']});
              border: 1px solid {t['acc_border']}; color: #FFFFFF; font-weight: 800; padding: 11px 28px; }}
QPushButton#Primary:hover {{ border: 1px solid #FFFFFF; }}
QPushButton#Secondary {{ background: transparent; border: 1.5px solid {t['gold']}; color: {t['gold_light']}; }}
QPushButton#Secondary:hover {{ background: {t['card']}; }}
QPushButton#Nav {{ text-align: left; padding: 11px 14px; border-radius: 12px; border: 1px solid transparent;
              background: transparent; color: {t['muted']}; font-weight: 600; }}
QPushButton#Nav:hover {{ background: {t['card']}; color: {t['text']}; }}
QPushButton#Nav:checked {{ background: {t['card']}; border: 1px solid {t['border']}; color: {t['text']}; font-weight: 800; }}
QPushButton#Tab {{ padding: 8px 14px; border-radius: 10px; border: 1px solid transparent; background: transparent;
              color: {t['muted']}; font-weight: 600; }}
QPushButton#Tab:checked {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {t['acc1']}, stop:1 {t['acc2']});
              border: 1px solid {t['acc_border']}; color: #FFFFFF; font-weight: 700; }}
QPushButton#Round {{ border-radius: 16px; padding: 0; min-width: 32px; max-width: 32px; min-height: 32px; max-height: 32px; }}
QPushButton#RoundClose {{ border-radius: 16px; padding: 0; min-width: 32px; max-width: 32px; min-height: 32px; max-height: 32px;
              border: 1px solid {t['gold']}; color: {t['gold_light']}; }}

QCheckBox, QRadioButton {{ color: {t['soft']}; spacing: 8px; background: transparent; }}
QCheckBox::indicator, QRadioButton::indicator {{ width: 16px; height: 16px; }}
QCheckBox::indicator {{ border: 1.5px solid {t['border']}; border-radius: 4px; background: {t['bg']}; }}
QCheckBox::indicator:checked {{ background: {t['gold']}; border-color: {t['gold']}; }}
QRadioButton::indicator {{ border: 1.5px solid {t['border']}; border-radius: 9px; background: {t['bg']}; }}
QRadioButton::indicator:checked {{ background: {t['gold']}; border: 4px solid {t['bg']}; }}

QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {t['border']}; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QPlainTextEdit {{ background: {t['bg']}; border: 1px solid {t['border']}; border-radius: 10px;
                 font-family: "DejaVu Sans Mono", monospace; font-size: 12px; color: {t['soft']}; }}
QToolTip {{ background: {t['card']}; color: {t['text']}; border: 1px solid {t['border']}; padding: 6px; }}
QMessageBox, QDialog {{ background: {t['bg']}; }}
QMessageBox QLabel {{ color: {t['text']}; }}
QMenu {{ background: {t['card']}; border: 1px solid {t['border']}; padding: 6px; border-radius: 10px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 6px; }}
QMenu::item:selected {{ background: {t['card_hover']}; }}
"""
