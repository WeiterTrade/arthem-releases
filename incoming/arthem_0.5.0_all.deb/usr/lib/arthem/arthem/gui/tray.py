"""Значок Arthem в трее: быстрый выбор стиля."""

import sys

from .. import config, core, styles
from . import logo, theme
from .app import cli_process
from .qt import QAction, QtCore, QtWidgets, exec_, make_app


class Tray(QtCore.QObject):
    def __init__(self, app):
        super().__init__()
        self.app = app
        t = theme.get(config.load().get("ui_theme"))
        self.icon = QtWidgets.QSystemTrayIcon(logo.logo_icon(t))
        self.icon.setToolTip("Arthem")
        self.menu = QtWidgets.QMenu()
        self.menu.setStyleSheet(theme.stylesheet(t))
        self.menu.aboutToShow.connect(self.refresh)
        self.icon.setContextMenu(self.menu)
        self.icon.activated.connect(self._activated)
        self.refresh()
        self.icon.show()
        self.procs = []

    def refresh(self):
        self.menu.clear()
        active = core.active_style()
        for sid in styles.ORDER:
            act = QAction(styles.name(sid), self.menu)
            act.setCheckable(True)
            act.setChecked(sid == active)
            act.triggered.connect(lambda _=False, s=sid: self.run(["apply", s, "--quiet"]))
            self.menu.addAction(act)
        self.menu.addSeparator()
        op = QAction("Открыть Arthem", self.menu)
        op.triggered.connect(lambda: self.run(["gui"], wait=False))
        self.menu.addAction(op)
        qu = QAction("Скрыть значок", self.menu)
        qu.triggered.connect(self.app.quit)
        self.menu.addAction(qu)

    def run(self, args, wait=True):
        p = cli_process(self, args)
        self.procs.append(p)
        p.finished.connect(lambda *_: self.procs.remove(p) if p in self.procs else None)
        p.start()

    def _activated(self, reason):
        if reason == QtWidgets.QSystemTrayIcon.Trigger:
            self.run(["gui"], wait=False)


def main():
    app = make_app(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    if not QtWidgets.QSystemTrayIcon.isSystemTrayAvailable():
        return 0
    tray = Tray(app)  # noqa: F841
    return exec_(app)
