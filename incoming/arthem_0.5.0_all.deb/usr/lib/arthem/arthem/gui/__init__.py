"""Графический интерфейс Arthem (PySide6 или PySide2)."""
