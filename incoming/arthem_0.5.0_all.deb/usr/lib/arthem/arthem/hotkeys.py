"""Горячие клавиши: разбор, проверка на конфликты и регистрация в KDE, GNOME и Cinnamon.

Внутренний формат сочетания — как в Qt: "Ctrl+Alt+Shift+1", "Meta+F5", "Ctrl+Alt+Shift+Space".
"""

import configparser
import os
import re
import shlex
import sys
from pathlib import Path

from . import config, desktop, paths, styles, util

MODS = ("Ctrl", "Alt", "Shift", "Meta")
_MOD_ALIASES = {
    "ctrl": "Ctrl", "control": "Ctrl", "primary": "Ctrl", "ctl": "Ctrl",
    "alt": "Alt", "mod1": "Alt",
    "shift": "Shift",
    "meta": "Meta", "super": "Meta", "win": "Meta", "mod4": "Meta", "hyper": "Meta",
}
_KEY_ALIASES = {
    "del": "Delete", "delete": "Delete", "esc": "Escape", "escape": "Escape",
    "return": "Return", "enter": "Return", "space": "Space", "tab": "Tab",
    "backspace": "Backspace", "print": "Print", "sysreq": "Print",
    "pgup": "PageUp", "pageup": "PageUp", "prior": "PageUp",
    "pgdown": "PageDown", "pagedown": "PageDown", "next": "PageDown",
    "ins": "Insert", "insert": "Insert", "home": "Home", "end": "End",
    "left": "Left", "right": "Right", "up": "Up", "down": "Down",
    "minus": "-", "equal": "=", "plus": "+",
}
# Shift+цифра в некоторых оболочках записывается символом
_SHIFT_DIGITS = {"!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6", "&": "7", "*": "8", "(": "9", ")": "0"}


def _norm_key(k):
    k = k.strip()
    if not k:
        return ""
    low = k.lower()
    if low in _KEY_ALIASES:
        return _KEY_ALIASES[low]
    if re.fullmatch(r"f\d{1,2}", low):
        return low.upper()
    if len(k) == 1:
        return k.upper()
    if low.startswith("kp_") or low.startswith("xf86"):
        return k
    return k[:1].upper() + k[1:]


def canonical(mods, key):
    mods = [m for m in MODS if m in set(mods)]
    key = _norm_key(key)
    if key in _SHIFT_DIGITS:
        key = _SHIFT_DIGITS[key]
        if "Shift" not in mods:
            mods = [m for m in MODS if m in set(mods) | {"Shift"}]
    return "+".join(mods + ([key] if key else []))


def parse(text):
    """Разбирает 'Ctrl+Alt+1', '<Control><Alt>1', '<Super>l', 'Meta+Shift+S'. Возвращает (mods, key)."""
    if not text:
        return [], ""
    text = text.strip()
    mods = []
    if text.startswith("<"):
        for m in re.findall(r"<([^>]+)>", text):
            mm = _MOD_ALIASES.get(m.lower())
            if mm:
                mods.append(mm)
        key = re.sub(r"<[^>]+>", "", text)
    else:
        parts = text.split("+")
        key = ""
        # "Ctrl++" — клавиша плюс
        if text.endswith("++"):
            parts = text[:-2].split("+") + ["+"]
        for p in parts:
            mm = _MOD_ALIASES.get(p.strip().lower())
            if mm:
                mods.append(mm)
            else:
                key = p
    c = canonical(mods, key)
    if not c:
        return [], ""
    bits = c.split("+")
    if c.endswith("++"):
        return bits[:-2], "+"
    key = bits[-1] if bits[-1] not in MODS else ""
    return [b for b in bits if b in MODS], key


def norm(text):
    mods, key = parse(text)
    return canonical(mods, key)


def to_gtk(text):
    mods, key = parse(text)
    gm = {"Ctrl": "<Control>", "Alt": "<Alt>", "Shift": "<Shift>", "Meta": "<Super>"}
    k = {"Space": "space", "Return": "Return", "Delete": "Delete", "Escape": "Escape"}.get(key, key)
    if len(k) == 1 and k.isalpha():
        k = k.lower()
    return "".join(gm[m] for m in mods) + k


def to_kde(text):
    return norm(text)


def pretty(text):
    return norm(text).replace("Meta", "Super").replace("Space", "Пробел")


# ---------- зарезервированные сочетания ----------

BLOCKED = {
    "Ctrl+Alt+Delete": "перезагрузка/выход из системы",
    "Ctrl+Alt+Backspace": "перезапуск графической оболочки",
    "Ctrl+Shift+Escape": "системный монитор",
    "Ctrl+Escape": "меню приложений",
    "Alt+Tab": "переключение окон",
    "Alt+Shift+Tab": "переключение окон",
    "Meta+Tab": "переключение окон",
    "Alt+F1": "меню приложений",
    "Alt+F2": "окно запуска команды",
    "Alt+F4": "закрытие окна",
    "Alt+Space": "меню окна",
    "Meta+L": "блокировка экрана",
    "Meta+D": "показать рабочий стол",
    "Meta+A": "все приложения",
    "Meta+E": "файловый менеджер",
    "Meta+Space": "смена раскладки",
    "Alt+Shift": "смена раскладки",
    "Ctrl+Shift": "смена раскладки",
    "Print": "снимок экрана",
    "Shift+Print": "снимок экрана",
    "Alt+Print": "снимок окна",
}
for _i in range(1, 13):
    BLOCKED[f"Ctrl+Alt+F{_i}"] = "переключение на консоль"

# Сочетания, которые есть почти в каждой программе
_APP_LETTERS = set("ACVXZYSONPFWQTRHLDBIUGEKM")


def _desktop_bindings(de):
    """Возвращает {сочетание: описание} из настроек текущей оболочки."""
    found = {}
    if de in ("gnome", "cinnamon"):
        schemas = {
            "gnome": [
                "org.gnome.desktop.wm.keybindings",
                "org.gnome.shell.keybindings",
                "org.gnome.mutter.keybindings",
                "org.gnome.mutter.wayland.keybindings",
                "org.gnome.settings-daemon.plugins.media-keys",
            ],
            "cinnamon": [
                "org.cinnamon.desktop.keybindings.wm",
                "org.cinnamon.desktop.keybindings.media-keys",
                "org.cinnamon.desktop.keybindings",
                "org.cinnamon.muffin.keybindings",
            ],
        }[de]
        for schema in schemas:
            if not util.gs_has(schema):
                continue
            res = util.run(["gsettings", "list-recursively", schema], quiet=True)
            if not res or res.returncode != 0:
                continue
            for line in res.stdout.splitlines():
                parts = line.split(" ", 2)
                if len(parts) < 3:
                    continue
                _schema, key, val = parts
                vals = util.parse_strv(val) if val.startswith("[") or val.startswith("@as") else [util.parse_gv_string(val)]
                for v in vals:
                    if v and isinstance(v, str) and ("<" in v or len(v) <= 12):
                        c = norm(v)
                        if c and c != "":
                            found.setdefault(c, key)
        found.update(_custom_gtk_bindings(de))
    elif de == "kde":
        rc = paths.XDG_CONFIG / "kglobalshortcutsrc"
        if rc.is_file():
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            cp.optionxform = str
            try:
                cp.read(rc, encoding="utf-8")
            except configparser.Error:
                cp = None
            if cp:
                for sect in cp.sections():
                    if "arthem" in sect.lower():
                        continue
                    for key, val in cp.items(sect):
                        if key.startswith("_k_friendly_name"):
                            continue
                        active = val.split(",")[0]
                        desc = val.split(",")[-1] if "," in val else key
                        for sc in active.split("\t"):
                            sc = sc.strip()
                            if sc and sc.lower() != "none":
                                found.setdefault(norm(sc), desc or key)
    return found


def _custom_gtk_bindings(de):
    out = {}
    if de == "gnome":
        base = "org.gnome.settings-daemon.plugins.media-keys"
        lst = util.parse_strv(util.gs_get(base, "custom-keybindings"))
        for p in lst:
            if "/arthem-" in p:
                continue
            sch = f"{base}.custom-keybinding:{p}"
            b = util.parse_gv_string(util.gs_get(sch, "binding"))
            n = util.parse_gv_string(util.gs_get(sch, "name"))
            if b:
                out[norm(b)] = n or "своя команда"
    elif de == "cinnamon":
        lst = util.parse_strv(util.gs_get("org.cinnamon.desktop.keybindings", "custom-list"))
        for cid in lst:
            if cid.startswith("arthem-"):
                continue
            sch = f"org.cinnamon.desktop.keybindings.custom-keybinding:/org/cinnamon/desktop/keybindings/custom-keybindings/{cid}/"
            for b in util.parse_strv(util.gs_get(sch, "binding")):
                out[norm(b)] = util.parse_gv_string(util.gs_get(sch, "name")) or "своя команда"
    return out


class Check:
    OK = "ok"
    WARN = "warn"
    BLOCK = "block"

    def __init__(self, level, message):
        self.level = level
        self.message = message

    def __repr__(self):
        return f"Check({self.level!r}, {self.message!r})"


def check(seq, action=None, de=None, assigned=None):
    """Проверка сочетания для действия action (стиль или 'next')."""
    mods, key = parse(seq)
    c = canonical(mods, key)
    if not key:
        return Check(Check.BLOCK, "Нужна обычная клавиша вместе с Ctrl, Alt, Shift или Super.")
    if not mods:
        return Check(Check.BLOCK, "Одиночная клавиша будет мешать набору текста. Добавьте Ctrl, Alt или Super.")
    if c in BLOCKED:
        return Check(Check.BLOCK, f"Это системная комбинация ({BLOCKED[c]}). Выберите другую.")
    if set(mods) <= {"Ctrl", "Shift"} and len(key) == 1 and key in _APP_LETTERS:
        return Check(Check.BLOCK, "Это сочетание используется почти во всех программах. Выберите другое.")
    assigned = assigned if assigned is not None else config.load().get("hotkeys", {})
    for other, val in assigned.items():
        if other != action and val and norm(val) == c:
            who = "переключение по кругу" if other == "next" else f"стиль «{styles.name(other)}»"
            return Check(Check.BLOCK, f"Это сочетание уже назначено на {who} в Arthem.")
    de = de if de is not None else desktop.detect()
    if de:
        taken = _desktop_bindings(de)
        if c in taken:
            return Check(Check.BLOCK, f"Это сочетание уже занято в системе: «{taken[c]}». Выберите другое.")
    if len(mods) == 1:
        return Check(
            Check.WARN,
            "Сочетание с одной клавишей-модификатором может быть занято внутри программ. "
            "Надёжнее добавить ещё Shift или Ctrl.",
        )
    return Check(Check.OK, "Сочетание свободно.")


# ---------- регистрация ----------

def _cli_command(arg):
    exe = "/usr/bin/arthem" if os.path.exists("/usr/bin/arthem") else f"{sys.executable} -m arthem"
    return f"{exe} {arg}"


def _actions(cfg):
    if not cfg.get("hotkeys_enabled", True):
        return []
    out = []
    for action, seq in cfg.get("hotkeys", {}).items():
        if not seq:
            continue
        if action == "next":
            out.append(("next", "Arthem: следующий стиль", _cli_command("next --quiet"), seq))
        elif action in styles.STYLES:
            out.append((action, f"Arthem: {styles.name(action)}", _cli_command(f"apply {action} --quiet"), seq))
    return out


def _register_gnome(actions):
    base = "org.gnome.settings-daemon.plugins.media-keys"
    if not util.gs_has(base, "custom-keybindings"):
        return False
    lst = [p for p in util.parse_strv(util.gs_get(base, "custom-keybindings")) if "/arthem-" not in p]
    for action, title, cmd, seq in actions:
        path = f"/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/arthem-{action}/"
        sch = f"{base}.custom-keybinding:{path}"
        util.gs_set_raw(sch, "name", util.gv_str(title))
        util.gs_set_raw(sch, "command", util.gv_str(cmd))
        util.gs_set_raw(sch, "binding", util.gv_str(to_gtk(seq)))
        lst.append(path)
    return util.gs_set_raw(base, "custom-keybindings", util.gv_strv(lst))


def _register_cinnamon(actions):
    base = "org.cinnamon.desktop.keybindings"
    if not util.gs_has(base, "custom-list"):
        return False
    lst = [c for c in util.parse_strv(util.gs_get(base, "custom-list")) if not c.startswith("arthem-")]
    for action, title, cmd, seq in actions:
        cid = f"arthem-{action}"
        sch = f"{base}.custom-keybinding:/org/cinnamon/desktop/keybindings/custom-keybindings/{cid}/"
        util.gs_set_raw(sch, "name", util.gv_str(title))
        util.gs_set_raw(sch, "command", util.gv_str(cmd))
        util.gs_set_raw(sch, "binding", util.gv_strv([to_gtk(seq)]))
        lst.append(cid)
    return util.gs_set_raw(base, "custom-list", util.gv_strv(lst))


def _kde_desktop_file(action):
    return paths.USER_APPS / f"arthem-switch-{action}.desktop"


def _register_kde(actions):
    kw = util.first_cmd("kwriteconfig6", "kwriteconfig5")
    paths.USER_APPS.mkdir(parents=True, exist_ok=True)
    for old in paths.USER_APPS.glob("arthem-switch-*.desktop"):
        old.unlink()
    rc = paths.XDG_CONFIG / "kglobalshortcutsrc"
    # Удаляем наши старые секции
    if rc.is_file():
        text = rc.read_text(encoding="utf-8", errors="replace")
        text = re.sub(r"\n?\[services\]\[arthem-switch-[^\]]+\][^\[]*", "\n", text)
        rc.write_text(text, encoding="utf-8")
    for action, title, cmd, seq in actions:
        kde_seq = to_kde(seq)
        mods, key = parse(seq)
        alts = [kde_seq]
        if "Shift" in mods and key.isdigit():
            sym = {v: k for k, v in _SHIFT_DIGITS.items()}[key]
            alts.append("+".join([m for m in mods if m != "Shift"] + [sym]))
        df = _kde_desktop_file(action)
        df.write_text(
            "[Desktop Entry]\n"
            "Type=Application\n"
            f"Name={title}\n"
            f"Exec={cmd}\n"
            "Icon=arthem\n"
            "NoDisplay=true\n"
            "StartupNotify=false\n"
            f"X-KDE-Shortcuts={kde_seq}\n",
            encoding="utf-8",
        )
        if kw:
            util.run([kw, "--file", "kglobalshortcutsrc", "--group", "services", "--group", df.name,
                      "--key", "_launch", "\t".join(alts)])
    # Перечитать сочетания
    if util.have("systemctl"):
        r = util.run(["systemctl", "--user", "is-active", "plasma-kglobalaccel.service"], quiet=True)
        if r and r.stdout.strip() == "active":
            util.run(["systemctl", "--user", "restart", "plasma-kglobalaccel.service"], quiet=True)
            return True
    if util.have("kquitapp5") and util.have("kglobalaccel5"):
        util.run(["kquitapp5", "kglobalaccel"], quiet=True)
        util.spawn(["kglobalaccel5"])
    return True


def register(cfg=None, de=None):
    cfg = cfg or config.load()
    de = de or desktop.detect()
    actions = _actions(cfg)
    if de == "gnome":
        return _register_gnome(actions)
    if de == "cinnamon":
        return _register_cinnamon(actions)
    if de == "kde":
        return _register_kde(actions)
    return False


def unregister(de=None):
    de = de or desktop.detect()
    empty = {"hotkeys_enabled": False}
    if de == "gnome":
        return _register_gnome([])
    if de == "cinnamon":
        return _register_cinnamon([])
    if de == "kde":
        return _register_kde([])
    return False


def conflicts(cfg=None, de=None):
    """Список (действие, сочетание, сообщение) для занятых/запрещённых сочетаний."""
    cfg = cfg or config.load()
    out = []
    assigned = cfg.get("hotkeys", {})
    for action, seq in assigned.items():
        if not seq:
            continue
        res = check(seq, action, de=de, assigned=assigned)
        if res.level == Check.BLOCK:
            out.append((action, seq, res.message))
    return out
