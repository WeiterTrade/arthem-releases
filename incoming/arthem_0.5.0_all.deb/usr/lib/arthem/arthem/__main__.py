"""Командная строка Arthem.

    arthem                     открыть окно программы
    arthem apply <стиль>       xp | 7 | 10 | 11 | mac | linux
    arthem revert              вернуть исходное оформление
    arthem next                следующий стиль по кругу
    arthem status              текущее состояние
    arthem list                список стилей и наборов
    arthem pack install FILE   установить набор .arthem
    arthem pack remove СТИЛЬ   удалить набор пользователя
    arthem pack list           наборы
    arthem hotkeys apply       зарегистрировать горячие клавиши
    arthem hotkeys check       проверить клавиши на конфликты
    arthem session             запуск при входе в систему (автозапуск)
    arthem tray                значок в трее
"""

import argparse
import json
import sys

from . import __version__, config, core, hotkeys, packs, styles, util


def _cmd_apply(args):
    sid = styles.resolve(args.style)
    if not sid:
        print(f"Неизвестный стиль: {args.style}. Доступны: xp, 7, 10, 11, mac, linux", file=sys.stderr)
        return 2
    res = core.apply(sid, quiet=args.quiet)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=2, default=str))
    elif not args.quiet:
        print(f"Готово: {styles.name(sid)}")
        if res.get("relogin"):
            print("Выйдите из системы и войдите снова, чтобы появилась новая панель.")
    return 0


def _cmd_revert(args):
    res = core.revert(quiet=args.quiet)
    if not args.quiet:
        print("Исходное оформление возвращено." + (f" Ошибок: {res['errors']}" if res.get("errors") else ""))
    return 0


def _cmd_next(args):
    core.next_style()
    return 0


def _cmd_status(args):
    st = core.status()
    if args.json:
        print(json.dumps(st, ensure_ascii=False, indent=2))
    else:
        print(f"Оболочка: {st['desktop_name'] or 'не определена'}")
        print(f"Активный стиль: {styles.name(st['active'])}")
        if st["pending_relogin"]:
            print("Нужно выйти и войти снова, чтобы изменения появились полностью.")
        if st["packs"]:
            print("Наборы:")
            for k, v in st["packs"].items():
                print(f"  {styles.name(k)}: {v['summary']} ({'вшит' if v['origin'] == 'system' else 'добавлен'})")
    return 0


def _cmd_list(args):
    pk = packs.list_packs()
    cfg = config.load()
    for sid in styles.ORDER:
        mark = "оригинал" if sid in pk else ("исходный" if sid == "linux" else "встроенный")
        key = cfg["hotkeys"].get(sid, "")
        print(f"{sid:6} {styles.name(sid):15} {mark:10} {hotkeys.pretty(key) if key else ''}")
    return 0


def _cmd_pack(args):
    if args.pack_cmd == "install":
        try:
            p = packs.install(args.file)
        except (packs.PackError, OSError) as exc:
            print(f"Ошибка: {exc}", file=sys.stderr)
            util.notify("Arthem: набор не установлен", str(exc))
            return 1
        msg = f"Набор «{p.title}» установлен."
        print(msg)
        util.notify("Arthem", msg)
        return 0
    if args.pack_cmd == "remove":
        sid = styles.resolve(args.style) or args.style
        print("Удалено." if packs.remove(sid) else "Пользовательского набора для этого стиля нет.")
        return 0
    for sid, p in packs.list_packs().items():
        print(f"{sid:6} {p.title:15} {p.origin:7} {p.summary()}  [{p.root}]")
    return 0


def _cmd_hotkeys(args):
    if args.hk_cmd == "apply":
        ok = hotkeys.register()
        print("Горячие клавиши зарегистрированы." if ok else "Не удалось зарегистрировать клавиши в этой оболочке.")
        return 0 if ok else 1
    if args.hk_cmd == "remove":
        hotkeys.unregister()
        return 0
    if args.hk_cmd == "test":
        res = hotkeys.check(args.seq, args.action)
        print(f"{res.level}: {res.message}")
        return 0 if res.level != "block" else 1
    bad = hotkeys.conflicts()
    if not bad:
        print("Конфликтов нет.")
        return 0
    for action, seq, msg in bad:
        print(f"{styles.name(action) if action != 'next' else 'Следующий стиль'}: {hotkeys.pretty(seq)} — {msg}")
    return 1


def _cmd_session(args):
    from . import session
    return session.run(installed=args.installed)


def _cmd_gui(args):
    from .gui import app
    return app.main(page=getattr(args, "page", None), open_file=getattr(args, "file", None))


def _cmd_tray(args):
    from .gui import tray
    return tray.main()


def build_parser():
    p = argparse.ArgumentParser(prog="arthem", description="Arthem — оформление Linux в стиле Windows и macOS")
    p.add_argument("--version", action="version", version=f"Arthem {__version__}")
    sub = p.add_subparsers(dest="cmd")

    a = sub.add_parser("apply", help="применить стиль")
    a.add_argument("style")
    a.add_argument("--quiet", action="store_true")
    a.add_argument("--json", action="store_true")
    a.set_defaults(func=_cmd_apply)

    r = sub.add_parser("revert", help="вернуть исходное оформление")
    r.add_argument("--quiet", action="store_true")
    r.set_defaults(func=_cmd_revert)

    n = sub.add_parser("next", help="следующий стиль")
    n.add_argument("--quiet", action="store_true")
    n.set_defaults(func=_cmd_next)

    s = sub.add_parser("status", help="состояние")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=_cmd_status)

    sub.add_parser("list", help="стили").set_defaults(func=_cmd_list)

    pk = sub.add_parser("pack", help="наборы .arthem")
    pks = pk.add_subparsers(dest="pack_cmd")
    pi = pks.add_parser("install")
    pi.add_argument("file")
    prm = pks.add_parser("remove")
    prm.add_argument("style")
    pks.add_parser("list")
    pk.set_defaults(func=_cmd_pack, pack_cmd="list")

    hk = sub.add_parser("hotkeys", help="горячие клавиши")
    hks = hk.add_subparsers(dest="hk_cmd")
    hks.add_parser("apply")
    hks.add_parser("remove")
    hks.add_parser("check")
    ht = hks.add_parser("test")
    ht.add_argument("seq")
    ht.add_argument("--action", default=None)
    hk.set_defaults(func=_cmd_hotkeys, hk_cmd="check")

    se = sub.add_parser("session", help="запуск при входе в систему")
    se.add_argument("--installed", action="store_true", help="вызвано сразу после установки пакета")
    se.set_defaults(func=_cmd_session)

    g = sub.add_parser("gui", help="окно программы")
    g.add_argument("--page", default=None)
    g.add_argument("file", nargs="?", default=None, help="набор .arthem для установки")
    g.set_defaults(func=_cmd_gui)

    sub.add_parser("tray", help="значок в трее").set_defaults(func=_cmd_tray)
    return p


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    # Двойной клик по файлу .arthem: «arthem путь/к/файлу.arthem»
    if len(argv) == 1 and argv[0].lower().endswith(".arthem"):
        argv = ["gui", argv[0]]
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        args = parser.parse_args(["gui"])
    try:
        return args.func(args) or 0
    except core.ArthemError as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        util.notify("Arthem", str(exc))
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
