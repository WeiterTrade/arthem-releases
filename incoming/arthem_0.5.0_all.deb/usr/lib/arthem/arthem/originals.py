"""Тема из оригинальных картинок .msstyles (из набора .arthem): заголовки окон, кнопки, элементы GTK,
панель задач, кнопки окон на панели и трей. Строится поверх встроенной темы Arthem."""

import json
from pathlib import Path

from . import paths


def load(pack):
    if not pack:
        return None
    mf = pack.root / "msstyles" / "manifest.json"
    if not mf.is_file():
        return None
    try:
        data = json.loads(mf.read_text(encoding="utf-8"))
    except ValueError:
        return None
    data["_dir"] = str(mf.parent)
    return data if data.get("parts") else None


class _P:
    def __init__(self, ms, key):
        self.d = ms["parts"].get(key)
        self.dir = Path(ms["_dir"])

    def __bool__(self):
        return bool(self.d)

    def url(self, i):
        frames = self.d["frames"]
        i = i if i < len(frames) else 0
        return (self.dir / frames[i]).as_uri()

    def n(self):
        return len(self.d["frames"])

    @property
    def w(self):
        return self.d["w"]

    @property
    def h(self):
        return self.d["h"]

    def border_image(self, i, gtk=True):
        l, r, t, b = self.d.get("margins") or [0, 0, 0, 0]
        if gtk:
            return (f'border-image: url("{self.url(i)}") {t} {r} {b} {l} stretch stretch; border-style: solid; '
                    f'border-width: {t}px {r}px {b}px {l}px; background-image: none; background-color: transparent; box-shadow: none;')
        return f'border-image: url("{self.url(i)}") {t} {r} {b} {l}; background-image: none; background-color: transparent; background-gradient-direction: none; box-shadow: none;'


def gtk_css(ms):
    css = ["/* Arthem: элементы из оригинального визуального стиля */"]
    cap = _P(ms, "caption")
    if cap:
        l, r, t, b = cap.d.get("margins") or [0, 0, 0, 0]
        inner = max(16, cap.h - t - b)
        css.append(f"""
headerbar.titlebar, .titlebar:not(headerbar), headerbar.default-decoration, .titlebar.default-decoration {{
  {cap.border_image(0)} min-height: {inner}px; border-radius: 0; padding-top: 0; padding-bottom: 0;
}}
headerbar.titlebar:backdrop, .titlebar:not(headerbar):backdrop, headerbar.default-decoration:backdrop, .titlebar.default-decoration:backdrop {{
  {cap.border_image(1)}
}}""")
        if cap.d.get("text"):
            css.append(f"headerbar .title, .titlebar .title {{ color: {cap.d['text']}; }}")
    for key, gtk in (("btn_close", "close"), ("btn_min", "minimize"), ("btn_max", "maximize")):
        p = _P(ms, key)
        if not p:
            continue
        inactive = 4 if p.n() > 4 else 0
        css.append(f"""
button.titlebutton.{gtk} {{ min-width: {p.w}px; min-height: {p.h}px; background-size: {p.w}px {p.h}px; background-image: url("{p.url(0)}"); border: none; }}
button.titlebutton.{gtk}:hover {{ background-image: url("{p.url(1)}"); }}
button.titlebutton.{gtk}:active {{ background-image: url("{p.url(2)}"); }}
button.titlebutton.{gtk}:backdrop {{ background-image: url("{p.url(inactive)}"); }}""")
    rs = _P(ms, "btn_restore")
    if rs:
        css.append(f""".maximized button.titlebutton.maximize {{ background-image: url("{rs.url(0)}"); }}
.maximized button.titlebutton.maximize:hover {{ background-image: url("{rs.url(1)}"); }}""")

    pb = _P(ms, "pushbutton")
    if pb:
        css.append(f"""
button:not(.titlebutton):not(.flat) {{ {pb.border_image(0)} }}
button:not(.titlebutton):not(.flat):hover {{ {pb.border_image(1)} }}
button:not(.titlebutton):not(.flat):active, button:not(.titlebutton):not(.flat):checked {{ {pb.border_image(2)} }}
button:not(.titlebutton):not(.flat):disabled {{ {pb.border_image(3)} }}
button.default:not(.titlebutton), button.suggested-action {{ {pb.border_image(4)} }}""")
    for key, node, states in (
        ("checkbox", "check", [("", 0), (":hover", 1), (":active", 2), (":disabled", 3), (":checked", 4),
                               (":checked:hover", 5), (":checked:active", 6), (":checked:disabled", 7), (":indeterminate", 8)]),
        ("radio", "radio", [("", 0), (":hover", 1), (":active", 2), (":disabled", 3), (":checked", 4),
                            (":checked:hover", 5), (":checked:active", 6), (":checked:disabled", 7)]),
    ):
        p = _P(ms, key)
        if not p:
            continue
        for st, i in states:
            if i >= p.n():
                continue
            extra = (f"min-width: {p.w}px; min-height: {p.h}px; border: none; border-radius: 0; box-shadow: none; "
                     f"background-color: transparent; -gtk-icon-source: none; background-size: {p.w}px {p.h}px; "
                     "background-repeat: no-repeat; background-position: center;") if st == "" else ""
            css.append(f'{node}{st} {{ {extra} background-image: url("{p.url(i)}"); }}')
    for key, sel in (("scroll_thumb_v", "scrollbar.vertical slider"), ("scroll_thumb_h", "scrollbar.horizontal slider")):
        p = _P(ms, key)
        if p:
            css.append(f"{sel} {{ {p.border_image(0)} border-radius: 0; min-width: {min(p.w, 17)}px; min-height: {min(p.h, 17)}px; margin: 0; }}")
            css.append(f"{sel}:hover {{ {p.border_image(1)} }}")
            css.append(f"{sel}:active {{ {p.border_image(2)} }}")
    for key, sel in (("scroll_track_v", "scrollbar.vertical trough"), ("scroll_track_h", "scrollbar.horizontal trough")):
        p = _P(ms, key)
        if p:
            css.append(f"{sel} {{ {p.border_image(0)} border-radius: 0; }}")
    bar = _P(ms, "progress_bar")
    if bar:
        css.append(f"progressbar trough {{ {bar.border_image(0)} border-radius: 0; min-height: {bar.h}px; }}")
    chunk = _P(ms, "progress_chunk") or _P(ms, "progress_fill")
    if chunk:
        if ms.get("kind") == "xp":
            css.append(f'progressbar progress {{ background-image: url("{chunk.url(0)}"); background-repeat: repeat-x; '
                       f"background-size: {chunk.w}px 100%; background-color: transparent; border: none; border-radius: 0; }}")
        else:
            css.append(f"progressbar progress {{ {chunk.border_image(0)} border-radius: 0; }}")
    tab = _P(ms, "tab_item")
    if tab:
        css.append(f"notebook > header tab {{ {tab.border_image(0)} border-radius: 0; }}")
        css.append(f"notebook > header tab:hover {{ {tab.border_image(1)} }}")
        css.append(f"notebook > header tab:checked {{ {tab.border_image(2)} }}")
    return "\n".join(css) + "\n"


def cinnamon_css(ms):
    css = []
    tb = _P(ms, "taskbar")
    if tb:
        css.append(f"#panel.panel-bottom {{ {tb.border_image(0, gtk=False)} }}")
    btn = _P(ms, "taskbtn")
    if btn:
        sel = "#panel.panel-bottom .window-list-item-box, #panel.panel-bottom .grouped-window-list-item-box"
        css.append(f"{sel} {{ {btn.border_image(0, gtk=False)} }}")
        hov = ", ".join(f"{s.strip()}:hover" for s in sel.split(","))
        css.append(f"{hov} {{ {btn.border_image(1, gtk=False)} }}")
        act_i = 4 if btn.n() > 4 else 2
        act = ", ".join(f"{s.strip()}{st}" for s in sel.split(",") for st in (":focus", ":checked", ":active"))
        css.append(f"{act} {{ {btn.border_image(act_i, gtk=False)} }}")
        if btn.d.get("text"):
            css.append(f"#panel.panel-bottom .window-list-item-label {{ color: {btn.d['text']}; }}")
    tray = _P(ms, "tray")
    if tray:
        css.append(f"#panel.panel-bottom #panelRight, #panel.panel-bottom .panelRight {{ {tray.border_image(0, gtk=False)} }}")
    return "\n".join(css) + "\n"


def start_frames(ms):
    p = _P(ms, "start")
    if not p:
        return None
    return {"frames": [str(Path(ms["_dir"]) / f) for f in p.d["frames"]], "margins": p.d.get("margins"),
            "w": p.w, "h": p.h, "text": p.d.get("text")}


def build_gtk_theme(style_theme, ms, backup):
    """Создаёт ~/.local/share/themes/<тема>-Original поверх встроенной темы и возвращает её имя."""
    name = f"{style_theme}-Original"
    root = paths.XDG_DATA / "themes" / name
    gtk3 = root / "gtk-3.0"
    gtk3.mkdir(parents=True, exist_ok=True)
    base = paths.PREFIX / "share" / "themes" / style_theme / "gtk-3.0" / "gtk.css"
    if not base.is_file():
        base = paths.XDG_DATA / "themes" / style_theme / "gtk-3.0" / "gtk.css"
    (gtk3 / "gtk.css").write_text(f'@import url("{base.as_uri()}");\n' + gtk_css(ms), encoding="utf-8")
    # кнопки-картинки встроенной темы указаны относительно её папки — дадим ссылку на metacity-1
    meta = base.parent.parent / "metacity-1"
    link = root / "metacity-1"
    if meta.is_dir() and not link.exists():
        try:
            link.symlink_to(meta)
        except OSError:
            pass
    (root / "index.theme").write_text(
        f"[Desktop Entry]\nType=X-GNOME-Metatheme\nName={name}\nComment=Arthem: оригинальный стиль\n\n"
        f"[X-GNOME-Metatheme]\nGtkTheme={name}\nMetacityTheme={style_theme}\n", encoding="utf-8")
    backup.add_created(str(root))
    return name
