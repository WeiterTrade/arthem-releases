"""Главная логика: применить стиль, откатить, следующий стиль, состояние."""

import fcntl
import os
import time

from . import backup as backup_mod
from . import config, desktop, paths, resources, styles, util


class ArthemError(Exception):
    pass


class _Lock:
    """Не даём двум переключениям идти одновременно (например, при быстром нажатии клавиш)."""

    def __init__(self):
        paths.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.path = paths.DATA_DIR / "apply.lock"
        self.fh = None

    def __enter__(self):
        self.fh = open(self.path, "w")
        deadline = time.time() + 60
        while True:
            try:
                fcntl.flock(self.fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except OSError:
                if time.time() > deadline:
                    raise ArthemError("Другое переключение стиля ещё идёт.")
                time.sleep(0.3)

    def __exit__(self, *exc):
        try:
            fcntl.flock(self.fh, fcntl.LOCK_UN)
            self.fh.close()
        except OSError:
            pass


def active_style():
    return config.load_state().get("active", "linux")


def apply(style_id, quiet=False):
    style_id = styles.resolve(style_id) or style_id
    styles.get(style_id)
    if style_id == "linux":
        return revert(quiet=quiet)
    de = desktop.detect()
    be = desktop.backend(de)
    if not be:
        raise ArthemError(
            "Не удалось определить оболочку. Поддерживаются KDE Plasma, GNOME и Cinnamon "
            "(переменная XDG_CURRENT_DESKTOP)."
        )
    paths.ensure_dirs()
    cfg = config.load()
    with _Lock():
        bk = backup_mod.Backup()
        util.log("применяю", style_id, "в", de)
        result = be.apply(style_id, cfg, bk)
        config.set_state(
            active=style_id,
            desktop=de,
            applied_at=int(time.time()),
            pending_relogin=bool(result.get("relogin")),
        )
    if not quiet:
        msg = f"Стиль «{styles.name(style_id)}» применён."
        if result.get("relogin"):
            msg += " Чтобы появилась панель, выйдите из системы и войдите снова."
        util.notify("Arthem", msg)
    return result


def revert(quiet=False):
    de = desktop.detect()
    be = desktop.backend(de)
    bk = backup_mod.Backup()
    if not bk.exists():
        config.set_state(active="linux")
        if not quiet:
            util.notify("Arthem", "Оформление уже исходное.")
        return {"errors": 0}
    with _Lock():
        if be:
            result = be.revert(bk)
        else:
            result = {"errors": bk.restore()}
        bk.clear()
        config.set_state(active="linux", pending_relogin=False)
    if not quiet:
        util.notify("Arthem", "Возвращено исходное оформление Linux.")
    return result


def next_style():
    order = styles.ORDER
    cur = active_style()
    idx = order.index(cur) if cur in order else -1
    nxt = order[(idx + 1) % len(order)]
    return apply(nxt)


def startup_sound_path():
    st = active_style()
    if st == "linux":
        return None
    from . import packs
    pk = packs.get(st)
    if pk and pk.startup_sound():
        return pk.startup_sound()
    return resources.builtin_sound(st)


def status():
    from . import packs
    de = desktop.detect()
    st = config.load_state()
    return {
        "desktop": de,
        "desktop_name": desktop.pretty_name(de) if de else None,
        "active": st.get("active", "linux"),
        "pending_relogin": st.get("pending_relogin", False),
        "packs": {k: {"origin": v.origin, "title": v.title, "summary": v.summary()} for k, v in packs.list_packs().items()},
        "share": str(paths.SHARE),
    }
