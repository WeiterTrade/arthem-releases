"""Картинки без внешних библиотек: BMP из ресурсов Windows → RGBA, разрезание спрайтов, запись PNG."""

import struct
import zlib


class Image:
    def __init__(self, w, h, rgba=None):
        self.w, self.h = w, h
        self.px = bytearray(rgba) if rgba is not None else bytearray(w * h * 4)

    def crop(self, x, y, w, h):
        out = Image(w, h)
        for row in range(h):
            src = ((y + row) * self.w + x) * 4
            out.px[row * w * 4:(row + 1) * w * 4] = self.px[src:src + w * 4]
        return out

    def split(self, count, vertical=True):
        if count <= 1:
            return [self]
        if vertical:
            fh = self.h // count
            return [self.crop(0, i * fh, self.w, fh) for i in range(count)]
        fw = self.w // count
        return [self.crop(i * fw, 0, fw, self.h) for i in range(count)]

    def key_out(self, rgb):
        """Цвет-ключ (обычно пурпурный 255,0,255) → прозрачность."""
        r, g, b = rgb
        p = self.px
        for i in range(0, len(p), 4):
            if p[i] == r and p[i + 1] == g and p[i + 2] == b:
                p[i + 3] = 0

    def save_png(self, path):
        raw = bytearray()
        stride = self.w * 4
        for y in range(self.h):
            raw.append(0)
            raw += self.px[y * stride:(y + 1) * stride]

        def chunk(tag, data):
            c = tag + data
            return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)

        png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0))
        png += chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
        with open(path, "wb") as fh:
            fh.write(png)


def from_dib(data):
    """DIB из ресурса BITMAP (или файл .bmp) → Image. Поддерживает 1/4/8/24/32 бит без сжатия."""
    if data[:2] == b"BM":
        data = data[14:]
    hsize = struct.unpack_from("<I", data, 0)[0]
    if hsize == 12:
        w, h, _planes, bpp = struct.unpack_from("<HHHH", data, 4)
        comp, clr_used = 0, 0
        pal_entry = 3
    else:
        w, h, _planes, bpp, comp = struct.unpack_from("<iiHHI", data, 4)
        clr_used = struct.unpack_from("<I", data, 32)[0] if hsize >= 36 else 0
        pal_entry = 4
    if comp not in (0, 3):
        raise ValueError(f"сжатый BMP (compression={comp}) не поддерживается")
    top_down = h < 0
    h = abs(h)
    off = hsize
    masks = None
    if comp == 3 and hsize == 40:
        masks = struct.unpack_from("<III", data, off)
        off += 12
    palette = []
    if bpp <= 8:
        n = clr_used or (1 << bpp)
        for i in range(n):
            b, g, r = data[off + i * pal_entry: off + i * pal_entry + 3]
            palette.append((r, g, b))
        off += n * pal_entry
    stride = ((w * bpp + 31) // 32) * 4
    img = Image(w, h)
    has_alpha = False
    for y in range(h):
        row = off + (y if top_down else h - 1 - y) * stride
        dst = y * w * 4
        for x in range(w):
            if bpp == 32:
                b, g, r, a = data[row + x * 4: row + x * 4 + 4]
                if a:
                    has_alpha = True
            elif bpp == 24:
                b, g, r = data[row + x * 3: row + x * 3 + 3]
                a = 255
            elif bpp == 16:
                v = struct.unpack_from("<H", data, row + x * 2)[0]
                r, g, b = ((v >> 10) & 31) << 3, ((v >> 5) & 31) << 3, (v & 31) << 3
                a = 255
            else:
                bit = x * bpp
                byte = data[row + bit // 8]
                shift = 8 - bpp - (bit % 8)
                idx = (byte >> shift) & ((1 << bpp) - 1)
                r, g, b = palette[idx] if idx < len(palette) else (0, 0, 0)
                a = 255
            img.px[dst + x * 4: dst + x * 4 + 4] = bytes((r, g, b, a))
    if bpp == 32 and not has_alpha:
        for i in range(3, len(img.px), 4):
            img.px[i] = 255
    elif bpp == 32:
        # Windows хранит предумноженную альфу — вернём обычную
        p = img.px
        for i in range(0, len(p), 4):
            a = p[i + 3]
            if 0 < a < 255:
                p[i] = min(255, p[i] * 255 // a)
                p[i + 1] = min(255, p[i + 1] * 255 // a)
                p[i + 2] = min(255, p[i + 2] * 255 // a)
    return img


def from_png(data):
    """Минимальный декодер PNG (8 бит, RGB/RGBA/серый, без чересстрочности) — для спрайтов Vista+."""
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("не PNG")
    pos = 8
    idat = b""
    w = h = ctype = depth = 0
    plte = None
    trns = None
    while pos < len(data):
        n = struct.unpack_from(">I", data, pos)[0]
        tag = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + n]
        if tag == b"IHDR":
            w, h, depth, ctype, _c, _f, inter = struct.unpack(">IIBBBBB", body)
            if depth != 8 or inter:
                raise ValueError("PNG: поддерживается только 8 бит без чересстрочности")
        elif tag == b"PLTE":
            plte = body
        elif tag == b"tRNS":
            trns = body
        elif tag == b"IDAT":
            idat += body
        elif tag == b"IEND":
            break
        pos += 12 + n
    raw = zlib.decompress(idat)
    bpp = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    stride = w * bpp
    prev = bytearray(stride)
    img = Image(w, h)
    i = 0
    for y in range(h):
        f = raw[i]
        i += 1
        line = bytearray(raw[i:i + stride])
        i += stride
        for x in range(stride):
            a = line[x - bpp] if x >= bpp else 0
            b = prev[x]
            c = prev[x - bpp] if x >= bpp else 0
            if f == 1:
                line[x] = (line[x] + a) & 255
            elif f == 2:
                line[x] = (line[x] + b) & 255
            elif f == 3:
                line[x] = (line[x] + ((a + b) >> 1)) & 255
            elif f == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                line[x] = (line[x] + pr) & 255
        prev = line
        for x in range(w):
            o = (y * w + x) * 4
            if ctype == 6:
                img.px[o:o + 4] = line[x * 4:x * 4 + 4]
            elif ctype == 2:
                img.px[o:o + 4] = bytes(line[x * 3:x * 3 + 3]) + b"\xff"
            elif ctype == 0:
                v = line[x]
                img.px[o:o + 4] = bytes((v, v, v, 255))
            elif ctype == 4:
                v, al = line[x * 2], line[x * 2 + 1]
                img.px[o:o + 4] = bytes((v, v, v, al))
            else:
                idx = line[x]
                r, g, b = plte[idx * 3:idx * 3 + 3]
                al = trns[idx] if trns and idx < len(trns) else 255
                img.px[o:o + 4] = bytes((r, g, b, al))
    return img
