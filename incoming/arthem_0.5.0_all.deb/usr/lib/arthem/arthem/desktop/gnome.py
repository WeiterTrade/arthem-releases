"""GNOME: тема GTK, иконки, звуки, обои, кнопки окон и расширения для панели и меню.

Для стилей Windows нужны Dash to Panel (панель задач) и ArcMenu (меню «Пуск»),
для macOS — Dash to Dock. Если расширений нет, Arthem скачивает их с extensions.gnome.org.
"""

import json
import os
import re
import tempfile
import urllib.request
from pathlib import Path

from .. import paths, resources, styles, util

DTP = "dash-to-panel@jderose9.github.com"
ARCMENU = "arcmenu@arcmenu.com"
DOCK = "dash-to-dock@micxgx.gmail.com"
UBUNTU_DOCK = "ubuntu-dock@ubuntu.com"

SCHEMA = {
    DTP: "org.gnome.shell.extensions.dash-to-panel",
    ARCMENU: "org.gnome.shell.extensions.arcmenu",
    DOCK: "org.gnome.shell.extensions.dash-to-dock",
    UBUNTU_DOCK: "org.gnome.shell.extensions.dash-to-dock",
}

EGO = "https://extensions.gnome.org"


def shell_major():
    res = util.run(["gnome-shell", "--version"], quiet=True)
    if res and res.returncode == 0:
        m = re.search(r"(\d+)", res.stdout)
        if m:
            return m.group(1)
    return None


def ext_dir(uuid):
    for base in (
        paths.XDG_DATA / "gnome-shell" / "extensions",
        Path("/usr/local/share/gnome-shell/extensions"),
        Path("/usr/share/gnome-shell/extensions"),
    ):
        d = base / uuid
        if d.is_dir():
            return d
    return None


def installed(uuid):
    return ext_dir(uuid) is not None


def schemadir_for(uuid):
    schema = SCHEMA.get(uuid)
    if schema and schema in util.gs_schemas():
        return None
    d = ext_dir(uuid)
    if d and (d / "schemas" / "gschemas.compiled").is_file():
        return str(d / "schemas")
    return None


def download_extension(uuid):
    """Скачивает и ставит расширение в домашнюю папку. Возвращает True при успехе."""
    major = shell_major()
    if not major or not util.have("gnome-extensions"):
        return False
    try:
        url = f"{EGO}/extension-info/?uuid={uuid}&shell_version={major}"
        with urllib.request.urlopen(url, timeout=20) as resp:
            meta = json.loads(resp.read().decode("utf-8"))
        dl = meta.get("download_url")
        if not dl:
            return False
        with urllib.request.urlopen(EGO + dl, timeout=60) as resp:
            data = resp.read()
    except Exception as exc:  # сеть, 404 для этой версии GNOME и т.п.
        util.log("не скачалось расширение", uuid, exc)
        return False
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as fh:
        fh.write(data)
        tmp = fh.name
    try:
        res = util.run(["gnome-extensions", "install", "--force", tmp], timeout=60)
        ok = bool(res and res.returncode == 0)
    finally:
        os.unlink(tmp)
    if ok:
        util.reset_caches()
    return ok


class Gnome:
    name = "gnome"

    def __init__(self):
        self.needs_relogin = False

    # ---------- расширения ----------

    def _ensure(self, uuid):
        if installed(uuid):
            return True
        util.info(f"Скачиваю расширение {uuid}…")
        if download_extension(uuid):
            self.needs_relogin = True  # новое расширение загрузится только после перезахода
            return True
        util.notify(
            "Не удалось установить расширение",
            f"{uuid}. Установите его через «Расширения» или менеджер пакетов.",
        )
        return False

    def _set_enabled(self, backup, enable=(), disable=()):
        backup.record_gs("org.gnome.shell", "enabled-extensions")
        backup.record_gs("org.gnome.shell", "disabled-extensions")
        if util.gs_has("org.gnome.shell", "disable-user-extensions"):
            backup.set_gs("org.gnome.shell", "disable-user-extensions", "false")
        enabled = util.parse_strv(util.gs_get("org.gnome.shell", "enabled-extensions"))
        disabled = util.parse_strv(util.gs_get("org.gnome.shell", "disabled-extensions"))
        for u in enable:
            if u not in enabled:
                enabled.append(u)
            if u in disabled:
                disabled.remove(u)
        for u in disable:
            if u in enabled:
                enabled.remove(u)
            if u not in disabled and installed(u):
                disabled.append(u)
        util.gs_set_raw("org.gnome.shell", "enabled-extensions", util.gv_strv(enabled))
        util.gs_set_raw("org.gnome.shell", "disabled-extensions", util.gv_strv(disabled))

    def _ext_set(self, backup, uuid, key, value):
        sd = schemadir_for(uuid)
        schema = SCHEMA[uuid]
        if util.gs_has(schema, key, sd):
            return backup.set_gs(schema, key, value, sd)
        return False

    def _json_per_monitor(self, uuid, key, make_value):
        """Ключи Dash to Panel хранят JSON по мониторам. Меняем все известные мониторы."""
        sd = schemadir_for(uuid)
        cur = util.parse_gv_string(util.gs_get(SCHEMA[uuid], key, sd)) if util.gs_has(SCHEMA[uuid], key, sd) else None
        if cur is None:
            return False
        try:
            data = json.loads(cur) if cur else {}
        except ValueError:
            data = {}
        monitors = list(data.keys()) or ["0"]
        new = {m: make_value(data.get(m)) for m in monitors}
        return self._ext_set(self._backup, uuid, key, util.gv_str(json.dumps(new)))

    def _configure_dtp(self, style_id):
        st = styles.get(style_id)
        b = self._backup
        pnl = st["panel"]
        self._ext_set(b, DTP, "panel-position", "'BOTTOM'")
        self._json_per_monitor(DTP, "panel-positions", lambda _old: "BOTTOM")
        self._json_per_monitor(DTP, "panel-sizes", lambda _old: pnl["height"])
        self._ext_set(b, DTP, "panel-size", str(pnl["height"]))
        self._ext_set(b, DTP, "show-activities-button", "false")
        self._ext_set(b, DTP, "show-showdesktop-button", "true")
        self._ext_set(b, DTP, "dot-position", "'BOTTOM'")
        self._ext_set(b, DTP, "dot-style-focused", "'METRO'")
        self._ext_set(b, DTP, "dot-style-unfocused", "'METRO'")
        self._ext_set(b, DTP, "trans-use-custom-bg", "true")
        self._ext_set(b, DTP, "trans-bg-color", util.gv_str(st["panel_color"]))
        self._ext_set(b, DTP, "trans-use-custom-opacity", "true")
        self._ext_set(b, DTP, "trans-panel-opacity", str(st["panel_opacity"]))
        # XP: подписи окон на панели (не группировать), остальные — значки
        self._ext_set(b, DTP, "group-apps", "false" if pnl["labels"] else "true")

        center = pnl["center"]

        def elements(old):
            order = [
                ("showAppsButton", False), ("activitiesButton", False), ("leftBox", True),
                ("taskbar", True), ("centerBox", True), ("rightBox", True),
                ("dateMenu", True), ("systemMenu", True), ("desktopButton", True),
            ]
            res = []
            for el, vis in order:
                if el in ("leftBox", "taskbar"):
                    pos = "centered" if center else "stackedTL"
                elif el in ("showAppsButton", "activitiesButton"):
                    pos = "stackedTL"
                else:
                    pos = "stackedBR"
                res.append({"element": el, "visible": vis, "position": pos})
            return res

        self._json_per_monitor(DTP, "panel-element-positions", elements)

    def _configure_arcmenu(self, style_id, start_icon):
        st = styles.get(style_id)
        b = self._backup
        if st.get("gnome_menu_layout"):
            self._ext_set(b, ARCMENU, "menu-layout", util.gv_str(st["gnome_menu_layout"]))
        if start_icon:
            self._ext_set(b, ARCMENU, "menu-button-icon", "'Custom_Icon'")
            self._ext_set(b, ARCMENU, "custom-menu-button-icon", util.gv_str(str(start_icon)))
            self._ext_set(b, ARCMENU, "custom-menu-button-icon-size", "28.0")
        self._ext_set(b, ARCMENU, "position-in-panel", "'Center'" if st["panel"]["center"] else "'Left'")

    def _configure_dock(self, uuid):
        b = self._backup
        self._ext_set(b, uuid, "dock-position", "'BOTTOM'")
        self._ext_set(b, uuid, "extend-height", "false")
        self._ext_set(b, uuid, "dock-fixed", "false")
        self._ext_set(b, uuid, "intellihide", "true")
        self._ext_set(b, uuid, "dash-max-icon-size", "48")
        self._ext_set(b, uuid, "show-apps-at-top", "false")

    # ---------- основное ----------

    def apply(self, style_id, cfg, backup):
        self._backup = backup
        st = styles.get(style_id)
        res = resources.Resources(style_id, cfg, backup)

        iface = "org.gnome.desktop.interface"
        backup.set_gs(iface, "gtk-theme", util.gv_str(res.gtk_theme))
        if res.icon_theme:
            backup.set_gs(iface, "icon-theme", util.gv_str(res.icon_theme))
        if res.cursor_theme:
            backup.set_gs(iface, "cursor-theme", util.gv_str(res.cursor_theme))
        backup.set_gs(iface, "color-scheme", "'prefer-light'")
        if util.gs_has(iface, "accent-color"):
            backup.set_gs(iface, "accent-color", "'blue'")
        backup.set_gs(iface, "enable-hot-corners", "true" if style_id == "mac" else "false")

        layout = "close,minimize,maximize:appmenu" if st["buttons"] == "left" else "appmenu:minimize,maximize,close"
        backup.set_gs("org.gnome.desktop.wm.preferences", "button-layout", util.gv_str(layout))

        if res.wallpaper:
            uri = util.gv_str(Path(res.wallpaper).as_uri())
            backup.set_gs("org.gnome.desktop.background", "picture-uri", uri)
            backup.set_gs("org.gnome.desktop.background", "picture-uri-dark", uri)
            backup.set_gs("org.gnome.desktop.background", "picture-options", "'zoom'")

        if res.sound_theme:
            backup.set_gs("org.gnome.desktop.sound", "theme-name", util.gv_str(res.sound_theme))
            backup.set_gs("org.gnome.desktop.sound", "event-sounds", "true")

        resources.write_gtk4_css(style_id, backup)

        if style_id == "mac":
            dock = UBUNTU_DOCK if installed(UBUNTU_DOCK) else DOCK
            if dock == DOCK:
                self._ensure(DOCK)
            self._set_enabled(backup, enable=[dock], disable=[DTP, ARCMENU])
            if installed(dock):
                self._configure_dock(dock)
        else:
            have_dtp = self._ensure(DTP)
            have_arc = self._ensure(ARCMENU)
            self._set_enabled(
                backup,
                enable=[u for u, ok in ((DTP, have_dtp), (ARCMENU, have_arc)) if ok],
                disable=[UBUNTU_DOCK, DOCK],
            )
            if have_dtp:
                self._configure_dtp(style_id)
            if have_arc:
                self._configure_arcmenu(style_id, res.start_icon)

        return {"relogin": self.needs_relogin, "resources": res.describe()}

    def revert(self, backup):
        errors = backup.restore()
        return {"errors": errors}

    def reload(self):
        pass
