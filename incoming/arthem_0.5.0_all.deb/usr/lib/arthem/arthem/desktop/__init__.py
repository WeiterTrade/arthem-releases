"""Определение рабочего окружения и выбор модуля, который умеет его настраивать."""

import os

from .. import util


def detect():
    """Возвращает 'kde', 'gnome', 'cinnamon' или None."""
    forced = os.environ.get("ARTHEM_DESKTOP")
    if forced:
        return forced
    raw = ":".join(
        os.environ.get(v, "") for v in ("XDG_CURRENT_DESKTOP", "XDG_SESSION_DESKTOP", "DESKTOP_SESSION")
    ).lower()
    if "kde" in raw or "plasma" in raw:
        return "kde"
    if "cinnamon" in raw:
        return "cinnamon"
    if any(x in raw for x in ("gnome", "ubuntu", "pop", "zorin", "unity")):
        return "gnome"
    if os.environ.get("KDE_FULL_SESSION"):
        return "kde"
    if os.environ.get("GNOME_DESKTOP_SESSION_ID"):
        return "gnome"
    return None


def pretty_name(de):
    if de == "kde":
        ver = plasma_version()
        return f"KDE Plasma {ver}" if ver else "KDE Plasma"
    if de == "gnome":
        res = util.run(["gnome-shell", "--version"], quiet=True)
        if res and res.returncode == 0:
            return res.stdout.strip().replace("Shell ", "")
        return "GNOME"
    if de == "cinnamon":
        res = util.run(["cinnamon", "--version"], quiet=True)
        if res and res.returncode == 0:
            return res.stdout.strip()
        return "Cinnamon"
    return "Неизвестная оболочка"


def plasma_version():
    res = util.run(["plasmashell", "--version"], quiet=True)
    if res and res.returncode == 0:
        parts = res.stdout.strip().split()
        if parts:
            return parts[-1].split(".")[0]
    if util.have("plasma-apply-lookandfeel") and util.have("kwriteconfig6"):
        return "6"
    if util.have("kwriteconfig5"):
        return "5"
    return ""


def backend(de=None):
    de = de or detect()
    if de == "kde":
        from . import kde
        return kde.KDE()
    if de == "gnome":
        from . import gnome
        return gnome.Gnome()
    if de == "cinnamon":
        from . import cinnamon
        return cinnamon.Cinnamon()
    return None
