"""Док в стиле macOS через Plank (короткий, по центру, с увеличением значков).

Plank ставится из репозитория (sudo apt install plank / sudo dnf install plank).
Arthem пишет тему Plank, настраивает док, добавляет автозапуск и убирает всё при откате.
"""

import os
from pathlib import Path
from urllib.parse import quote

from .. import paths, util

THEME = "Arthem-Mac"
SCHEMA = "net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/"
AUTOSTART = paths.XDG_CONFIG / "autostart" / "arthem-plank.desktop"
LAUNCHERS = paths.XDG_CONFIG / "plank" / "dock1" / "launchers"

THEME_TEXT = """[PlankTheme]
TopRoundness=14
BottomRoundness=14
LineWidth=1
OuterStrokeColor=255;;255;;255;;120
FillStartColor=246;;246;;246;;150
FillEndColor=236;;236;;236;;135
InnerStrokeColor=255;;255;;255;;70

[PlankDockTheme]
HorizPadding=6
TopPadding=-3
BottomPadding=4
ItemPadding=6
IndicatorSize=3
IconShadowSize=1
UrgentBounceHeight=1.6666666666666667
LaunchBounceHeight=0.625
FadeOpacity=1
ClickTime=300
UrgentBounceTime=600
LaunchBounceTime=600
ActiveTime=300
SlideTime=300
FadeTime=250
HideTime=150
GlowSize=30
GlowTime=10000
GlowPulseTime=2000
UrgentHueShift=150
ItemMoveTime=450
CascadeHide=true
"""

DEFAULT_APPS = [
    "nemo.desktop", "org.gnome.Nautilus.desktop", "firefox.desktop", "firefox_firefox.desktop", "google-chrome.desktop",
    "chromium.desktop", "thunderbird.desktop", "org.gnome.Terminal.desktop", "gnome-terminal.desktop",
    "xed.desktop", "org.gnome.TextEditor.desktop", "libreoffice-writer.desktop", "mintinstall.desktop",
    "org.gnome.Software.desktop", "cinnamon-settings.desktop",
]


def available():
    return util.have("plank")


def _desktop_path(app_id):
    for base in (paths.XDG_DATA / "applications", Path("/usr/local/share/applications"),
                 Path("/usr/share/applications"), Path("/var/lib/snapd/desktop/applications"),
                 Path("/var/lib/flatpak/exports/share/applications")):
        p = base / app_id
        if p.is_file():
            return p
    return None


def _favorites():
    ids = util.parse_strv(util.gs_get("org.cinnamon", "favorite-apps")) if util.gs_has("org.cinnamon", "favorite-apps") else []
    out, seen = [], set()
    for app_id in ids + DEFAULT_APPS:
        p = _desktop_path(app_id)
        if p and app_id not in seen:
            seen.add(app_id)
            out.append((app_id, p))
        if len(out) >= 9:
            break
    return out


def _write_launchers(backup):
    """Значки в доке, только если пользователь ещё не настраивал Plank."""
    if LAUNCHERS.is_dir() and any(LAUNCHERS.glob("*.dockitem")):
        return
    LAUNCHERS.mkdir(parents=True, exist_ok=True)
    backup.add_created(str(LAUNCHERS.parent))
    for app_id, path in _favorites():
        name = app_id[:-len(".desktop")] if app_id.endswith(".desktop") else app_id
        (LAUNCHERS / f"{name}.dockitem").write_text(
            f"[PlankDockItemPreferences]\nLauncher=file://{quote(str(path))}\n", encoding="utf-8")


def enable(backup):
    if not available():
        return False
    theme_dir = paths.XDG_DATA / "plank" / "themes" / THEME
    theme_dir.mkdir(parents=True, exist_ok=True)
    (theme_dir / "dock.theme").write_text(THEME_TEXT, encoding="utf-8")
    backup.add_created(str(theme_dir))
    _write_launchers(backup)
    for key, val in (
        ("theme", f"'{THEME}'"),
        ("position", "'bottom'"),
        ("alignment", "'center'"),
        ("icon-size", "48"),
        ("zoom-enabled", "true"),
        ("zoom-percent", "160"),
        ("hide-mode", "'window-dodge'"),
        ("pressure-reveal", "false"),
        ("show-dock-item", "false"),
        ("lock-items", "false"),
    ):
        backup.set_gs(SCHEMA, key, val)
    AUTOSTART.parent.mkdir(parents=True, exist_ok=True)
    if not AUTOSTART.exists():
        backup.add_created(str(AUTOSTART))
    AUTOSTART.write_text(
        "[Desktop Entry]\nType=Application\nName=Plank (Arthem macOS)\nExec=plank\nIcon=plank\n"
        "X-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Delay=3\nNoDisplay=true\n", encoding="utf-8")
    running = util.run(["pgrep", "-x", "plank"], quiet=True)
    if not (running and running.returncode == 0):
        util.spawn(["plank"])
    return True


def disable():
    """Убрать док, если его включал Arthem (при смене стиля на другой)."""
    if AUTOSTART.exists():
        try:
            os.remove(AUTOSTART)
        except OSError:
            pass
        util.run(["pkill", "-x", "plank"], quiet=True)
