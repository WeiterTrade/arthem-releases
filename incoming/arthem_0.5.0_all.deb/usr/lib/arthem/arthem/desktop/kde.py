"""KDE Plasma 5/6: панели (через скрипт plasmashell), тема Plasma, цвета, иконки, курсоры, звуки,
кнопки окон и обои."""

import glob
import json
import os
import time
from pathlib import Path

from .. import paths, resources, styles, util
from . import plasma_version

CONFIG_FILES = [
    "plasma-org.kde.plasma.desktop-appletsrc",
    "plasmashellrc",
    "kdeglobals",
    "kwinrc",
    "plasmarc",
    "kcminputrc",
    "ksplashrc",
    "gtk-3.0/settings.ini",
    "gtk-4.0/settings.ini",
]


def kwrite_cmd():
    return util.first_cmd("kwriteconfig6", "kwriteconfig5")


def kread_cmd():
    return util.first_cmd("kreadconfig6", "kreadconfig5")


def kwrite(backup, file, groups, key, value):
    cmd = kwrite_cmd()
    if not cmd:
        return False
    backup.record_file(paths.XDG_CONFIG / file)
    args = [cmd, "--file", file]
    for g in groups:
        args += ["--group", g]
    args += ["--key", key, str(value)]
    res = util.run(args)
    return bool(res and res.returncode == 0)


def dbus_call(dest, path, method, *args):
    """Вызов D-Bus метода сеанса. args — строки. Пробуем qdbus/gdbus/dbus-send."""
    for tool in ("qdbus6", "qdbus", "qdbus-qt5"):
        if util.have(tool):
            res = util.run([tool, dest, path, method] + list(args), timeout=60)
            if res and res.returncode == 0:
                return True
    if util.have("gdbus"):
        res = util.run(
            ["gdbus", "call", "--session", "--dest", dest, "--object-path", path, "--method", method] + list(args),
            timeout=60,
        )
        if res and res.returncode == 0:
            return True
    if util.have("dbus-send"):
        iface, _, meth = method.rpartition(".")
        res = util.run(
            ["dbus-send", "--session", "--type=method_call", "--print-reply", f"--dest={dest}", path, method]
            + [f"string:{a}" for a in args],
            timeout=60,
        )
        if res and res.returncode == 0:
            return True
    return False


def js_str(s):
    return json.dumps(str(s))


def layout_script(style_id, start_icon, wallpaper):
    """Скрипт для plasmashell: убирает панели и строит панель в стиле системы."""
    st = styles.get(style_id)
    pnl = st["panel"]
    icon = js_str(str(start_icon) if start_icon else "start-here-kde")
    wall = js_str(Path(wallpaper).as_uri()) if wallpaper else "null"
    launchers = js_str("preferred://filemanager,preferred://browser")
    return f"""
var STYLE = {js_str(style_id)};
var ICON = {icon};
var WALL = {wall};
function tryset(obj, key, val) {{ try {{ obj[key] = val; }} catch (e) {{}} }}
function cfg(w, group, key, val) {{ try {{ w.currentConfigGroup = group; w.writeConfig(key, val); }} catch (e) {{}} }}

var old = panels();
for (var i = 0; i < old.length; i++) {{ old[i].remove(); }}

function addMenu(p, kind) {{
  var m = p.addWidget(kind);
  if (kind === "org.kde.plasma.kicker") {{
    cfg(m, ["General"], "useCustomButtonImage", "true");
    cfg(m, ["General"], "customButtonImage", ICON);
  }}
  cfg(m, ["General"], "icon", ICON);
  return m;
}}
function addTasks(p, labels, fill) {{
  var t = p.addWidget(labels ? "org.kde.plasma.taskmanager" : "org.kde.plasma.icontasks");
  cfg(t, ["General"], "launchers", {launchers});
  if (!fill) cfg(t, ["General"], "fill", "false");
  return t;
}}
function addTray(p, showDesktop) {{
  p.addWidget("org.kde.plasma.systemtray");
  p.addWidget("org.kde.plasma.digitalclock");
  if (showDesktop) p.addWidget("org.kde.plasma.showdesktop");
}}

if (STYLE === "mac") {{
  var top = new Panel;
  top.location = "top";
  top.height = 28;
  tryset(top, "floating", false);
  addMenu(top, "org.kde.plasma.kickoff");
  try {{ top.addWidget("org.kde.plasma.appmenu"); }} catch (e) {{}}
  top.addWidget("org.kde.plasma.panelspacer");
  addTray(top, false);

  var dock = new Panel;
  dock.location = "bottom";
  dock.height = 56;
  tryset(dock, "floating", true);
  tryset(dock, "alignment", "center");
  tryset(dock, "lengthMode", "fit");
  tryset(dock, "hiding", "dodgewindows");
  addTasks(dock, false, false);
}} else {{
  var p = new Panel;
  p.location = "bottom";
  p.height = {pnl["height"]};
  tryset(p, "floating", false);
  var center = {str(pnl["center"]).lower()};
  if (center) p.addWidget("org.kde.plasma.panelspacer");
  var kind = (STYLE === "xp" || STYLE === "w7") ? "org.kde.plasma.kicker" : "org.kde.plasma.kickoff";
  addMenu(p, kind);
  addTasks(p, {str(pnl["labels"]).lower()}, !center);
  if (center) p.addWidget("org.kde.plasma.panelspacer");
  addTray(p, STYLE !== "xp");
}}

if (WALL) {{
  var ds = desktops();
  for (var j = 0; j < ds.length; j++) {{
    ds[j].wallpaperPlugin = "org.kde.image";
    ds[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    ds[j].writeConfig("Image", WALL);
  }}
}}
"""


def _plasma_changeicons():
    cands = glob.glob("/usr/lib*/*/libexec/plasma-changeicons") + glob.glob("/usr/lib*/libexec/plasma-changeicons")
    cands += ["/usr/libexec/plasma-changeicons"]
    for c in cands:
        if os.access(c, os.X_OK):
            return c
    return None


class KDE:
    name = "kde"

    def __init__(self):
        self.version = plasma_version() or "6"

    def _record_all(self, backup):
        for f in CONFIG_FILES:
            backup.record_file(paths.XDG_CONFIG / f)

    def apply(self, style_id, cfg, backup):
        st = styles.get(style_id)
        self._record_all(backup)
        res = resources.Resources(style_id, cfg, backup)

        lnf_tool = util.first_cmd("plasma-apply-lookandfeel", "lookandfeeltool")
        if lnf_tool:
            util.run([lnf_tool, "-a", st["kde_lnf"]], timeout=120)

        if util.have("plasma-apply-colorscheme"):
            util.run(["plasma-apply-colorscheme", st["kde_colors"]])
        else:
            kwrite(backup, "kdeglobals", ["General"], "ColorScheme", st["kde_colors"])

        if util.have("plasma-apply-desktoptheme"):
            util.run(["plasma-apply-desktoptheme", res.plasma_theme])
        else:
            kwrite(backup, "plasmarc", ["Theme"], "name", res.plasma_theme)

        if res.icon_theme:
            tool = _plasma_changeicons()
            if tool:
                util.run([tool, res.icon_theme])
            else:
                kwrite(backup, "kdeglobals", ["Icons"], "Theme", res.icon_theme)

        if res.cursor_theme:
            if util.have("plasma-apply-cursortheme"):
                util.run(["plasma-apply-cursortheme", res.cursor_theme])
            else:
                kwrite(backup, "kcminputrc", ["Mouse"], "cursorTheme", res.cursor_theme)

        if res.sound_theme:
            kwrite(backup, "kdeglobals", ["Sounds"], "Theme", res.sound_theme)
            kwrite(backup, "kdeglobals", ["Sounds"], "Enable", "true")

        # Кнопки окон
        if st["buttons"] == "left":
            kwrite(backup, "kwinrc", ["org.kde.kdecoration2"], "ButtonsOnLeft", "XIA")
            kwrite(backup, "kwinrc", ["org.kde.kdecoration2"], "ButtonsOnRight", "")
        else:
            kwrite(backup, "kwinrc", ["org.kde.kdecoration2"], "ButtonsOnLeft", "M")
            kwrite(backup, "kwinrc", ["org.kde.kdecoration2"], "ButtonsOnRight", "IAX")
        dbus_call("org.kde.KWin", "/KWin", "org.kde.KWin.reconfigure")

        # GTK-программы внутри KDE
        for gtkver in ("gtk-3.0", "gtk-4.0"):
            kwrite(backup, f"{gtkver}/settings.ini", ["Settings"], "gtk-theme-name", res.gtk_theme)
            if res.icon_theme:
                kwrite(backup, f"{gtkver}/settings.ini", ["Settings"], "gtk-icon-theme-name", res.icon_theme)
        resources.write_gtk4_css(style_id, backup)
        if util.gs_has("org.gnome.desktop.interface", "gtk-theme"):
            backup.set_gs("org.gnome.desktop.interface", "gtk-theme", util.gv_str(res.gtk_theme))

        # Панели и обои — скриптом прямо в работающий plasmashell
        script = layout_script(style_id, res.start_icon, res.wallpaper)
        ok = dbus_call("org.kde.plasmashell", "/PlasmaShell", "org.kde.PlasmaShell.evaluateScript", script)
        if not ok and res.wallpaper and util.have("plasma-apply-wallpaperimage"):
            util.run(["plasma-apply-wallpaperimage", str(res.wallpaper)])
        if not ok:
            util.log("plasmashell не принял скрипт панели")
        return {"relogin": False, "resources": res.describe(), "panel_ok": ok}

    # ---------- откат ----------

    def _stop_plasmashell(self):
        if util.have("systemctl"):
            r = util.run(["systemctl", "--user", "is-active", "plasma-plasmashell.service"], quiet=True)
            if r and r.stdout.strip() == "active":
                util.run(["systemctl", "--user", "stop", "plasma-plasmashell.service"], timeout=60)
                return "systemd"
        tool = util.first_cmd("kquitapp6", "kquitapp5")
        if tool:
            util.run([tool, "plasmashell"], timeout=60, quiet=True)
        time.sleep(1)
        return "plain"

    def _start_plasmashell(self, how):
        if how == "systemd":
            util.run(["systemctl", "--user", "start", "plasma-plasmashell.service"], timeout=60)
            return
        for cmd in (["kstart", "plasmashell"], ["kstart5", "plasmashell"], ["plasmashell", "--replace"]):
            if util.spawn(cmd):
                return

    def revert(self, backup):
        how = self._stop_plasmashell()
        try:
            errors = backup.restore()
        finally:
            self._start_plasmashell(how)
        # Подтянуть восстановленные цвета/иконки/тему
        cs = util.run([kread_cmd() or "kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "ColorScheme"], quiet=True)
        if cs and cs.returncode == 0 and cs.stdout.strip() and util.have("plasma-apply-colorscheme"):
            util.run(["plasma-apply-colorscheme", cs.stdout.strip()])
        dbus_call("org.kde.KWin", "/KWin", "org.kde.KWin.reconfigure")
        return {"errors": errors}

    def reload(self):
        pass
