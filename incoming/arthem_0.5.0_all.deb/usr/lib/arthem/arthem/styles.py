"""Описание стилей. Один источник правды для движка, генератора ресурсов и интерфейса."""

ORDER = ["xp", "w7", "w10", "w11", "mac", "linux"]

STYLES = {
    "xp": {
        "name": "Windows XP",
        "short": "XP",
        "theme": "Arthem-XP",           # GTK-тема, иконки, звуки, тема Plasma
        "kde_lnf": "org.arthem.xp",
        "kde_colors": "ArthemXP",
        "accent": "#316AC5",
        "buttons": "right",
        "panel": {"position": "bottom", "height": 30, "center": False, "labels": True},
        "gnome_menu_layout": "Redmond",
        "panel_color": "#245EDB",
        "panel_opacity": 1.0,
        "desc": "Синяя объёмная панель, зелёная кнопка «пуск», меню в две колонки и подписи на кнопках окон.",
    },
    "w7": {
        "name": "Windows 7",
        "short": "7",
        "theme": "Arthem-7",
        "kde_lnf": "org.arthem.w7",
        "kde_colors": "Arthem7",
        "accent": "#3399FF",
        "buttons": "right",
        "panel": {"position": "bottom", "height": 40, "center": False, "labels": False},
        "gnome_menu_layout": "Redmond",
        "panel_color": "#1C3A5A",
        "panel_opacity": 0.85,
        "desc": "Стеклянная панель, круглая кнопка «Пуск», меню с поиском и крупные значки без подписей.",
    },
    "w10": {
        "name": "Windows 10",
        "short": "10",
        "theme": "Arthem-10",
        "kde_lnf": "org.arthem.w10",
        "kde_colors": "Arthem10",
        "accent": "#0078D7",
        "buttons": "right",
        "panel": {"position": "bottom", "height": 40, "center": False, "labels": False},
        "gnome_menu_layout": "Windows",
        "panel_color": "#101318",
        "panel_opacity": 0.97,
        "desc": "Тёмная плоская панель, меню со списком приложений и плитками, поиск рядом с «Пуском».",
    },
    "w11": {
        "name": "Windows 11",
        "short": "11",
        "theme": "Arthem-11",
        "kde_lnf": "org.arthem.w11",
        "kde_colors": "Arthem11",
        "accent": "#005FB8",
        "buttons": "right",
        "panel": {"position": "bottom", "height": 48, "center": True, "labels": False},
        "gnome_menu_layout": "Eleven",
        "panel_color": "#1F1F1F",
        "panel_opacity": 0.9,
        "desc": "Значки и «Пуск» по центру, скруглённые окна, меню с сеткой закреплённых приложений.",
    },
    "mac": {
        "name": "macOS",
        "short": "macOS",
        "theme": "Arthem-Mac",
        "kde_lnf": "org.arthem.mac",
        "kde_colors": "ArthemMac",
        "accent": "#007AFF",
        "buttons": "left",
        "panel": {"position": "top", "height": 28, "center": False, "labels": False},
        "gnome_menu_layout": None,
        "panel_color": "#F2F2F2",
        "panel_opacity": 0.8,
        "desc": "Строка меню сверху, док внизу по центру, цветные кнопки окон слева.",
    },
    "linux": {
        "name": "Обычный Linux",
        "short": "Linux",
        "theme": None,
        "desc": "Возврат к оформлению, которое было до Arthem.",
    },
}

WINDOWS_STYLES = ("xp", "w7", "w10", "w11")


def get(style_id):
    if style_id not in STYLES:
        raise KeyError(f"Неизвестный стиль: {style_id}. Доступны: {', '.join(ORDER)}")
    return STYLES[style_id]


def name(style_id):
    return STYLES.get(style_id, {}).get("name", style_id)


def resolve(text):
    """Понимает разные написания: 'win7', '7', 'windows 7', 'xp', 'mac', 'macos'."""
    t = (text or "").strip().lower().replace(" ", "").replace("-", "").replace("_", "")
    aliases = {
        "xp": "xp", "winxp": "xp", "windowsxp": "xp",
        "7": "w7", "w7": "w7", "win7": "w7", "windows7": "w7",
        "10": "w10", "w10": "w10", "win10": "w10", "windows10": "w10",
        "11": "w11", "w11": "w11", "win11": "w11", "windows11": "w11",
        "mac": "mac", "macos": "mac", "osx": "mac",
        "linux": "linux", "revert": "linux", "default": "linux", "0": "linux",
    }
    return aliases.get(t)
