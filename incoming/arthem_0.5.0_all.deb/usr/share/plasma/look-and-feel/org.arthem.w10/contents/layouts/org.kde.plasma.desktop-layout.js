
var STYLE = "w10";
var ICON = "/usr/share/arthem/start/w10.png";
var WALL = "file:///usr/share/arthem/wallpapers/w10.png";
function tryset(obj, key, val) { try { obj[key] = val; } catch (e) {} }
function cfg(w, group, key, val) { try { w.currentConfigGroup = group; w.writeConfig(key, val); } catch (e) {} }

var old = panels();
for (var i = 0; i < old.length; i++) { old[i].remove(); }

function addMenu(p, kind) {
  var m = p.addWidget(kind);
  if (kind === "org.kde.plasma.kicker") {
    cfg(m, ["General"], "useCustomButtonImage", "true");
    cfg(m, ["General"], "customButtonImage", ICON);
  }
  cfg(m, ["General"], "icon", ICON);
  return m;
}
function addTasks(p, labels, fill) {
  var t = p.addWidget(labels ? "org.kde.plasma.taskmanager" : "org.kde.plasma.icontasks");
  cfg(t, ["General"], "launchers", "preferred://filemanager,preferred://browser");
  if (!fill) cfg(t, ["General"], "fill", "false");
  return t;
}
function addTray(p, showDesktop) {
  p.addWidget("org.kde.plasma.systemtray");
  p.addWidget("org.kde.plasma.digitalclock");
  if (showDesktop) p.addWidget("org.kde.plasma.showdesktop");
}

if (STYLE === "mac") {
  var top = new Panel;
  top.location = "top";
  top.height = 28;
  tryset(top, "floating", false);
  addMenu(top, "org.kde.plasma.kickoff");
  try { top.addWidget("org.kde.plasma.appmenu"); } catch (e) {}
  top.addWidget("org.kde.plasma.panelspacer");
  addTray(top, false);

  var dock = new Panel;
  dock.location = "bottom";
  dock.height = 56;
  tryset(dock, "floating", true);
  tryset(dock, "alignment", "center");
  tryset(dock, "lengthMode", "fit");
  tryset(dock, "hiding", "dodgewindows");
  addTasks(dock, false, false);
} else {
  var p = new Panel;
  p.location = "bottom";
  p.height = 40;
  tryset(p, "floating", false);
  var center = false;
  if (center) p.addWidget("org.kde.plasma.panelspacer");
  var kind = (STYLE === "xp" || STYLE === "w7") ? "org.kde.plasma.kicker" : "org.kde.plasma.kickoff";
  addMenu(p, kind);
  addTasks(p, false, !center);
  if (center) p.addWidget("org.kde.plasma.panelspacer");
  addTray(p, STYLE !== "xp");
}

if (WALL) {
  var ds = desktops();
  for (var j = 0; j < ds.length; j++) {
    ds[j].wallpaperPlugin = "org.kde.image";
    ds[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    ds[j].writeConfig("Image", WALL);
  }
}
