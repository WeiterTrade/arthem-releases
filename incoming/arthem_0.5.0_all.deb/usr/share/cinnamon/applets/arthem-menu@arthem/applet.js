// Arthem: меню «Пуск» для Cinnamon.
// Раскладка (xp, w7, w10, w11, mac) и картинки берутся из ~/.local/share/arthem/cinnamon-menu.json,
// который пишет Arthem при смене стиля. Файл отслеживается — меню перестраивается само.

const Applet = imports.ui.applet;
const PopupMenu = imports.ui.popupMenu;
const Main = imports.ui.main;
const Util = imports.misc.util;
const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Pango = imports.gi.Pango;

let AppFavorites = null;
try { AppFavorites = imports.ui.appFavorites; } catch (e) { AppFavorites = null; }
let Gtk = null;
try { Gtk = imports.gi.Gtk; } catch (e) { Gtk = null; }

const CONF_PATH = GLib.build_filenamev([GLib.get_user_data_dir(), "arthem", "cinnamon-menu.json"]);
const PREFS_PATH = GLib.build_filenamev([GLib.get_user_data_dir(), "arthem", "cinnamon-menu-user.json"]);
const SEARCH_MODES = [["hidden", "Скрыто"], ["icon", "Показать значок поиска"], ["box", "Показать поле поиска"]];
const SHARE = "/usr/share/arthem";

const DEFAULT_FAVS = [
    "firefox.desktop", "firefox_firefox.desktop", "org.mozilla.firefox.desktop", "chromium.desktop", "google-chrome.desktop",
    "nemo.desktop", "org.gnome.Nautilus.desktop", "thunderbird.desktop", "org.gnome.TextEditor.desktop", "xed.desktop",
    "org.gnome.Terminal.desktop", "gnome-terminal.desktop", "libreoffice-writer.desktop", "org.gnome.Calculator.desktop",
    "mintinstall.desktop", "org.gnome.Software.desktop", "cinnamon-settings.desktop"
];

function readJson(path) {
    try {
        let [ok, data] = GLib.file_get_contents(path);
        if (!ok) return null;
        let text;
        if (typeof data === "string") text = data;
        else {
            try { text = new TextDecoder("utf-8").decode(data); }
            catch (e) { text = imports.byteArray.toString(data); }
        }
        return JSON.parse(text);
    } catch (e) {
        return null;
    }
}

function writeJson(path, obj) {
    try {
        GLib.mkdir_with_parents(GLib.path_get_dirname(path), 0o755);
        GLib.file_set_contents(path, JSON.stringify(obj, null, 1));
    } catch (e) {
        global.logError("arthem-menu: запись настроек: " + e);
    }
}

function fileExists(path) {
    return path && GLib.file_test(path, GLib.FileTest.EXISTS);
}

function label(text, style) {
    let l = new St.Label({ text: text || "", style: style || "" });
    try { l.clutter_text.ellipsize = Pango.EllipsizeMode.END; } catch (e) {}
    l.y_align = Clutter.ActorAlign.CENTER;
    return l;
}

function hbox(style) { return new St.BoxLayout({ vertical: false, style: style || "" }); }
function vbox(style) { return new St.BoxLayout({ vertical: true, style: style || "" }); }

function spacer() {
    let s = new St.Bin();
    s.x_expand = true;
    s.y_expand = true;
    return s;
}

function userDir(kind) {
    try { return GLib.get_user_special_dir(kind); } catch (e) { return null; }
}

class ArthemMenuApplet extends Applet.TextIconApplet {
    constructor(metadata, orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this.metadata = metadata;
        this._orientation = orientation;
        this._panelH = panelHeight || 30;
        this._showAll = false;
        this._built = false;

        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new Applet.AppletPopupMenu(this, orientation);
        this.menuManager.addMenu(this.menu);
        this.menu.connect("open-state-changed", (m, open) => {
            if (open) {
                this._onOpen();
            } else if (this._searchMode) {
                this._searchMode = false;
                this._built = false;
                if (this._searchText) this._searchText.set_text("Введите здесь текст для поиска");
            }
        });

        this._loadConf();
        try {
            this._monitor = Gio.File.new_for_path(CONF_PATH).monitor_file(Gio.FileMonitorFlags.NONE, null);
            this._monitor.connect("changed", () => {
                this._loadConf();
                this._buildButton();
                this._built = false;
            });
        } catch (e) {
            global.logError("arthem-menu: монитор файла: " + e);
        }
        this._prefs = readJson(PREFS_PATH) || {};
        this._searchMode = false;
        this._buildExtras();
        this._buildContextItems();
        this._appSys = null;
        try {
            let AppSys = imports.gi.Cinnamon.AppSystem.get_default();
            this._appSysId = AppSys.connect("installed-changed", () => { this._apps = null; this._built = false; });
            this._appSys = AppSys;
        } catch (e) {}
        this._buildButton();
    }

    // ------------------------------------------------------------ конфигурация

    _loadConf() {
        let c = readJson(CONF_PATH) || {};
        this.layout = c.layout || "w7";
        this.startIcon = c.start || null;
        this.userPic = c.user_pic || null;
        this.accent = c.accent || "#3399FF";
        this.startFrames = c.start_frames || null;
    }

    on_panel_height_changed() {
        this._panelH = this._panelHeight || this._panelH;
        this._buildButton();
    }

    // ------------------------------------------------------------ кнопка на панели

    _buildButton() {
        let h = this._panelHeight || this._panelH || 30;
        this.actor.set_style("");
        this.set_applet_tooltip("Пуск");
        let L = this.layout;
        if (L === "xp") {
            let icon = SHARE + "/start/diamond-white.png";
            if (fileExists(icon)) this.set_applet_icon_path(icon);
            this.set_applet_label("пуск");
            this.hide_applet_label(false);
            try { this._applet_icon.set_icon_size(Math.max(14, Math.round(h * 0.5))); } catch (e) {}
            try {
                this._applet_label.set_style("font-style: italic; font-weight: bold; font-size: " +
                    Math.max(11, Math.round(h * 0.5)) + "px; color: #FFFFFF; text-shadow: 1px 1px 1px rgba(0,0,0,0.5); padding-left: 4px;");
            } catch (e) {}
            let shape = "border-radius: 0px " + Math.round(h / 2) + "px " + Math.round(h / 2) + "px 0px;" +
                "padding: 0px " + Math.round(h * 0.6) + "px 0px " + Math.round(h * 0.3) + "px; margin-right: 6px;" +
                "border: 1px solid rgba(255,255,255,0.25); box-shadow: inset 0px 1px 0px rgba(255,255,255,0.45);";
            let normal = "background-gradient-direction: vertical; background-gradient-start: #62C462; background-gradient-end: #2E7D2E;" + shape;
            let hover = "background-gradient-direction: vertical; background-gradient-start: #7AD87A; background-gradient-end: #3A943A;" + shape;
            let pressed = "background-gradient-direction: vertical; background-gradient-start: #2A7A2A; background-gradient-end: #3E9A3E;" + shape;
            let sf = this.startFrames;
            if (sf && sf.frames && sf.frames.length && fileExists(sf.frames[0])) {
                // кнопка из оригинального визуального стиля XP
                let m = sf.margins || [0, 0, 0, 0];
                let bi = (f) => "border-image: url(\"file://" + f + "\") " + m[2] + " " + m[1] + " " + m[3] + " " + m[0] + ";" +
                    "background-gradient-direction: none; background-color: transparent; box-shadow: none; border-radius: 0px;" +
                    "padding: 0px " + Math.round(h * 0.7) + "px 0px " + Math.round(h * 0.25) + "px; margin-right: 6px;";
                normal = bi(sf.frames[0]);
                hover = bi(sf.frames[Math.min(1, sf.frames.length - 1)]);
                pressed = bi(sf.frames[Math.min(2, sf.frames.length - 1)]);
                try { this._applet_icon.hide(); } catch (e) {}
                if (sf.text) {
                    try { this._applet_label.set_style(this._applet_label.get_style() + "color: " + sf.text + ";"); } catch (e) {}
                }
            } else {
                try { this._applet_icon.show(); } catch (e) {}
            }
            this._xpStyles = { normal: normal, hover: hover, pressed: pressed };
            this.actor.set_style(normal);
            this._hookXpStates();
            return;
        }
        this.set_applet_label("");
        this.hide_applet_label(true);
        try { this._applet_icon.show(); } catch (e) {}
        let path = this.startIcon;
        if (!fileExists(path)) {
            let fallback = { w7: "w7.png", w10: "diamond-white.png", w11: "diamond-blue.png", mac: "diamond-dark.png" }[L] || "w7.png";
            path = SHARE + "/start/" + fallback;
        }
        if (L === "w10") path = SHARE + "/start/diamond-white.png";
        if (L === "w11") path = SHARE + "/start/diamond-blue.png";
        if (L === "mac") path = SHARE + "/start/diamond-dark.png";
        if (fileExists(path)) this.set_applet_icon_path(path);
        let size = { w7: h - 2, w10: Math.round(h * 0.5), w11: Math.round(h * 0.5), mac: Math.round(h * 0.55) }[L] || h - 4;
        try { this._applet_icon.set_icon_size(Math.max(12, size)); } catch (e) {}
        if (L === "w10") {
            this.actor.set_style("padding: 0px 0px 0px " + Math.round(h * 0.35) + "px;");
        } else if (L === "w11") {
            this.actor.set_style("padding: 0px 8px; border-radius: 6px;");
        }
        this._updateExtras();
    }

    // ------------------------------------------------------------ поиск Windows 10 и заголовок macOS

    _buildExtras() {
        // Поле/значок поиска рядом с «Пуском»
        this._searchBtn = new St.Button({ reactive: true, can_focus: true, track_hover: true });
        let box = hbox("spacing: 8px;");
        this._searchIcon = new St.Icon({ icon_name: "system-search-symbolic", icon_type: St.IconType.SYMBOLIC, icon_size: 16 });
        this._searchIcon.y_align = Clutter.ActorAlign.CENTER;
        this._searchText = label("Введите здесь текст для поиска", "");
        box.add_child(this._searchIcon);
        box.add_child(this._searchText);
        this._searchBtn.set_child(box);
        this._searchBtn.connect("clicked", () => this._openSearch());
        this._searchBtn.connect("notify::hover", () => this._styleSearch());
        this.actor.add_child(this._searchBtn);
        this._searchBtn.hide();

        // Имя активной программы в строке меню macOS
        this._appTitle = label("", "font-weight: bold; padding-left: 10px; padding-right: 6px;");
        this.actor.add_child(this._appTitle);
        this._appTitle.hide();
        try {
            this._tracker = imports.gi.Cinnamon.WindowTracker.get_default();
            this._focusId = global.display.connect("notify::focus-window", () => this._updateTitle());
        } catch (e) {
            this._tracker = null;
        }
    }

    _searchModeValue() {
        let m = this._prefs.w10_search;
        return (m === "hidden" || m === "icon" || m === "box") ? m : "box";
    }

    _styleSearch() {
        if (!this._searchBtn) return;
        let h = this._panelHeight || this._panelH || 30;
        let mode = this._searchModeValue();
        let hover = this._searchBtn.hover;
        if (mode === "box") {
            this._searchBtn.set_style("background-color: " + (hover ? "#FFFFFF" : "#F3F3F3") + "; border: 1px solid #FFFFFF;" +
                "padding: 0px " + Math.round(h * 1.6) + "px 0px 10px; margin: " + Math.round(h * 0.12) + "px 0px " + Math.round(h * 0.12) + "px " + Math.round(h * 0.35) + "px;");
            this._searchIcon.set_style("color: #1A1A1A;");
            this._searchText.set_style("color: #5A5A5A; font-weight: normal; font-size: " + Math.max(10, Math.round(h * 0.32)) + "px;");
            this._searchText.show();
        } else {
            this._searchBtn.set_style("padding: 0px " + Math.round(h * 0.35) + "px;" + (hover ? "background-color: rgba(255,255,255,0.10);" : ""));
            this._searchIcon.set_style("color: #FFFFFF;");
            this._searchText.hide();
        }
    }

    _updateExtras() {
        if (!this._searchBtn) return;
        let mode = this._searchModeValue();
        if (this.layout === "w10" && mode !== "hidden") {
            this._searchBtn.show();
            this._styleSearch();
        } else {
            this._searchBtn.hide();
        }
        if (this._searchMenu) {
            this._searchMenu.actor.visible = this.layout === "w10";
            this._markSearchItems();
        }
        this._updateTitle();
    }

    _updateTitle() {
        if (!this._appTitle) return;
        if (this.layout !== "mac") {
            this._appTitle.hide();
            return;
        }
        let name = "Рабочий стол";
        try {
            let w = global.display.focus_window;
            if (w) {
                let app = this._tracker ? this._tracker.get_window_app(w) : null;
                name = app ? app.get_name() : (w.get_wm_class() || w.get_title() || name);
            }
        } catch (e) {}
        this._appTitle.set_text(name);
        this._appTitle.set_style("font-weight: bold; color: #1D1D1F; padding-left: 12px; padding-right: 6px;");
        this._appTitle.show();
    }

    _buildContextItems() {
        try {
            this._searchMenu = new PopupMenu.PopupSubMenuMenuItem("Поиск");
            this._searchItems = {};
            for (let [key, title] of SEARCH_MODES) {
                let it = new PopupMenu.PopupMenuItem(title);
                it.connect("activate", () => this._setSearchMode(key));
                this._searchMenu.menu.addMenuItem(it);
                this._searchItems[key] = [it, title];
            }
            this._applet_context_menu.addMenuItem(this._searchMenu, 0);
            this._applet_context_menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(), 1);
            this._searchMenu.actor.visible = this.layout === "w10";
            this._markSearchItems();
        } catch (e) {
            global.logError("arthem-menu: контекстное меню: " + e);
        }
    }

    _markSearchItems() {
        if (!this._searchItems) return;
        let cur = this._searchModeValue();
        for (let key in this._searchItems) {
            let [it, title] = this._searchItems[key];
            let on = key === cur;
            let done = false;
            try {
                if (it.setOrnament && PopupMenu.OrnamentType) {
                    it.setOrnament(on ? PopupMenu.OrnamentType.DOT : PopupMenu.OrnamentType.NONE, on);
                    done = true;
                }
            } catch (e) {}
            if (!done) {
                try { it.setShowDot(on); done = true; } catch (e) {}
            }
            if (!done) {
                try { it.label.set_text((on ? "● " : "    ") + title); } catch (e) {}
            }
        }
    }

    _setSearchMode(mode) {
        this._prefs.w10_search = mode;
        writeJson(PREFS_PATH, this._prefs);
        this._updateExtras();
    }

    _openSearch() {
        this._searchMode = true;
        this._built = false;
        if (this.menu.isOpen) this._rebuild(); else this.menu.open(true);
    }

    _hookXpStates() {
        if (this._xpHooked) return;
        this._xpHooked = true;
        this.actor.track_hover = true;
        this.actor.connect("notify::hover", () => {
            if (this.layout !== "xp" || !this._xpStyles) return;
            this.actor.set_style(this.menu.isOpen ? this._xpStyles.pressed : (this.actor.hover ? this._xpStyles.hover : this._xpStyles.normal));
        });
        this.menu.connect("open-state-changed", (m, open) => {
            if (this.layout !== "xp" || !this._xpStyles) return;
            this.actor.set_style(open ? this._xpStyles.pressed : this._xpStyles.normal);
        });
    }

    on_applet_clicked() {
        if (this._searchMode && this.menu.isOpen) {
            this._searchMode = false;
            this._built = false;
            this._rebuild();
            return;
        }
        this.menu.toggle();
    }

    // ------------------------------------------------------------ данные

    _allApps() {
        if (!this._apps) {
            let list = [];
            try {
                list = Gio.AppInfo.get_all().filter(a => { try { return a.should_show(); } catch (e) { return false; } });
            } catch (e) {}
            list.sort((a, b) => a.get_name().localeCompare(b.get_name()));
            this._apps = list;
        }
        return this._apps;
    }

    _favorites(max) {
        let out = [];
        try {
            if (AppFavorites) {
                let favs = AppFavorites.getAppFavorites().getFavorites();
                for (let f of favs) {
                    let info = f.get_app_info ? f.get_app_info() : null;
                    if (info) out.push(info);
                }
            }
        } catch (e) {}
        if (out.length < max) {
            for (let id of DEFAULT_FAVS) {
                if (out.length >= max) break;
                try {
                    let a = Gio.DesktopAppInfo.new(id);
                    if (a && !out.some(o => o.get_id && o.get_id() === a.get_id())) out.push(a);
                } catch (e) {}
            }
        }
        if (out.length < max) {
            for (let a of this._allApps()) {
                if (out.length >= max) break;
                let id = "", cats = "";
                try { id = a.get_id() || ""; } catch (e) {}
                try { cats = a.get_categories ? (a.get_categories() || "") : ""; } catch (e) {}
                if (id.startsWith("cinnamon-settings") || cats.indexOf("Settings") >= 0 || cats.indexOf("System") >= 0) continue;
                if (!out.some(o => o.get_id && o.get_id() === id)) out.push(a);
            }
        }
        return out.slice(0, max);
    }

    _recent(max) {
        let out = [];
        if (!Gtk) return out;
        try {
            let items = Gtk.RecentManager.get_default().get_items();
            items.sort((a, b) => b.get_modified() - a.get_modified());
            for (let it of items) {
                if (out.length >= max) break;
                if (it.exists && !it.exists()) continue;
                out.push({ name: it.get_display_name(), uri: it.get_uri(), gicon: it.get_gicon ? it.get_gicon() : null });
            }
        } catch (e) {}
        return out;
    }

    _search(text) {
        let t = text.toLowerCase().trim();
        if (!t) return [];
        let res = [];
        for (let a of this._allApps()) {
            let n = a.get_name().toLowerCase();
            let d = "";
            try { d = (a.get_description() || "").toLowerCase(); } catch (e) {}
            let kw = "";
            try { kw = (a.get_keywords ? a.get_keywords().join(" ") : "").toLowerCase(); } catch (e) {}
            let score = n.startsWith(t) ? 0 : (n.indexOf(t) >= 0 ? 1 : ((kw.indexOf(t) >= 0 || d.indexOf(t) >= 0) ? 2 : -1));
            if (score >= 0) res.push([score, a]);
        }
        res.sort((x, y) => x[0] - y[0] || x[1].get_name().localeCompare(y[1].get_name()));
        return res.slice(0, 30).map(x => x[1]);
    }

    _userName() {
        let n = GLib.get_real_name();
        if (!n || n === "Unknown") n = GLib.get_user_name();
        return n;
    }

    _avatar(size, style) {
        let candidates = [this.userPic, GLib.build_filenamev([GLib.get_home_dir(), ".face"]),
            "/var/lib/AccountsService/icons/" + GLib.get_user_name()];
        for (let p of candidates) {
            if (fileExists(p)) {
                return new St.Icon({ gicon: Gio.FileIcon.new(Gio.File.new_for_path(p)), icon_size: size, style: style || "" });
            }
        }
        return new St.Icon({ icon_name: "avatar-default", icon_type: St.IconType.FULLCOLOR, icon_size: size, style: style || "" });
    }

    // ------------------------------------------------------------ действия

    _launch(app) {
        this.menu.close();
        try {
            let ctx = global.create_app_launch_context ? global.create_app_launch_context() : null;
            app.launch([], ctx);
        } catch (e) {
            try { app.launch([], null); } catch (e2) { global.logError("arthem-menu: запуск: " + e2); }
        }
    }

    _openUri(uri) {
        this.menu.close();
        try { Gio.AppInfo.launch_default_for_uri(uri, null); } catch (e) { Util.spawn(["xdg-open", uri]); }
    }

    _openPath(path) {
        if (!path) return;
        this._openUri(Gio.File.new_for_path(path).get_uri());
    }

    _cmd(cmd) {
        this.menu.close();
        Util.spawnCommandLine(cmd);
    }

    _power(kind) {
        let cmds = {
            off: "cinnamon-session-quit --power-off",
            reboot: "cinnamon-session-quit --reboot",
            logout: "cinnamon-session-quit --logout",
            lock: "cinnamon-screensaver-command --lock",
            sleep: "systemctl suspend",
        };
        this._cmd(cmds[kind]);
    }

    _run() {
        this.menu.close();
        try { Main.getRunDialog().open(); } catch (e) { Util.spawnCommandLine("cinnamon-settings"); }
    }

    _places() {
        const D = GLib.UserDirectory;
        return {
            home: GLib.get_home_dir(),
            documents: userDir(D.DIRECTORY_DOCUMENTS),
            pictures: userDir(D.DIRECTORY_PICTURES),
            music: userDir(D.DIRECTORY_MUSIC),
            videos: userDir(D.DIRECTORY_VIDEOS),
            downloads: userDir(D.DIRECTORY_DOWNLOAD),
        };
    }

    // ------------------------------------------------------------ элементы

    _item(iconObj, text, onClick, opts) {
        opts = opts || {};
        let btn = new St.Button({ reactive: true, can_focus: true, track_hover: true, style: opts.style || "" });
        btn.x_align = Clutter.ActorAlign.FILL;
        let row = hbox("spacing: " + (opts.spacing || 8) + "px;");
        if (iconObj) row.add_child(iconObj);
        let l = label(text, opts.labelStyle);
        row.add_child(l);
        row.x_expand = true;
        btn.set_child(row);
        btn.x_expand = true;
        try { btn.x_fill = true; } catch (e) {}
        try { btn.set_x_align(St.Align.START); } catch (e) {}
        let hover = opts.hover || "background-color: rgba(51,153,255,0.25);";
        let base = opts.style || "";
        btn.connect("notify::hover", () => { btn.set_style(base + (btn.hover ? hover : "")); });
        btn.connect("clicked", () => onClick());
        return btn;
    }

    _appIcon(app, size) {
        let g = null;
        try { g = app.get_icon(); } catch (e) {}
        if (!g) g = Gio.ThemedIcon.new("application-x-executable");
        return new St.Icon({ gicon: g, icon_size: size, icon_type: St.IconType.FULLCOLOR });
    }

    _named(name, size, style) {
        return new St.Icon({ icon_name: name, icon_size: size, icon_type: St.IconType.FULLCOLOR, style: style || "" });
    }

    _scroll(child, maxH) {
        let sv = new St.ScrollView({ style: "max-height: " + maxH + "px;" });
        try { sv.set_policy(St.PolicyType.NEVER, St.PolicyType.AUTOMATIC); } catch (e) {}
        try { sv.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC); } catch (e) {}
        sv.add_actor(child);
        sv.x_expand = true;
        sv.y_expand = true;
        return sv;
    }

    _entry(hint, style, onChange) {
        let e = new St.Entry({ hint_text: hint, can_focus: true, track_hover: true, style: style });
        e.clutter_text.connect("text-changed", () => onChange(e.get_text()));
        e.clutter_text.connect("activate", () => {
            let r = this._search(e.get_text());
            if (r.length) this._launch(r[0]);
        });
        this._searchEntry = e;
        return e;
    }

    _appList(apps, box, iconSize, textStyle, hover) {
        box.destroy_all_children();
        for (let a of apps) {
            box.add_child(this._item(this._appIcon(a, iconSize), a.get_name(), () => this._launch(a),
                { labelStyle: textStyle, style: "padding: 4px 8px; border-radius: 3px;", hover: hover }));
        }
        if (!apps.length) box.add_child(label("Ничего не найдено", textStyle + "padding: 8px; font-style: italic;"));
    }

    // ------------------------------------------------------------ сборка меню

    _onOpen() {
        if (!this._built) {
            this._rebuild();
        }
        if (this._searchEntry) {
            this._searchEntry.set_text("");
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 60, () => {
                try { global.stage.set_key_focus(this._searchEntry); } catch (e) {}
                return false;
            });
        }
    }

    _rebuild() {
        this._showAll = false;
        this._searchEntry = null;
        this.menu.removeAll();
        // removeAll() убирает только пункты меню — свой корневой блок удаляем сами
        if (this._root) {
            try { this._root.destroy(); } catch (e) {}
            this._root = null;
        }
        try { this.menu.box.destroy_all_children(); } catch (e) {}
        try { this.menu.box.set_style("padding: 0px;"); } catch (e) {}
        try {
            this.menu.actor.set_style("padding: 0px; border: none; border-image: none; background-color: transparent; box-shadow: none; background-gradient-direction: none;" +
                "-arrow-background-color: transparent; -arrow-border-color: transparent; -arrow-border-width: 0px; -arrow-base: 0px; -arrow-rise: 0px;");
        } catch (e) {}
        let builders = { xp: this._buildXP, w7: this._build7, w10: this._build10, w11: this._build11, mac: this._buildMac };
        let root;
        try {
            let fn = (this.layout === "w10" && this._searchMode) ? this._build10Search : (builders[this.layout] || this._build7);
            root = fn.call(this);
        } catch (e) {
            global.logError("arthem-menu: сборка " + this.layout + ": " + e + "\n" + e.stack);
            root = vbox("padding: 12px; background-color: #FFFFFF;");
            root.add_child(label("Ошибка меню: " + e, "color: #A00;"));
        }
        this.menu.addActor(root);
        this._root = root;
        this._built = true;
    }

    // ---------- Windows XP

    _buildXP() {
        const blue = "background-gradient-direction: vertical; background-gradient-start: #3C8CF6; background-gradient-end: #0B55D6;";
        let root = vbox("width: 410px; background-color: #FFFFFF; border: 1px solid #0B55D6; border-radius: 8px 8px 0px 0px;");
        let head = hbox(blue + "padding: 8px 10px; spacing: 10px; border-radius: 7px 7px 0px 0px;");
        head.add_child(this._avatar(42, "border: 2px solid #FFFFFF; border-radius: 4px;"));
        head.add_child(label(this._userName(), "color: #FFFFFF; font-weight: bold; font-size: 15px; text-shadow: 1px 1px 2px rgba(0,0,0,0.6);"));
        root.add_child(head);
        root.add_child(new St.Bin({ style: "height: 2px; background-gradient-direction: horizontal; background-gradient-start: #FFFFFF; background-gradient-end: #F29C38;" }));

        let body = hbox("min-height: 340px;");
        let left = vbox("width: 210px; padding: 6px; spacing: 2px; background-color: #FFFFFF;");
        let listBox = vbox("spacing: 1px;");
        const txt = "color: #000000; font-size: 13px;";
        const hov = "background-color: #316AC5; color: #FFFFFF;";
        this._appList(this._favorites(8), listBox, 32, txt + "font-weight: bold;", hov);
        let scroll = this._scroll(listBox, 300);
        left.add_child(scroll);
        left.add_child(spacer());
        left.add_child(new St.Bin({ style: "height: 1px; background-color: #D4D0C8; margin: 4px 0px;" }));
        let allBtn = this._item(null, "Все программы  ▸", () => {
            this._showAll = !this._showAll;
            this._appList(this._showAll ? this._allApps() : this._favorites(8), listBox, this._showAll ? 16 : 32,
                txt + (this._showAll ? "" : "font-weight: bold;"), hov);
            allBtn.get_child().get_children()[0].set_text(this._showAll ? "◂  Назад" : "Все программы  ▸");
        }, { labelStyle: "color: #000; font-weight: bold; font-size: 13px;", style: "padding: 6px 10px;", hover: "background-color: #316AC5;" });
        left.add_child(allBtn);
        body.add_child(left);

        let right = vbox("width: 196px; padding: 6px; spacing: 2px; background-color: #D3E5FA; border-left: 1px solid #95BDEE;");
        const rtxt = "color: #0A246A; font-weight: bold; font-size: 12px;";
        const rh = "background-color: #316AC5;";
        let P = this._places();
        let links = [
            ["folder-documents", "Мои документы", () => this._openPath(P.documents)],
            ["folder-pictures", "Мои рисунки", () => this._openPath(P.pictures)],
            ["folder-music", "Моя музыка", () => this._openPath(P.music)],
            ["computer", "Мой компьютер", () => this._openUri("computer:///")],
            null,
            ["preferences-system", "Панель управления", () => this._cmd("cinnamon-settings")],
            ["system-search", "Найти", () => this._cmd("nemo --search")],
            ["system-run", "Выполнить…", () => this._run()],
        ];
        for (let l of links) {
            if (!l) { right.add_child(new St.Bin({ style: "height: 1px; background-color: #A9C6EC; margin: 4px 0px;" })); continue; }
            right.add_child(this._item(this._named(l[0], 22), l[1], l[2], { labelStyle: rtxt, style: "padding: 4px 6px;", hover: rh }));
        }
        let srch = this._entry("Поиск программ…", "margin-top: 8px; padding: 4px 6px; background-color: #FFFFFF; border: 1px solid #7F9DB9; color: #000;",
            (t) => {
                if (!t) { this._appList(this._showAll ? this._allApps() : this._favorites(8), listBox, this._showAll ? 16 : 32, txt, hov); return; }
                this._appList(this._search(t), listBox, 16, txt, hov);
            });
        right.add_child(spacer());
        right.add_child(srch);
        body.add_child(right);
        root.add_child(body);

        let foot = hbox(blue + "padding: 6px 10px; spacing: 14px;");
        foot.add_child(spacer());
        const fs = "color: #FFFFFF; font-size: 12px;";
        foot.add_child(this._item(this._named("system-log-out", 22), "Выход из системы", () => this._power("logout"),
            { labelStyle: fs, style: "padding: 3px 6px; border-radius: 3px;", hover: "background-color: rgba(255,255,255,0.2);" }));
        foot.add_child(this._item(this._named("system-shutdown", 22), "Выключение", () => this._power("off"),
            { labelStyle: fs, style: "padding: 3px 6px; border-radius: 3px;", hover: "background-color: rgba(255,255,255,0.2);" }));
        root.add_child(foot);
        return root;
    }

    // ---------- Windows 7

    _build7() {
        let root = hbox("width: 430px; padding: 8px; spacing: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.45);" +
            "background-gradient-direction: vertical; background-gradient-start: rgba(70,110,150,0.95); background-gradient-end: rgba(20,42,68,0.97);");
        let left = vbox("width: 250px; padding: 6px; spacing: 2px; background-color: #FFFFFF; border-radius: 4px; border: 1px solid #9DB5CF;");
        let listBox = vbox("spacing: 1px;");
        const txt = "color: #1A1A1A; font-size: 13px;";
        const hov = "background-color: #DCEBFC; border: 1px solid #7DA2CE; border-radius: 3px;";
        this._appList(this._favorites(9), listBox, 32, txt, hov);
        left.add_child(this._scroll(listBox, 330));
        left.add_child(spacer());
        left.add_child(new St.Bin({ style: "height: 1px; background-color: #D6E3F2; margin: 4px 0px;" }));
        let allBtn = this._item(null, "▸  Все программы", () => {
            this._showAll = !this._showAll;
            this._appList(this._showAll ? this._allApps() : this._favorites(9), listBox, this._showAll ? 16 : 32, txt, hov);
            allBtn.get_child().get_children()[0].set_text(this._showAll ? "◂  Назад" : "▸  Все программы");
        }, { labelStyle: "color: #1A1A1A; font-size: 13px;", style: "padding: 5px 8px;", hover: hov });
        left.add_child(allBtn);
        left.add_child(this._entry("Найти программы и файлы",
            "margin-top: 4px; padding: 5px 8px; background-color: #FFFFFF; border: 1px solid #9DB5CF; border-radius: 3px; color: #1A1A1A; font-style: italic;",
            (t) => {
                if (!t) { this._appList(this._showAll ? this._allApps() : this._favorites(9), listBox, this._showAll ? 16 : 32, txt, hov); return; }
                this._appList(this._search(t), listBox, 16, txt, hov);
            }));
        root.add_child(left);

        let right = vbox("width: 160px; spacing: 1px; padding-top: 2px;");
        let picBox = new St.Bin({ style: "padding: 2px; border: 1px solid rgba(255,255,255,0.6); border-radius: 4px; background-color: rgba(255,255,255,0.15);" });
        picBox.set_child(this._avatar(52));
        let picRow = hbox("padding-bottom: 6px;");
        picRow.add_child(spacer());
        picRow.add_child(picBox);
        picRow.add_child(spacer());
        right.add_child(picRow);
        const rt = "color: #FFFFFF; font-size: 13px; text-shadow: 0px 1px 2px rgba(0,0,0,0.6);";
        const rh = "background-color: rgba(255,255,255,0.18); border: 1px solid rgba(255,255,255,0.4); border-radius: 3px;";
        let P = this._places();
        let links = [
            [this._userName(), () => this._openPath(P.home)],
            ["Документы", () => this._openPath(P.documents)],
            ["Изображения", () => this._openPath(P.pictures)],
            ["Музыка", () => this._openPath(P.music)],
            ["Загрузки", () => this._openPath(P.downloads)],
            null,
            ["Компьютер", () => this._openUri("computer:///")],
            ["Сеть", () => this._openUri("network:///")],
            null,
            ["Панель управления", () => this._cmd("cinnamon-settings")],
            ["Устройства и принтеры", () => this._cmd("cinnamon-settings printers")],
        ];
        for (let l of links) {
            if (!l) { right.add_child(new St.Bin({ style: "height: 1px; background-color: rgba(255,255,255,0.18); margin: 3px 4px;" })); continue; }
            right.add_child(this._item(null, l[0], l[1], { labelStyle: rt, style: "padding: 5px 8px;", hover: rh }));
        }
        right.add_child(spacer());
        let pw = hbox("spacing: 0px;");
        pw.add_child(this._item(null, "Завершение работы", () => this._power("off"),
            { labelStyle: "color: #FFFFFF; font-size: 12px;",
              style: "padding: 5px 10px; border: 1px solid rgba(255,255,255,0.5); border-radius: 3px 0px 0px 3px;" +
                     "background-gradient-direction: vertical; background-gradient-start: rgba(255,255,255,0.25); background-gradient-end: rgba(255,255,255,0.05);",
              hover: "background-color: rgba(220,90,60,0.6);" }));
        pw.add_child(this._item(null, "▸", () => this._power("logout"),
            { labelStyle: "color: #FFFFFF; font-size: 12px;",
              style: "padding: 5px 7px; border: 1px solid rgba(255,255,255,0.5); border-radius: 0px 3px 3px 0px;",
              hover: "background-color: rgba(255,255,255,0.25);" }));
        right.add_child(pw);
        root.add_child(right);
        return root;
    }

    // ---------- Windows 10

    _build10() {
        let root = hbox("width: 640px; background-color: rgba(31,31,31,0.98); border: 1px solid #3A3A3A;");
        const white = "color: #FFFFFF; font-size: 13px;";
        const hov = "background-color: rgba(255,255,255,0.12);";
        // полоска слева
        let strip = vbox("width: 48px; padding: 6px 0px; spacing: 2px; background-color: rgba(20,20,20,0.98);");
        let mk = (icon, tip, fn) => {
            let b = this._item(this._named(icon, 20, "color: #FFFFFF;"), "", fn, { style: "padding: 10px 14px;", hover: hov });
            b.set_style("padding: 10px 14px;");
            return b;
        };
        strip.add_child(mk("open-menu-symbolic", "Меню", () => {}));
        strip.add_child(spacer());
        let P = this._places();
        strip.add_child(mk("avatar-default-symbolic", "Пользователь", () => this._openPath(P.home)));
        strip.add_child(mk("folder-documents-symbolic", "Документы", () => this._openPath(P.documents)));
        strip.add_child(mk("folder-pictures-symbolic", "Изображения", () => this._openPath(P.pictures)));
        strip.add_child(mk("emblem-system-symbolic", "Параметры", () => this._cmd("cinnamon-settings")));
        strip.add_child(mk("system-shutdown-symbolic", "Выключение", () => this._power("off")));
        root.add_child(strip);

        // список приложений
        let mid = vbox("width: 270px; padding: 8px 4px 8px 8px; spacing: 4px;");
        let listBox = vbox("spacing: 1px;");
        mid.add_child(this._entry("Введите здесь текст для поиска",
            "padding: 7px 10px; background-color: #FFFFFF; color: #1A1A1A; border: 2px solid #0078D7;",
            (t) => this._appList(t ? this._search(t) : this._allApps(), listBox, 24, white, hov)));
        this._appList(this._allApps(), listBox, 24, white, hov);
        mid.add_child(this._scroll(listBox, 470));
        root.add_child(mid);

        // плитки
        let tiles = vbox("padding: 10px; spacing: 6px;");
        tiles.add_child(label("Закреплённые", "color: #FFFFFF; font-size: 12px; padding: 0px 0px 4px 2px;"));
        const colors = ["#0078D7", "#00B294", "#E81123", "#FF8C00", "#5C2D91", "#0063B1", "#107C10", "#B4009E", "#2D7D9A"];
        let favs = this._favorites(9);
        let row = null;
        favs.forEach((a, i) => {
            if (i % 3 === 0) { row = hbox("spacing: 6px;"); tiles.add_child(row); }
            let tile = new St.Button({ reactive: true, track_hover: true, can_focus: true,
                style: "width: 92px; height: 92px; background-color: " + colors[i % colors.length] + ";" });
            let tv = vbox("padding: 8px;");
            tv.add_child(spacer());
            let ic = this._appIcon(a, 32);
            let icRow = hbox("");
            icRow.add_child(spacer()); icRow.add_child(ic); icRow.add_child(spacer());
            tv.add_child(icRow);
            tv.add_child(spacer());
            tv.add_child(label(a.get_name(), "color: #FFFFFF; font-size: 11px;"));
            tile.set_child(tv);
            let base = tile.get_style();
            tile.connect("notify::hover", () => tile.set_style(base + (tile.hover ? "border: 2px solid rgba(255,255,255,0.6);" : "")));
            tile.connect("clicked", () => this._launch(a));
            row.add_child(tile);
        });
        root.add_child(tiles);
        return root;
    }

    // ---------- Windows 10: панель поиска

    _build10Search() {
        let root = vbox("width: 640px; background-color: rgba(31,31,31,0.98); border: 1px solid #3A3A3A;");
        const white = "color: #FFFFFF; font-size: 13px;";
        const muted = "color: #BBBBBB; font-size: 12px;";
        const hov = "background-color: rgba(255,255,255,0.12);";
        let body = hbox("min-height: 430px;");
        let left = vbox("width: 330px; padding: 12px 6px 12px 12px; spacing: 6px;");
        let right = vbox("width: 300px; padding: 22px; spacing: 12px; background-color: rgba(43,43,43,0.98);");
        body.add_child(left);
        body.add_child(right);
        root.add_child(body);

        let showDetail = (app) => {
            right.destroy_all_children();
            if (!app) {
                right.add_child(label("Поиск в приложениях и файлах", "color: #FFFFFF; font-size: 15px; font-weight: bold;"));
                right.add_child(label("Начните вводить название программы.", muted));
                return;
            }
            let icRow = hbox("");
            icRow.add_child(spacer());
            icRow.add_child(this._appIcon(app, 64));
            icRow.add_child(spacer());
            right.add_child(icRow);
            let nm = label(app.get_name(), "color: #FFFFFF; font-size: 16px; font-weight: bold;");
            nm.x_align = Clutter.ActorAlign.CENTER;
            right.add_child(nm);
            let kind = label("Приложение", muted);
            kind.x_align = Clutter.ActorAlign.CENTER;
            right.add_child(kind);
            right.add_child(new St.Bin({ style: "height: 1px; background-color: #444444; margin: 6px 0px;" }));
            right.add_child(this._item(this._named("media-playback-start-symbolic", 16, "color: #FFFFFF;"), "Открыть", () => this._launch(app),
                { labelStyle: white, style: "padding: 6px 8px;", hover: hov }));
        };

        let render = (text) => {
            left.destroy_all_children();
            if (this._searchText) this._searchText.set_text(text || "Введите здесь текст для поиска");
            if (!text) {
                left.add_child(label("Популярные приложения", "color: #FFFFFF; font-weight: bold; font-size: 13px; padding: 2px 4px 6px 4px;"));
                let list = vbox("spacing: 1px;");
                this._appList(this._favorites(8), list, 24, white, hov);
                left.add_child(list);
                let rec = this._recent(4);
                if (rec.length) {
                    left.add_child(label("Недавние", "color: #FFFFFF; font-weight: bold; font-size: 13px; padding: 10px 4px 6px 4px;"));
                    for (let r of rec) {
                        let ic = r.gicon ? new St.Icon({ gicon: r.gicon, icon_size: 20 }) : this._named("text-x-generic", 20);
                        left.add_child(this._item(ic, r.name, () => this._openUri(r.uri), { labelStyle: white, style: "padding: 4px 8px;", hover: hov }));
                    }
                }
                showDetail(null);
                return;
            }
            let res = this._search(text);
            if (!res.length) {
                left.add_child(label("Ничего не найдено по запросу «" + text + "»", white + "padding: 8px;"));
                showDetail(null);
                return;
            }
            left.add_child(label("Лучшее соответствие", "color: #FFFFFF; font-weight: bold; font-size: 13px; padding: 2px 4px 6px 4px;"));
            let best = res[0];
            let bestBtn = this._item(this._appIcon(best, 32), best.get_name() + "\nПриложение", () => this._launch(best),
                { labelStyle: white, style: "padding: 8px; background-color: rgba(0,120,215,0.45);", hover: "background-color: rgba(0,120,215,0.65);" });
            left.add_child(bestBtn);
            if (res.length > 1) {
                left.add_child(label("Приложения", "color: #FFFFFF; font-weight: bold; font-size: 13px; padding: 10px 4px 6px 4px;"));
                let list = vbox("spacing: 1px;");
                this._appList(res.slice(1, 12), list, 20, white, hov);
                left.add_child(this._scroll(list, 260));
            }
            showDetail(best);
        };

        let bar = hbox("padding: 8px; background-color: #FFFFFF; border-top: 2px solid #0078D7; spacing: 8px;");
        bar.add_child(this._named("system-search-symbolic", 18, "color: #1A1A1A;"));
        let entry = this._entry("Введите здесь текст для поиска", "background-color: #FFFFFF; color: #1A1A1A; border: none; padding: 4px;", render);
        entry.x_expand = true;
        bar.add_child(entry);
        root.add_child(bar);
        render("");
        return root;
    }

    // ---------- Windows 11

    _build11() {
        let root = vbox("width: 620px; background-color: rgba(243,245,249,0.98); border: 1px solid #D6DDE8; border-radius: 10px;");
        let top = vbox("padding: 22px 28px 10px 28px; spacing: 10px;");
        let grid = vbox("spacing: 6px;");
        let showGrid = (apps) => {
            grid.destroy_all_children();
            let row = null;
            apps.forEach((a, i) => {
                if (i % 6 === 0) { row = hbox("spacing: 4px;"); grid.add_child(row); }
                let b = new St.Button({ reactive: true, track_hover: true, can_focus: true, style: "width: 90px; padding: 8px 2px; border-radius: 6px;" });
                let v = vbox("spacing: 6px;");
                let icRow = hbox("");
                icRow.add_child(spacer()); icRow.add_child(this._appIcon(a, 32)); icRow.add_child(spacer());
                v.add_child(icRow);
                let l = label(a.get_name(), "color: #1A1A1A; font-size: 11px; text-align: center;");
                l.x_align = Clutter.ActorAlign.CENTER;
                v.add_child(l);
                b.set_child(v);
                let base = b.get_style();
                b.connect("notify::hover", () => b.set_style(base + (b.hover ? "background-color: rgba(255,255,255,0.9);" : "")));
                b.connect("clicked", () => this._launch(a));
                row.add_child(b);
            });
        };
        top.add_child(this._entry("Поиск приложений, параметров и документов",
            "padding: 8px 16px; border-radius: 16px; background-color: #FFFFFF; border: 1px solid #D6DDE8; color: #1A1A1A;",
            (t) => {
                if (t) { showGrid(this._search(t).slice(0, 18)); pinHead.set_text("Результаты"); }
                else { showGrid(this._favorites(18)); pinHead.set_text("Закреплённые"); }
            }));
        let headRow = hbox("padding-top: 6px;");
        let pinHead = label("Закреплённые", "color: #1A1A1A; font-weight: bold; font-size: 14px;");
        headRow.add_child(pinHead);
        headRow.add_child(spacer());
        let allBtn = this._item(null, "Все приложения  ›", () => {
            this._showAll = !this._showAll;
            if (this._showAll) {
                pinHead.set_text("Все приложения");
                grid.destroy_all_children();
                let list = vbox("spacing: 1px;");
                this._appList(this._allApps(), list, 24, "color: #1A1A1A; font-size: 13px;", "background-color: rgba(255,255,255,0.9); border-radius: 4px;");
                grid.add_child(this._scroll(list, 330));
            } else {
                pinHead.set_text("Закреплённые");
                showGrid(this._favorites(18));
            }
            allBtn.get_child().get_children()[0].set_text(this._showAll ? "‹  Назад" : "Все приложения  ›");
        }, { labelStyle: "color: #1A1A1A; font-size: 12px;", style: "padding: 3px 10px; border-radius: 4px; background-color: #FFFFFF; border: 1px solid #D6DDE8;",
             hover: "background-color: #F5F7FA;" });
        headRow.add_child(allBtn);
        top.add_child(headRow);
        showGrid(this._favorites(18));
        top.add_child(grid);

        top.add_child(label("Рекомендуем", "color: #1A1A1A; font-weight: bold; font-size: 14px; padding-top: 10px;"));
        let rec = this._recent(6);
        let rg = vbox("spacing: 4px;");
        let rrow = null;
        if (!rec.length) {
            rg.add_child(label("Здесь появятся недавние файлы", "color: #555; font-size: 12px; padding: 6px;"));
        }
        rec.forEach((r, i) => {
            if (i % 2 === 0) { rrow = hbox("spacing: 8px;"); rg.add_child(rrow); }
            let ic = r.gicon ? new St.Icon({ gicon: r.gicon, icon_size: 28 }) : this._named("text-x-generic", 28);
            let b = this._item(ic, r.name, () => this._openUri(r.uri),
                { labelStyle: "color: #1A1A1A; font-size: 12px;", style: "width: 270px; padding: 6px 8px; border-radius: 6px;",
                  hover: "background-color: rgba(255,255,255,0.9);" });
            rrow.add_child(b);
        });
        top.add_child(rg);
        root.add_child(top);

        let foot = hbox("width: 562px; padding: 12px 28px; spacing: 10px; background-color: rgba(233,237,243,0.98); border-top: 1px solid #D6DDE8; border-radius: 0px 0px 10px 10px;");
        let P = this._places();
        foot.add_child(this._item(this._avatar(28, "border-radius: 14px;"), this._userName(), () => this._openPath(P.home),
            { labelStyle: "color: #1A1A1A; font-size: 13px;", style: "padding: 4px 8px; border-radius: 6px;", hover: "background-color: rgba(255,255,255,0.9);" }));
        foot.add_child(spacer());
        foot.add_child(this._item(this._named("system-shutdown-symbolic", 18, "color: #1A1A1A;"), "", () => this._power("off"),
            { style: "padding: 8px; border-radius: 6px;", hover: "background-color: rgba(255,255,255,0.9);" }));
        root.add_child(foot);
        return root;
    }

    // ---------- macOS

    _buildMac() {
        let root = vbox("width: 250px; padding: 5px; spacing: 0px; background-color: rgba(242,242,242,0.98); border: 1px solid #C8C8C8; border-radius: 8px;");
        const t = "color: #1D1D1F; font-size: 13px;";
        const hv = "background-color: #007AFF; color: #FFFFFF;";
        let items = [
            ["Об этом компьютере", () => this._cmd("cinnamon-settings info")],
            null,
            ["Системные настройки…", () => this._cmd("cinnamon-settings")],
            ["Центр приложений…", () => this._cmd("sh -c 'mintinstall || gnome-software || plasma-discover'")],
            null,
            ["Все приложения…", () => { listBox.show(); this._appList(this._allApps(), inner, 16, t, hv); }],
            null,
            ["Сон", () => this._power("sleep")],
            ["Перезагрузить…", () => this._power("reboot")],
            ["Выключить…", () => this._power("off")],
            null,
            ["Заблокировать экран", () => this._power("lock")],
            ["Завершить сеанс «" + this._userName() + "»…", () => this._power("logout")],
        ];
        let listBox = vbox("spacing: 0px; padding-top: 4px;");
        for (let it of items) {
            if (!it) { root.add_child(new St.Bin({ style: "height: 1px; background-color: #D6D6D6; margin: 4px 8px;" })); continue; }
            root.add_child(this._item(null, it[0], it[1], { labelStyle: t, style: "padding: 4px 12px; border-radius: 4px;", hover: hv }));
        }
        let inner = vbox("spacing: 1px;");
        root.add_child(this._entry("Поиск", "margin: 6px 4px 2px 4px; padding: 4px 8px; border-radius: 6px; background-color: #FFFFFF; border: 1px solid #D0D0D0; color: #1D1D1F;",
            (q) => { if (q) { listBox.show(); this._appList(this._search(q), inner, 16, t, hv); } else { listBox.hide(); } }));
        listBox.add_child(this._scroll(inner, 260));
        listBox.hide();
        root.add_child(listBox);
        return root;
    }

    on_applet_removed_from_panel() {
        try { this.menu.close(false); } catch (e) {}
        try { this.menu.destroy(); } catch (e) {}
        try { if (this._monitor) this._monitor.cancel(); } catch (e) {}
        try { if (this._focusId) global.display.disconnect(this._focusId); } catch (e) {}
        try { if (this._appSys && this._appSysId) this._appSys.disconnect(this._appSysId); } catch (e) {}
    }
}

function main(metadata, orientation, panelHeight, instanceId) {
    return new ArthemMenuApplet(metadata, orientation, panelHeight, instanceId);
}
