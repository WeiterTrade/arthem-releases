"""arthem-pack — создание набора .arthem из ISO-образа Windows (XP, 7, 10, 11).

    arthem-pack --iso Win7.iso                     → Windows7.arthem в текущей папке
    arthem-pack --iso WinXP.iso --upscale -o XP.arthem
    arthem-pack --iso Win11.iso --install          → сразу установить набор

Что извлекается: обои, звуки, иконки (папки, компьютер, корзина), курсоры, кнопка «Пуск» (XP/7),
мелодия запуска. Шрифты — только с ключом --fonts.

Нужные программы: 7z (или 7zz), wimlib-imagex (Vista+), cabextract (XP), wrestool/icotool (icoutils),
convert (ImageMagick); для курсоров — xcursorgen; для апскейла — realesrgan-ncnn-vulkan.
"""

import argparse
import datetime
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from . import __version__, packs, paths, styles

ESRGAN_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-ubuntu.zip"
ESRGAN_DIR = paths.DATA_DIR / "tools" / "realesrgan"

# ------------------------------------------------------------------ вывод

def say(*a):
    print(*a, flush=True)


def warn(*a):
    print("  ! " + " ".join(str(x) for x in a), flush=True)


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def run(cmd, check=True, quiet=True, timeout=3600):
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if check and res.returncode != 0:
        raise RuntimeError(f"{' '.join(map(str, cmd[:3]))}…: {(res.stderr or res.stdout).strip()[:400]}")
    return res


# ------------------------------------------------------------------ сопоставления

SOUND_MAP = [
    # (событие freedesktop, ключевые слова в имени файла Windows по приоритету)
    ("desktop-login", ["xp startup", "logon"]),
    ("desktop-logout", ["xp shutdown", "logoff", "shutdown"]),
    ("dialog-error", ["critical stop", "error"]),
    ("dialog-warning", ["exclamation"]),
    ("dialog-information", ["notify system generic", "notify", "asterisk", "ding"]),
    ("message-new-instant", ["notify messaging", "balloon", "notify"]),
    ("message", ["notify email", "notify"]),
    ("bell", ["ding", "default"]),
    ("complete", ["chimes", "ding"]),
    ("device-added", ["hardware insert"]),
    ("device-removed", ["hardware remove"]),
    ("trash-empty", ["recycle"]),
    ("battery-low", ["battery low"]),
]

# Иконки: имя freedesktop → [(dll, id ресурса группы иконок)], первая найденная используется.
# Для Vista+ это идентификаторы из реестра DefaultIcon (imageres.dll,-N).
ICONS_MODERN = {
    "places/folder": [("imageres", 3)],
    "mimetypes/inode-directory": [("imageres", 3)],
    "places/user-home": [("imageres", 123), ("imageres", 3)],
    "places/user-desktop": [("imageres", 183), ("imageres", 105)],
    "places/folder-documents": [("imageres", 112), ("imageres", 107)],
    "places/folder-download": [("imageres", 184)],
    "places/folder-downloads": [("imageres", 184)],
    "places/folder-pictures": [("imageres", 113), ("imageres", 108)],
    "places/folder-music": [("imageres", 108), ("imageres", 103)],
    "places/folder-videos": [("imageres", 189), ("imageres", 178)],
    "devices/computer": [("imageres", 109), ("imageres", 104)],
    "places/user-trash": [("imageres", 55)],
    "places/user-trash-full": [("imageres", 54)],
    "devices/drive-harddisk": [("imageres", 30), ("imageres", 32)],
    "places/network-workgroup": [("imageres", 25), ("imageres", 120)],
    "apps/system-file-manager": [("imageres", 3)],
}
ICONS_XP = {
    "places/folder": [("shell32", 4)],
    "mimetypes/inode-directory": [("shell32", 4)],
    "places/folder-documents": [("mydocs", "first"), ("shell32", 235)],
    "devices/computer": [("explorer", "first"), ("shell32", 16)],
    "places/user-trash": [("shell32", 32)],
    "places/user-trash-full": [("shell32", 33)],
    "devices/drive-harddisk": [("shell32", 9)],
    "places/user-desktop": [("shell32", 35)],
    "apps/system-file-manager": [("shell32", 4)],
}
CURSOR_MAP = [
    (["aero_arrow", "arrow_r", "arrow_m", "arrow"], ["left_ptr", "default", "arrow", "top_left_arrow"]),
    (["aero_link", "hand"], ["hand2", "hand1", "pointer", "pointing_hand"]),
    (["aero_working", "appstart", "wait_r"], ["left_ptr_watch", "progress", "half-busy"]),
    (["aero_busy", "busy", "hourglas"], ["watch", "wait"]),
    (["aero_helpsel", "help"], ["help", "question_arrow", "whats_this", "left_ptr_help"]),
    (["aero_unavail", "unavail", "no_"], ["not-allowed", "crossed_circle", "forbidden", "circle"]),
    (["aero_ns", "size3", "ns_"], ["sb_v_double_arrow", "ns-resize", "v_double_arrow", "size_ver", "row-resize", "n-resize", "s-resize"]),
    (["aero_ew", "size4", "ew_"], ["sb_h_double_arrow", "ew-resize", "h_double_arrow", "size_hor", "col-resize", "e-resize", "w-resize"]),
    (["aero_nwse", "size2", "nwse"], ["nwse-resize", "size_fdiag", "bd_double_arrow", "nw-resize", "se-resize", "bottom_right_corner", "top_left_corner"]),
    (["aero_nesw", "size1", "nesw"], ["nesw-resize", "size_bdiag", "fd_double_arrow", "ne-resize", "sw-resize", "bottom_left_corner", "top_right_corner"]),
    (["aero_move", "move"], ["fleur", "move", "size_all", "all-scroll", "grabbing"]),
    (["aero_up", "up_"], ["up-arrow", "center_ptr"]),
    (["aero_pen", "pen_"], ["pencil"]),
    (["beam", "ibeam"], ["xterm", "text", "ibeam"]),
    (["cross"], ["crosshair", "cross", "tcross"]),
]

SIZES = [16, 22, 24, 32, 48, 64, 128, 256]


# ------------------------------------------------------------------ ISO

class Iso:
    """Доступ к файлам ISO: монтирование через udisksctl (без root) или распаковка 7z."""

    def __init__(self, iso, work):
        self.iso = str(Path(iso).resolve())
        self.work = Path(work)
        self.mount = None
        self.loop = None
        self.seven = which("7z", "7zz", "7za")

    def __enter__(self):
        if which("udisksctl"):
            try:
                out = run(["udisksctl", "loop-setup", "-r", "-f", self.iso, "--no-user-interaction"]).stdout
                m = re.search(r"(/dev/loop\d+)", out)
                if m:
                    self.loop = m.group(1)
                    out2 = run(["udisksctl", "mount", "-b", self.loop, "--no-user-interaction"], check=False).stdout
                    m2 = re.search(r" at (.+?)\.?$", out2.strip())
                    if m2:
                        self.mount = Path(m2.group(1).strip())
                    else:
                        # окружение могло смонтировать образ само
                        info = run(["udisksctl", "info", "-b", self.loop], check=False).stdout
                        m3 = re.search(r"MountPoints:\s+(\S.*)", info)
                        if m3:
                            self.mount = Path(m3.group(1).strip())
            except Exception as exc:
                warn("не удалось смонтировать ISO, распакую через 7z:", exc)
        return self

    def __exit__(self, *a):
        if self.loop:
            run(["udisksctl", "unmount", "-b", self.loop, "--no-user-interaction"], check=False)
            run(["udisksctl", "loop-delete", "-b", self.loop, "--no-user-interaction"], check=False)

    def find(self, *candidates):
        """Путь к файлу внутри ISO (без учёта регистра). Распаковывает при необходимости."""
        for cand in candidates:
            if self.mount:
                p = self._ci(self.mount, cand)
                if p:
                    return p
            elif self.seven:
                dest = self.work / "iso"
                res = run([self.seven, "x", "-y", "-ssc-", f"-o{dest}", self.iso, cand], check=False)
                p = self._ci(dest, cand)
                if p:
                    return p
        return None

    def extract_glob(self, patterns, dest):
        """Распаковать файлы по шаблонам (без учёта регистра) в dest."""
        dest = Path(dest)
        dest.mkdir(parents=True, exist_ok=True)
        if self.mount:
            for pat in patterns:
                d, _, mask = pat.rpartition("/")
                src_dir = self._ci(self.mount, d) if d else self.mount
                if not src_dir:
                    continue
                rx = re.compile("^" + re.escape(mask).replace(r"\*", ".*").replace(r"\?", ".") + "$", re.I)
                for f in src_dir.iterdir():
                    if f.is_file() and rx.match(f.name):
                        shutil.copy2(f, dest / f.name)
        elif self.seven:
            run([self.seven, "e", "-y", "-ssc-", f"-o{dest}", self.iso] + patterns, check=False)
        return sorted(dest.iterdir())

    @staticmethod
    def _ci(base, rel):
        cur = Path(base)
        for part in [p for p in rel.split("/") if p]:
            if not cur.is_dir():
                return None
            low = part.lower()
            nxt = None
            for f in cur.iterdir():
                if f.name.lower() == low:
                    nxt = f
                    break
            if nxt is None:
                return None
            cur = nxt
        return cur


# ------------------------------------------------------------------ изображения

def magick():
    return which("magick", "convert")


def to_png(src, dst, size=None):
    tool = magick()
    if not tool:
        raise RuntimeError("Нужен ImageMagick (convert/magick).")
    cmd = [tool, str(src) + ("[0]" if str(src).lower().endswith((".bmp", ".ico", ".cur")) else "")]
    if size:
        cmd += ["-resize", f"{size}x{size}"]
    cmd += [str(dst)]
    run(cmd)


def image_size(path):
    tool = which("identify") or (magick() if magick() and magick().endswith("magick") else None)
    if not tool:
        return (0, 0)
    cmd = [tool, "identify", "-format", "%w %h", str(path) + "[0]"] if tool.endswith("magick") else [tool, "-format", "%w %h", str(path) + "[0]"]
    res = run(cmd, check=False)
    try:
        w, h = res.stdout.split()[:2]
        return int(w), int(h)
    except ValueError:
        return (0, 0)


def esrgan_bin():
    exe = which("realesrgan-ncnn-vulkan")
    if exe:
        return exe
    cand = list(ESRGAN_DIR.rglob("realesrgan-ncnn-vulkan"))
    return str(cand[0]) if cand else None


def download_esrgan():
    say(f"Скачиваю Real-ESRGAN (~45 МБ) в {ESRGAN_DIR} …")
    ESRGAN_DIR.mkdir(parents=True, exist_ok=True)
    tmp = ESRGAN_DIR / "esrgan.zip"
    with urllib.request.urlopen(ESRGAN_URL, timeout=120) as r, open(tmp, "wb") as fh:
        shutil.copyfileobj(r, fh)
    with zipfile.ZipFile(tmp) as zf:
        zf.extractall(ESRGAN_DIR)
    tmp.unlink()
    exe = esrgan_bin()
    if exe:
        os.chmod(exe, 0o755)
    return exe


def upscale(src, dst, allow_download):
    """Увеличивает картинку до ~4K: нейросетью, если есть, иначе Lanczos + резкость."""
    w, h = image_size(src)
    exe = esrgan_bin()
    if not exe and allow_download:
        try:
            exe = download_esrgan()
        except Exception as exc:
            warn("не удалось скачать Real-ESRGAN:", exc)
    tool = magick()
    if exe:
        tmp_in = Path(dst).with_suffix(".in.png")
        to_png(src, tmp_in)
        model = "realesrgan-x4plus"
        ok = False
        for tile in ("0", "200", "100"):
            res = run([exe, "-i", str(tmp_in), "-o", str(dst), "-n", model, "-t", tile], check=False)
            if res.returncode == 0 and Path(dst).exists():
                ok = True
                break
        tmp_in.unlink(missing_ok=True)
        if ok:
            say(f"    нейросеть: {Path(src).name} {w}×{h} → ×4")
            return True
        warn("Real-ESRGAN не сработал (нет Vulkan?), увеличу обычным способом")
    if tool:
        target = max(2560, w * 2)
        run([tool, str(src) + "[0]", "-filter", "Lanczos", "-resize", f"{target}x", "-unsharp", "0x0.75+0.75+0.008", str(dst)])
        say(f"    Lanczos: {Path(src).name} {w}×{h} → {target}px")
        return True
    return False


# ------------------------------------------------------------------ иконки и ресурсы PE

def wrestool():
    return which("wrestool")


def extract_group_icon(pe, ident, out_ico):
    """Достаёт группу иконок (RT_GROUP_ICON=14) как .ico. ident — число или 'first'."""
    tool = wrestool()
    if not tool or not pe or not Path(pe).exists():
        return False
    if ident == "first":
        lst = run([tool, "-l", "-t", "14", str(pe)], check=False).stdout
        m = re.search(r"--name=(?:')?([^ ']+)", lst)
        if not m:
            return False
        ident = m.group(1)
    res = run([tool, "-x", "-t", "14", "-n", str(ident), "-o", str(out_ico), str(pe)], check=False)
    return res.returncode == 0 and Path(out_ico).exists() and Path(out_ico).stat().st_size > 0


def ico_to_sizes(ico, out_dir):
    """Раскладывает .ico по размерам. Возвращает {размер: png}."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    found = {}
    if which("icotool"):
        run(["icotool", "-x", "-o", str(out_dir), str(ico)], check=False)
        for f in out_dir.glob("*.png"):
            m = re.search(r"_(\d+)x(\d+)x(\d+)\.png$", f.name)
            if m:
                s, bpp = int(m.group(1)), int(m.group(3))
                if s not in found or bpp > found[s][1]:
                    found[s] = (f, bpp)
    result = {s: f for s, (f, _b) in found.items()}
    if not result and magick():
        big = out_dir / "big.png"
        to_png(ico, big)
        result[image_size(big)[0] or 32] = big
    return result


def build_icon_theme(dlls, mapping, theme_dir, inherit):
    theme_dir = Path(theme_dir)
    tmp = theme_dir.parent / "_ico"
    made = set()
    dirs = set()
    for name, cands in mapping.items():
        ctx, icon = name.split("/")
        for dll, ident in cands:
            pe = dlls.get(dll)
            if not pe:
                continue
            ico = tmp / f"{dll}_{ident}.ico"
            ico.parent.mkdir(parents=True, exist_ok=True)
            if not ico.exists() and not extract_group_icon(pe, ident, ico):
                continue
            sizes = ico_to_sizes(ico, tmp / f"{dll}_{ident}")
            if not sizes:
                continue
            biggest = max(sizes)
            for s in SIZES:
                src = sizes.get(s)
                d = theme_dir / f"{s}x{s}" / ctx
                d.mkdir(parents=True, exist_ok=True)
                if src:
                    shutil.copy2(src, d / f"{icon}.png")
                elif s <= biggest and magick():
                    to_png(sizes[biggest], d / f"{icon}.png", s)
                else:
                    continue
                dirs.add(f"{s}x{s}/{ctx}")
            made.add(icon)
            break
    shutil.rmtree(tmp, ignore_errors=True)
    if not made:
        return 0
    ctxname = {"places": "Places", "devices": "Devices", "mimetypes": "MimeTypes", "apps": "Applications"}
    lines = ["[Icon Theme]", f"Name={theme_dir.name}", "Comment=Arthem: иконки из набора",
             f"Inherits={inherit}", "Directories=" + ",".join(sorted(dirs)), ""]
    for d in sorted(dirs):
        s = int(d.split("x")[0])
        lines += [f"[{d}]", f"Size={s}", f"Context={ctxname[d.split('/')[1]]}", "Type=Fixed", ""]
    (theme_dir / "index.theme").write_text("\n".join(lines), encoding="utf-8")
    return len(made)


def extract_start_bitmap(pe, ident, out_png, states):
    """Кнопка «Пуск» из ресурсов explorer.exe (BITMAP). states — сколько состояний сложено по вертикали."""
    tool = wrestool()
    if not tool or not pe:
        return False
    bmp = Path(out_png).with_suffix(".bmp")
    res = run([tool, "-x", "-t", "2", "-n", str(ident), "-o", str(bmp), str(pe)], check=False)
    if res.returncode != 0 or not bmp.exists() or bmp.stat().st_size < 100:
        return False
    data = bmp.read_bytes()
    if not data.startswith(b"BM"):
        # wrestool отдаёт DIB без заголовка файла — добавим
        hdr_size = struct.unpack("<I", data[:4])[0]
        bpp = struct.unpack("<H", data[14:16])[0]
        clr = struct.unpack("<I", data[32:36])[0] if hdr_size >= 36 else 0
        palette = (clr or (1 << bpp if bpp <= 8 else 0)) * 4
        off = 14 + hdr_size + palette
        data = b"BM" + struct.pack("<IHHI", 14 + len(data), 0, 0, off) + data
        bmp.write_bytes(data)
    tool_m = magick()
    if not tool_m:
        return False
    w, h = image_size(bmp)
    crop = []
    if states > 1 and h:
        crop = ["-crop", f"{w}x{h // states}+0+0", "+repage"]
    run([tool_m, str(bmp)] + crop + [str(out_png)], check=False)
    bmp.unlink(missing_ok=True)
    return Path(out_png).exists()


def extract_wave(pe, out_wav):
    """Самый длинный WAVE-ресурс (мелодия запуска в imageres.dll)."""
    tool = wrestool()
    if not tool or not pe or not Path(pe).exists():
        return False
    d = Path(out_wav).parent / "_wave"
    d.mkdir(parents=True, exist_ok=True)
    run([tool, "-x", "--type=WAVE", "-o", str(d), str(pe)], check=False)
    waves = sorted(d.glob("*"), key=lambda f: f.stat().st_size, reverse=True)
    ok = False
    if waves and waves[0].stat().st_size > 10000:
        shutil.move(str(waves[0]), str(out_wav))
        ok = True
    shutil.rmtree(d, ignore_errors=True)
    return ok


# ------------------------------------------------------------------ курсоры

def _cur_frames(data):
    """Разбор .cur: [(png_bytes_или_None, hx, hy, raw_entry)]"""
    if len(data) < 6:
        return []
    _res, typ, count = struct.unpack("<HHH", data[:6])
    out = []
    for i in range(count):
        e = data[6 + 16 * i: 22 + 16 * i]
        if len(e) < 16:
            break
        w, h, _c, _r, hx, hy, size, off = struct.unpack("<BBBBHHII", e)
        out.append((w or 256, h or 256, hx, hy, data[off: off + size]))
    return out


def _ani_frames(data):
    frames, rate, jif = [], [], 6
    pos = 12
    while pos + 8 <= len(data):
        cid = data[pos:pos + 4]
        size = struct.unpack("<I", data[pos + 4:pos + 8])[0]
        body = data[pos + 8: pos + 8 + size]
        if cid == b"anih" and len(body) >= 36:
            jif = struct.unpack("<I", body[28:32])[0] or 6
        elif cid == b"rate":
            rate = list(struct.unpack(f"<{len(body) // 4}I", body))
        elif cid == b"LIST" and body[:4] == b"fram":
            p2 = 4
            while p2 + 8 <= len(body):
                sid = body[p2:p2 + 4]
                ssz = struct.unpack("<I", body[p2 + 4:p2 + 8])[0]
                if sid == b"icon":
                    frames.append(body[p2 + 8:p2 + 8 + ssz])
                p2 += 8 + ssz + (ssz & 1)
        pos += 8 + size + (size & 1)
    delays = [(rate[i] if i < len(rate) else jif) * 1000 // 60 for i in range(len(frames))]
    return frames, delays


def convert_cursor(src, out_file, work):
    xcg = which("xcursorgen")
    tool = magick()
    if not xcg or not tool:
        return False
    data = Path(src).read_bytes()
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    cfg_lines = []
    if data[:4] == b"RIFF":
        frames, delays = _ani_frames(data)
    else:
        frames, delays = [data], [0]
    for fi, fdata in enumerate(frames):
        for ei, (w, h, hx, hy, _img) in enumerate(_cur_frames(fdata)):
            tmp = work / f"f{fi}_{ei}.cur"
            tmp.write_bytes(fdata)
            png = work / f"f{fi}_{ei}.png"
            res = run([tool, f"{tmp}[{ei}]", str(png)], check=False)
            if res.returncode != 0 or not png.exists():
                continue
            line = f"{w} {hx} {hy} {png.name}"
            if len(frames) > 1:
                line += f" {max(20, delays[fi])}"
            cfg_lines.append(line)
    if not cfg_lines:
        return False
    cfg = work / "cursor.cfg"
    cfg.write_text("\n".join(cfg_lines) + "\n", encoding="utf-8")
    res = run([xcg, "-p", str(work), str(cfg), str(out_file)], check=False)
    return res.returncode == 0


def build_cursor_theme(files, theme_dir):
    theme_dir = Path(theme_dir)
    cdir = theme_dir / "cursors"
    cdir.mkdir(parents=True, exist_ok=True)
    made = 0
    for keys, names in CURSOR_MAP:
        src = None
        for k in keys:
            for f in files:
                if f.name.lower().startswith(k):
                    src = f
                    break
            if src:
                break
        if not src:
            continue
        out = cdir / names[0]
        if convert_cursor(src, out, theme_dir.parent / "_cur" / names[0]):
            made += 1
            for alias in names[1:]:
                link = cdir / alias
                if not link.exists():
                    os.symlink(names[0], link)
    shutil.rmtree(theme_dir.parent / "_cur", ignore_errors=True)
    if made:
        (theme_dir / "index.theme").write_text(
            f"[Icon Theme]\nName={theme_dir.name}\nComment=Arthem: курсоры из набора\nInherits=Adwaita,breeze_cursors\n",
            encoding="utf-8")
    else:
        shutil.rmtree(theme_dir, ignore_errors=True)
    return made


# ------------------------------------------------------------------ XP

def parse_txtsetup(path):
    """Короткое имя → длинное (из TXTSETUP.SIF)."""
    names = {}
    try:
        text = Path(path).read_text(encoding="latin-1", errors="replace")
    except OSError:
        return names
    for line in text.splitlines():
        m = re.match(r"^\s*([^;=\s]+)\s*=\s*(.*)$", line)
        if not m:
            continue
        quoted = re.findall(r'"([^"]+)"', m.group(2))
        if quoted:
            names[m.group(1).lower()] = quoted[-1]
    return names


def expand_xp(files, dest, longnames):
    """Распаковывает сжатые файлы XP (*.XX_) и даёт им настоящие имена."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    cab = which("cabextract")
    for f in files:
        name = f.name
        if name.endswith("_"):
            if not cab:
                continue
            tmpd = dest / "_x"
            tmpd.mkdir(exist_ok=True)
            run([cab, "-q", "-d", str(tmpd), str(f)], check=False)
            for g in tmpd.iterdir():
                real = longnames.get(g.name.lower(), g.name)
                target = dest / real
                shutil.move(str(g), str(target))
                out.append(target)
            shutil.rmtree(tmpd, ignore_errors=True)
        else:
            real = longnames.get(name.lower(), name)
            target = dest / real
            shutil.copy2(f, target)
            out.append(target)
    return out


# ------------------------------------------------------------------ основное

class Builder:
    def __init__(self, args):
        self.args = args
        self.work = Path(tempfile.mkdtemp(prefix="arthem-pack-"))
        self.out = self.work / "pack"
        self.out.mkdir()
        self.manifest = {
            "format": packs.FORMAT,
            "version": packs.FORMAT_VERSION,
            "generator": f"arthem-pack {__version__}",
            "created": datetime.datetime.now().isoformat(timespec="seconds"),
            "source": {"iso": Path(args.iso).name},
        }
        self.notes = []

    def cleanup(self):
        if not self.args.keep_temp:
            shutil.rmtree(self.work, ignore_errors=True)
        else:
            say("Временная папка:", self.work)

    # --- определение системы

    def detect(self, iso):
        if iso.find("sources/install.wim", "sources/install.esd") if iso.mount else None:
            return "modern"
        if iso.find("I386/TXTSETUP.SIF", "AMD64/TXTSETUP.SIF"):
            return "xp"
        if not iso.mount:
            # с 7z проверяем без распаковки большого файла
            res = run([iso.seven, "l", "-ssc-", iso.iso, "sources/install.*"], check=False)
            if "install." in res.stdout:
                return "modern"
        return None

    def run(self):
        need = ["7z/7zz или udisksctl"]
        with Iso(self.args.iso, self.work) as iso:
            if not iso.mount and not iso.seven:
                raise RuntimeError("Нужен 7z (пакет 7zip/p7zip) или udisksctl, чтобы читать ISO.")
            kind = self.detect(iso)
            if kind == "modern":
                self.modern(iso)
            elif kind == "xp":
                self.xp(iso)
            else:
                raise RuntimeError("Не похоже на установочный образ Windows XP/7/10/11.")
        return self.finish()

    def _set_style(self, style, osname, build="", lang=""):
        style = self.args.style or style
        if style not in styles.STYLES or style == "linux":
            raise RuntimeError(f"Не удалось определить версию Windows ({osname}). Укажите --style xp|7|10|11.")
        self.style = styles.resolve(style) or style
        self.manifest["style"] = self.style
        self.manifest["title"] = styles.name(self.style)
        self.manifest["source"].update({"os": osname, "build": str(build), "lang": lang})
        say(f"Система: {osname}" + (f", сборка {build}" if build else "") + (f", {lang}" if lang else ""))

    # --- Vista/7/8/10/11

    def modern(self, iso):
        wim = which("wimlib-imagex", "wimlib")
        if not wim:
            raise RuntimeError("Нужна программа wimlib-imagex (пакет wimtools или wimlib-utils).")
        say("Ищу install.wim/esd…")
        wimfile = iso.find("sources/install.wim", "sources/install.esd")
        if not wimfile:
            raise RuntimeError("В образе нет sources/install.wim или install.esd.")
        info = run([wim, "info", str(wimfile), "1"], check=False).stdout
        def field(name):
            m = re.search(rf"^{name}:\s*(.+)$", info, re.M)
            return m.group(1).strip() if m else ""
        major, minor, build = field("Major Version"), field("Minor Version"), field("Build")
        name = field("Display Name") or field("Name") or "Windows"
        lang = field("Default Language") or field("Languages")
        try:
            b = int(build or 0)
        except ValueError:
            b = 0
        if major == "6" and minor in ("0", "1"):
            style = "w7"
        elif major == "6":
            style = "w10"
        elif b >= 22000:
            style = "w11"
        elif major == "10":
            style = "w10"
        else:
            style = None
        self._set_style(style, name, build, lang)

        root = self.work / "win"
        paths_needed = [
            "/Windows/Web/Wallpaper", "/Windows/Web/4K/Wallpaper/Windows", "/Windows/Media",
            "/Windows/System32/imageres.dll", "/Windows/System32/shell32.dll",
            "/Windows/SystemResources/imageres.dll.mun", "/Windows/SystemResources/shell32.dll.mun",
            "/Windows/explorer.exe", "/Windows/Cursors",
        ]
        if self.args.fonts:
            paths_needed += ["/Windows/Fonts/segoeui.ttf", "/Windows/Fonts/segoeuib.ttf", "/Windows/Fonts/segoeuil.ttf",
                             "/Windows/Fonts/seguisb.ttf", "/Windows/Fonts/tahoma.ttf"]
        say("Извлекаю нужные файлы из install.wim (это 1–3 минуты)…")
        root.mkdir()
        run([wim, "extract", str(wimfile), "1", f"--dest-dir={root}", "--no-acls", "--nullglob", "--preserve-dir-structure"] + paths_needed,
            check=False, timeout=3600)
        W = root / "Windows"
        if not W.is_dir():
            raise RuntimeError("Не удалось извлечь файлы из install.wim.")

        # Обои: 4K, затем обычные
        walls = []
        for d in (W / "Web" / "4K" / "Wallpaper" / "Windows", W / "Web" / "Wallpaper"):
            if d.is_dir():
                walls += [f for f in d.rglob("*") if f.suffix.lower() in (".jpg", ".jpeg", ".png", ".bmp")]
        self.wallpapers(walls)

        # Звуки
        media = [f for f in (W / "Media").rglob("*.wav")] if (W / "Media").is_dir() else []
        res_dir = W / "SystemResources"
        imageres = res_dir / "imageres.dll.mun" if (res_dir / "imageres.dll.mun").exists() else W / "System32" / "imageres.dll"
        shell32 = res_dir / "shell32.dll.mun" if (res_dir / "shell32.dll.mun").exists() else W / "System32" / "shell32.dll"
        startup = self.work / "startup.wav"
        has_start = extract_wave(imageres, startup) or extract_wave(W / "System32" / "imageres.dll", startup)
        self.sounds(media, startup if has_start else None)

        # Иконки
        n = build_icon_theme({"imageres": imageres, "shell32": shell32}, ICONS_MODERN, self.out / "icons",
                             f"{styles.STYLES[self.style]['theme']},breeze,Adwaita,hicolor")
        say(f"Иконок: {n}")

        # Кнопка «Пуск» Windows 7 (шар) из explorer.exe
        if self.style == "w7":
            ui = self.out / "ui"
            ui.mkdir(exist_ok=True)
            for ident in (6801, 6805, 6809):
                if extract_start_bitmap(W / "explorer.exe", ident, ui / "start.png", 3):
                    say("Кнопка «Пуск»: найдена")
                    break

        # Курсоры
        cur = [f for f in (W / "Cursors").iterdir()] if (W / "Cursors").is_dir() else []
        self.cursors(cur)
        if self.args.fonts:
            self.fonts([f for f in (W / "Fonts").glob("*.ttf")] if (W / "Fonts").is_dir() else [])

    # --- XP

    def xp(self, iso):
        sif = iso.find("I386/TXTSETUP.SIF") or iso.find("AMD64/TXTSETUP.SIF")
        arch = "I386" if "i386" in str(sif).lower() else "AMD64"
        longnames = parse_txtsetup(sif)
        text = Path(sif).read_text(encoding="latin-1", errors="replace")
        m = re.search(r'productname\s*=\s*"([^"]+)"', text, re.I)
        osname = m.group(1) if m else "Windows XP"
        build = ""
        m2 = re.search(r"BuildNumber\s*=\s*(\d+)", text, re.I)
        if m2:
            build = m2.group(1)
        self._set_style("xp", osname, build)
        if not which("cabextract"):
            raise RuntimeError("Для XP нужна программа cabextract.")
        say("Извлекаю файлы XP…")
        raw = self.work / "raw"
        pats = [f"{arch}/*.WA_", f"{arch}/*.WAV", f"{arch}/*.BM_", f"{arch}/*.BMP", f"{arch}/*.JP_", f"{arch}/*.JPG",
                f"{arch}/SHELL32.DL_", f"{arch}/EXPLORER.EX_", f"{arch}/MYDOCS.DL_",
                f"{arch}/*.CU_", f"{arch}/*.AN_", f"{arch}/*.CUR", f"{arch}/*.ANI"]
        if self.args.fonts:
            pats += [f"{arch}/TAHOMA*.TT_", f"{arch}/TAHOMA*.TTF", f"{arch}/TREBUC*.TT_", f"{arch}/FRANKLIN*.TT_"]
        files = iso.extract_glob(pats, raw)
        X = self.work / "xp"
        real = expand_xp(files, X, longnames)
        by_ext = lambda *e: [f for f in real if f.suffix.lower() in e]
        imgs = [f for f in by_ext(".jpg", ".bmp") if f.stat().st_size > 60000]
        self.wallpapers(imgs, prefer=["bliss"])
        self.sounds(by_ext(".wav"), None)
        dlls = {}
        for f in real:
            low = f.name.lower()
            if low == "shell32.dll":
                dlls["shell32"] = f
            elif low == "explorer.exe":
                dlls["explorer"] = f
            elif low == "mydocs.dll":
                dlls["mydocs"] = f
        n = build_icon_theme(dlls, ICONS_XP, self.out / "icons", "Arthem-XP,breeze,Adwaita,hicolor")
        say(f"Иконок: {n}")
        if dlls.get("explorer"):
            ui = self.out / "ui"
            ui.mkdir(exist_ok=True)
            for ident in (143, 146):
                if extract_start_bitmap(dlls["explorer"], ident, ui / "start.png", 1):
                    say("Кнопка «пуск»: найдена")
                    break
        self.cursors(by_ext(".cur", ".ani"))
        if self.args.fonts:
            self.fonts(by_ext(".ttf"))

    # --- общие шаги

    def wallpapers(self, files, prefer=("img0",)):
        if not files:
            warn("обои не найдены")
            return
        wd = self.out / "wallpapers"
        wd.mkdir(exist_ok=True)
        files = sorted(files, key=lambda f: (-image_size(f)[0], f.name))
        chosen = None
        for key in prefer:
            for f in files:
                if key in f.name.lower():
                    chosen = f
                    break
            if chosen:
                break
        chosen = chosen or files[0]
        seen = set()
        default_rel = None
        for f in files[:40]:
            stem = f.stem.lower()
            stem = re.sub(r"_\d+x\d+$", "", stem)
            if stem in seen:
                continue
            seen.add(stem)
            w, h = image_size(f)
            out = wd / (re.sub(r"[^\w\-. ]", "_", f.stem) + (".png" if f.suffix.lower() == ".bmp" or (w and w < 1600) else f.suffix.lower()))
            small = w and w < 1600
            if small and self.args.upscale:
                upscale(f, out.with_suffix(".png"), allow_download=self.args.download_esrgan)
                out = out.with_suffix(".png")
            elif f.suffix.lower() == ".bmp":
                to_png(f, out)
            else:
                shutil.copy2(f, out)
            if f == chosen:
                default_rel = f"wallpapers/{out.name}"
        self.manifest["wallpaper"] = default_rel or f"wallpapers/{sorted(wd.iterdir())[0].name}"
        say(f"Обои: {len(seen)} (по умолчанию {Path(self.manifest['wallpaper']).name})")

    def sounds(self, wavs, startup):
        if not wavs and not startup:
            warn("звуки не найдены")
            return
        sd = self.out / "sounds" / "stereo"
        sd.mkdir(parents=True, exist_ok=True)
        low = {f: f.stem.lower() for f in wavs}
        used = 0
        for event, keys in SOUND_MAP:
            src = None
            for k in keys:
                for f, n in low.items():
                    if k in n:
                        src = f
                        break
                if src:
                    break
            if src:
                shutil.copy2(src, sd / f"{event}.wav")
                used += 1
        if startup:
            shutil.copy2(startup, sd / "system-ready.wav")
            if not (sd / "desktop-login.wav").exists():
                shutil.copy2(startup, sd / "desktop-login.wav")
        elif (sd / "desktop-login.wav").exists():
            shutil.copy2(sd / "desktop-login.wav", sd / "system-ready.wav")
        theme = styles.STYLES[self.style]["theme"]
        (self.out / "sounds" / "index.theme").write_text(
            f"[Sound Theme]\nName={theme}-Original\nComment=Arthem: звуки из набора\nInherits={theme},freedesktop\n"
            "Directories=stereo\n\n[stereo]\nOutputProfile=stereo\n", encoding="utf-8")
        self.manifest["sounds"] = {"startup": "sounds/stereo/system-ready.wav"} if (sd / "system-ready.wav").exists() else {}
        say(f"Звуки: {used} событий" + (", мелодия запуска найдена" if startup else ""))

    def cursors(self, files):
        if not files:
            return
        if not which("xcursorgen"):
            warn("курсоры пропущены: нет программы xcursorgen (пакет x11-apps / xorg-x11-apps)")
            return
        n = build_cursor_theme(files, self.out / "cursors")
        say(f"Курсоры: {n}")

    def fonts(self, files):
        if not files:
            return
        fd = self.out / "fonts"
        fd.mkdir(exist_ok=True)
        for f in files:
            shutil.copy2(f, fd / f.name)
        say(f"Шрифты: {len(files)}")

    def preview(self):
        """Мини-рабочий стол из файлов набора (рисуется через Qt без окна)."""
        try:
            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
            from .gui.qt import QtCore, QtGui, QtWidgets
            from .gui import previews
            app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
            img = QtGui.QImage(960, 600, QtGui.QImage.Format_ARGB32_Premultiplied)
            img.fill(0)
            p = QtGui.QPainter(img)
            wall = None
            if self.manifest.get("wallpaper"):
                wall = QtGui.QPixmap(str(self.out / self.manifest["wallpaper"]))
            icons = {}
            for key, rel in (("computer", "icons/48x48/devices/computer.png"), ("trash", "icons/48x48/places/user-trash.png")):
                f = self.out / rel
                if f.exists():
                    icons[key] = QtGui.QPixmap(str(f))
            start = None
            if (self.out / "ui" / "start.png").exists():
                start = QtGui.QPixmap(str(self.out / "ui" / "start.png"))
            previews.paint(p, QtCore.QRectF(0, 0, 960, 600), self.style, 0.0, None, wall, icons, start)
            p.end()
            img.save(str(self.out / "preview.png"))
            self.manifest["preview"] = "preview.png"
            say("Превью: готово")
        except Exception as exc:
            warn("превью не создано:", exc)

    def finish(self):
        self.preview()
        contents = sorted({p.relative_to(self.out).parts[0] for p in self.out.rglob("*") if p.is_file()})
        self.manifest["contents"] = contents
        (self.out / "manifest.json").write_text(json.dumps(self.manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        name = {"xp": "WindowsXP", "w7": "Windows7", "w10": "Windows10", "w11": "Windows11"}.get(self.style, self.style)
        target = Path(self.args.output) if self.args.output else Path.cwd() / f"{name}.arthem"
        if target.is_dir():
            target = target / f"{name}.arthem"
        tmpzip = target.with_suffix(".arthem.part")
        with zipfile.ZipFile(tmpzip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(self.out / "manifest.json", "manifest.json")
            for f in sorted(self.out.rglob("*")):
                rel = f.relative_to(self.out).as_posix()
                if rel == "manifest.json":
                    continue
                if f.is_symlink():
                    # ссылки внутри набора запрещены — пишем копию файла
                    real = f.resolve()
                    if real.is_file():
                        zf.write(real, rel)
                elif f.is_file():
                    zf.write(f, rel)
        os.replace(tmpzip, target)
        size = target.stat().st_size / 1024 / 1024
        say(f"\nНабор готов: {target} ({size:.1f} МБ)")
        return target


def main(argv=None):
    ap = argparse.ArgumentParser(prog="arthem-pack", description="Создать набор .arthem из ISO-образа Windows")
    ap.add_argument("--iso", required=True, help="путь к ISO-образу Windows XP/7/10/11")
    ap.add_argument("-o", "--output", help="куда сохранить .arthem (файл или папка)")
    ap.add_argument("--style", help="принудительно: xp, 7, 10, 11")
    ap.add_argument("--upscale", action="store_true", help="увеличить маленькие обои (нейросеть, если есть)")
    ap.add_argument("--download-esrgan", action="store_true", help="скачать Real-ESRGAN, если её нет")
    ap.add_argument("--fonts", action="store_true", help="положить в набор шрифты из образа")
    ap.add_argument("--install", action="store_true", help="сразу установить набор для текущего пользователя")
    ap.add_argument("--keep-temp", action="store_true", help="не удалять временные файлы")
    args = ap.parse_args(argv)
    if args.style:
        args.style = styles.resolve(args.style)
    if args.upscale and not esrgan_bin() and not args.download_esrgan and sys.stdin.isatty():
        ans = input("Нейросеть Real-ESRGAN не найдена. Скачать (~45 МБ)? [Д/н] ").strip().lower()
        args.download_esrgan = ans in ("", "д", "да", "y", "yes")
    b = Builder(args)
    try:
        target = b.run()
        if args.install:
            p = packs.install(target)
            say(f"Набор установлен: {p.title}")
    except Exception as exc:
        print(f"\nОшибка: {exc}", file=sys.stderr, flush=True)
        return 1
    finally:
        b.cleanup()
    return 0


if __name__ == "__main__":
    sys.exit(main())
