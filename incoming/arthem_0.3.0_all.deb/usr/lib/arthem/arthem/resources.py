"""Выбор ресурсов для стиля: встроенные или из набора .arthem, плюс подготовка ссылок на темы набора."""

import os
from pathlib import Path

from . import packs, paths, styles, util


def _link(target, link_path, backup):
    link_path = Path(link_path)
    link_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        if os.path.islink(link_path):
            os.remove(link_path)
        elif link_path.exists():
            util.log("папка занята, ссылку не создаю:", link_path)
            return False
        os.symlink(str(target), str(link_path))
        backup.add_created(str(link_path))
        return True
    except OSError as exc:
        util.log("не удалось создать ссылку", link_path, exc)
        return False


def builtin_wallpaper(style_id):
    for ext in (".png", ".jpg", ".svg"):
        p = paths.share("wallpapers", style_id + ext)
        if p.is_file():
            return p
    return None


def builtin_start_icon(style_id):
    for ext in (".png", ".svg"):
        p = paths.share("start", style_id + ext)
        if p.is_file():
            return p
    return None


def builtin_sound(style_id, event="desktop-login"):
    theme = styles.STYLES[style_id].get("theme")
    if not theme:
        return None
    for base in (paths.PREFIX / "share" / "sounds", paths.USER_SOUNDS):
        for ext in (".wav", ".oga", ".ogg"):
            p = base / theme / "stereo" / (event + ext)
            if p.is_file():
                return p
    return None


class Resources:
    """Что именно ставить для стиля с учётом галочек в настройках и наличия набора."""

    def __init__(self, style_id, cfg, backup):
        st = styles.get(style_id)
        comp = cfg.get("components", {})
        self.style = style_id
        self.pack = packs.get(style_id)
        theme = st["theme"]
        self.gtk_theme = theme
        self.plasma_theme = theme
        self.icon_theme = theme if comp.get("icons", True) else None
        self.sound_theme = theme if comp.get("sounds", True) else None
        self.cursor_theme = None
        self.wallpaper = builtin_wallpaper(style_id) if comp.get("wallpaper", True) else None
        self.start_icon = builtin_start_icon(style_id)
        self.startup_sound = builtin_sound(style_id)
        self.original = False

        pk = self.pack
        if pk:
            self.original = True
            if comp.get("icons", True) and pk.icons_dir():
                name = f"{theme}-Original"
                if _link(pk.icons_dir(), paths.USER_ICONS / name, backup):
                    self.icon_theme = name
            if comp.get("sounds", True) and pk.sounds_dir():
                name = f"{theme}-Original"
                if _link(pk.sounds_dir(), paths.USER_SOUNDS / name, backup):
                    self.sound_theme = name
            if comp.get("cursors", True) and pk.cursors_dir():
                name = f"{theme}-Cursors"
                if _link(pk.cursors_dir(), paths.USER_ICONS / name, backup):
                    self.cursor_theme = name
            if comp.get("wallpaper", True) and pk.wallpaper():
                self.wallpaper = pk.wallpaper()
            if pk.ui("start.png"):
                self.start_icon = pk.ui("start.png")
            if pk.startup_sound():
                self.startup_sound = pk.startup_sound()

    def describe(self):
        return {
            "gtk": self.gtk_theme,
            "icons": self.icon_theme,
            "sounds": self.sound_theme,
            "cursors": self.cursor_theme,
            "wallpaper": str(self.wallpaper) if self.wallpaper else None,
            "start": str(self.start_icon) if self.start_icon else None,
            "original": self.original,
        }


# ---------- GTK4 / libadwaita ----------

GTK4_BEGIN = "/* arthem:begin — блок добавлен Arthem, удаляется при откате */"
GTK4_END = "/* arthem:end */"

_GTK4_CONTROLS = {
    "mac": """
windowcontrols > button > image { border-radius: 50%; min-width: 12px; min-height: 12px; padding: 0; color: transparent; }
windowcontrols > button.close > image { background-color: #FF5F57; }
windowcontrols > button.minimize > image { background-color: #FEBC2E; }
windowcontrols > button.maximize > image { background-color: #28C840; }
windowcontrols > button:hover > image { color: rgba(0,0,0,0.6); }
""",
    "xp": """
windowcontrols > button.close > image { background-color: #D9472B; color: #FFFFFF; border-radius: 3px; }
""",
}


def gtk4_css(style_id):
    st = styles.get(style_id)
    accent = st["accent"]
    controls = _GTK4_CONTROLS.get(style_id, """
windowcontrols > button.close:hover > image { background-color: #C42B1C; color: #FFFFFF; }
""")
    radius = {"xp": 3, "w7": 4, "w10": 0, "w11": 8, "mac": 10}.get(style_id, 6)
    return f"""{GTK4_BEGIN}
@define-color accent_bg_color {accent};
@define-color accent_color {accent};
@define-color accent_fg_color #ffffff;
button, entry, popover > contents {{ border-radius: {radius}px; }}
{controls}
{GTK4_END}
"""


def write_gtk4_css(style_id, backup):
    path = paths.XDG_CONFIG / "gtk-4.0" / "gtk.css"
    backup.record_file(path)
    old = ""
    if path.is_file():
        old = path.read_text(encoding="utf-8", errors="replace")
    old = strip_block(old)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text((old.rstrip() + "\n\n" if old.strip() else "") + gtk4_css(style_id), encoding="utf-8")


def strip_block(text):
    while GTK4_BEGIN in text and GTK4_END in text:
        a = text.index(GTK4_BEGIN)
        b = text.index(GTK4_END, a) + len(GTK4_END)
        text = text[:a] + text[b:]
    return text
